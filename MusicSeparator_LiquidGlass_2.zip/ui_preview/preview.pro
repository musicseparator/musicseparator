QT += widgets
CONFIG += c++20
TARGET = studio-preview
TEMPLATE = app
INCLUDEPATH += ../src
SOURCES += preview.cpp \
    ../src/ui/Theme.cpp ../src/ui/StudioWindow.cpp ../src/ui/AppearanceDialog.cpp \
    ../src/ui/ImportDropZone.cpp ../src/ui/MixConsoleWidget.cpp \
    ../src/ui/TrackCard.cpp ../src/ui/TransportBar.cpp ../src/ui/WaveformWidget.cpp \
    ../src/audio/Waveform.cpp
HEADERS += ../src/ui/Theme.h ../src/ui/ImportDropZone.h ../src/ui/MixConsoleWidget.h \
    ../src/ui/TrackCard.h ../src/ui/TransportBar.h ../src/ui/WaveformWidget.h
RESOURCES += ../resources/resources.qrc
