// UI-only preview. Synthetic waveforms; no model or audio engine involved.
#include "ui/Theme.h"
#include "ui/StudioWindow.h"
#include "ui/AppearanceDialog.h"
#include "ui/ImportDropZone.h"
#include "ui/MixConsoleWidget.h"
#include <QApplication>
#include <QCheckBox>
#include <QComboBox>
#include <QDir>
#include <QDialogButtonBox>
#include <QSettings>
#include <QHBoxLayout>
#include <QLabel>
#include <QPushButton>
#include <QStackedWidget>
#include <QTimer>
#include <QVBoxLayout>
#include <cmath>
#include <iostream>

int main(int argc,char** argv) {
    QApplication app(argc,argv); app.setStyle("Fusion");
    app.setOrganizationName("MusicSeparatorPreview"); app.setApplicationName("VisualReview");
    mc::Theme::apply({});
    mc::StudioWindow window; window.resize(1160,800);
    auto* central=new QWidget; auto* root=new QVBoxLayout(central); root->setContentsMargins(0,0,0,0); root->setSpacing(0);
    root->addWidget(new mc::StudioTitleBar(&window));
    auto* header=new QWidget; header->setObjectName("headerBar"); header->setFixedHeight(64);
    auto* headerRow=new QHBoxLayout(header); headerRow->setContentsMargins(20,0,20,0);
    auto* heading=new QLabel("Workspace"); heading->setObjectName("cardTitle"); headerRow->addWidget(heading); headerRow->addStretch();
    for(const auto& name: {QString("New import"),QString("Appearance"),QString("Settings")}) {
        auto* b=new QPushButton(name); b->setObjectName("ghostButton"); b->setIcon(mc::Theme::icon(name=="Settings"?"settings":name=="Appearance"?"appearance":"new")); headerRow->addWidget(b);
        if(name=="Appearance") QObject::connect(b,&QPushButton::clicked,&window,[&]{mc::AppearanceDialog d(&window); d.exec();});
    }
    root->addWidget(header);
    auto* pages=new QStackedWidget; root->addWidget(pages,1);
    auto* imports=new QWidget; auto* importLayout=new QVBoxLayout(imports); importLayout->setContentsMargins(48,32,48,32);
    auto* drop=new mc::ImportDropZone; drop->setMaximumWidth(860); importLayout->addWidget(drop,1); importLayout->setAlignment(drop,Qt::AlignHCenter); pages->addWidget(imports);
    auto* mixPage=new QWidget; auto* mixLayout=new QVBoxLayout(mixPage); mixLayout->setContentsMargins(0,0,0,0); mixLayout->setSpacing(0);
    auto* song=new QWidget; song->setObjectName("headerBar"); song->setFixedHeight(48); auto* songRow=new QHBoxLayout(song); songRow->setContentsMargins(16,0,16,0);
    auto* back=new QPushButton("Back to track"); back->setObjectName("ghostButton"); songRow->addWidget(back); songRow->addStretch();
    auto* title=new QLabel("Separated tracks"); title->setObjectName("cardTitle"); songRow->addWidget(title); songRow->addStretch(); auto* spacer=new QWidget; spacer->setObjectName("mixSpacer"); spacer->setFixedWidth(120); songRow->addWidget(spacer); mixLayout->addWidget(song);
    auto* mix=new mc::MixConsoleWidget; mixLayout->addWidget(mix,1); pages->addWidget(mixPage);
    QVector<mc::StemResult> stems;
    const QString names[]{"Vocals","Drums","Bass","Guitar","Piano"};
    for(int s=0;s<5;++s) {
        mc::StemResult stem; stem.displayName=names[s]; stem.id=names[s].toLower(); stem.buffer.pcm.resize(88000);
        for(int i=0;i<44000;++i) {
            double t=i/44000.; double envelope=.15+.6*std::pow(std::abs(std::sin(t*(21+s*7))),2);
            double beats=std::exp(-std::fmod(t*(48+s*2),1.)*(s==1?8:1));
            float sample=float(std::sin(i*.43)*envelope*beats);
            stem.buffer.pcm[2*i]=sample; stem.buffer.pcm[2*i+1]=sample;
        }
        stems.append(std::move(stem));
    }
    mix->setStems(stems); mix->setDuration(214); mix->setPosition(78);
    auto* footer=new QWidget; footer->setObjectName("footer"); auto* footerRow=new QHBoxLayout(footer); footerRow->setContentsMargins(24,8,24,8);
    auto* note=new QLabel("MusicSeparator  /  Liquid Glass · 2.0"); note->setObjectName("metaLabel"); footerRow->addWidget(note); footerRow->addStretch();
    auto* shortcut=new QLabel("Ctrl+O  Import audio"); shortcut->setObjectName("metaLabel"); footerRow->addWidget(shortcut); root->addWidget(footer);
    window.setCentralWidget(central); window.show();
    if(argc>1) {
        const QString output=QString::fromLocal8Bit(argv[1]); QDir().mkpath(output);
        QTimer::singleShot(150,[&,output] {
            auto capture=[&](const QString& name) { app.processEvents(); window.grab().save(output+"/"+name+".png"); };
            pages->setCurrentIndex(1); capture("studio-light");
            auto a=mc::Theme::current(); a.theme="dark"; mc::Theme::apply(a); capture("studio-dark");
            for(const auto& preset:mc::Theme::presets()) { a.preset=preset.id; mc::Theme::apply(a); capture("glass-"+preset.id); }
            a.preset="mint"; mc::Theme::apply(a); pages->setCurrentIndex(0); capture("studio-import");
            mc::AppearanceDialog dialog(&window); dialog.show(); app.processEvents(); dialog.grab().save(output+"/studio-appearance.png"); dialog.reject();
            window.resize(940,720); pages->setCurrentIndex(1); a.textSize=15; a.compact=true; a.controlsRight=true; mc::Theme::apply(a); capture("studio-compact");
            // Exercise actual controls: preview, reject, save and reload.
            auto before=mc::Theme::current();
            {
                mc::AppearanceDialog d(&window);
                auto* combo=d.findChildren<QComboBox*>().first();
                combo->setCurrentIndex(combo->findData("champagne"));
                if(mc::Theme::current().preset!="champagne") qFatal("Preset preview failed");
                d.reject();
                if(mc::Theme::current().preset!=before.preset) qFatal("Cancel rollback failed");
            }
            {
                mc::AppearanceDialog d(&window);
                auto* combo=d.findChildren<QComboBox*>().first();
                combo->setCurrentIndex(combo->findData("sage"));
                d.findChildren<QCheckBox*>().first()->setChecked(false);
                d.findChild<QDialogButtonBox*>()->button(QDialogButtonBox::Save)->click();
                mc::Theme::apply({}); mc::Theme::load();
                if(mc::Theme::current().preset!="sage" || mc::Theme::current().glass) qFatal("Settings persistence failed");
                capture("glass-opaque");
            }
            QSettings().clear();
            std::cout << "PASS: preset preview, cancel rollback, save/reload, opaque mode.\n";
            std::cout << "Qt UI rendered: light, dark, import, appearance, compact.\n";
            app.quit();
        });
    }
    return app.exec();
}
