# Post-build deployment for MusicSeparator.exe
#
# 1. Runs windeployqt so Qt plugins (platforms/qwindows.dll, multimedia
#    backends, image formats...) end up next to the exe.
# 2. Copies the models/ folder (downloaded by tools/download_models.ps1).
# 3. Copies yt-dlp.exe when present.
#
# Non-Qt DLLs (Qt6*, onnxruntime.dll, DirectML.dll, avcodec-*, ...) are
# copied automatically by vcpkg's app-local deployment (VCPKG_APPLOCAL_DEPS).

function(ms_deploy target)
    if(NOT WIN32)
        return()
    endif()

    add_custom_command(TARGET ${target} POST_BUILD
        COMMAND "$<TARGET_FILE:Qt6::windeployqt>"
                --no-translations --no-opengl-sw --release
                "$<TARGET_FILE:${target}>"
        COMMENT "Deploying Qt runtime next to the executable"
    )

    # Copy models directory (if the developer downloaded them).
    add_custom_command(TARGET ${target} POST_BUILD
        COMMAND ${CMAKE_COMMAND} -E copy_directory_if_different
                "${CMAKE_CURRENT_SOURCE_DIR}/models"
                "$<TARGET_FILE_DIR:${target}>/models"
        COMMENT "Copying models folder"
    )

    # Copy yt-dlp.exe when present in the source tree.
    add_custom_command(TARGET ${target} POST_BUILD
        COMMAND ${CMAKE_COMMAND} -E copy_if_different
                "${CMAKE_CURRENT_SOURCE_DIR}/yt-dlp.exe"
                "$<TARGET_FILE_DIR:${target}>/yt-dlp.exe"
        COMMENT "Copying yt-dlp.exe"
    )

    # Copy the vendored ONNX Runtime runtime DLLs (DML-enabled) next to the exe.
    add_custom_command(TARGET ${target} POST_BUILD
        COMMAND ${CMAKE_COMMAND} -E copy_directory
                "${CMAKE_CURRENT_SOURCE_DIR}/third_party/onnxruntime/lib"
                "$<TARGET_FILE_DIR:${target}>"
        COMMENT "Copying ONNX Runtime + DirectML DLLs"
    )
endfunction()
