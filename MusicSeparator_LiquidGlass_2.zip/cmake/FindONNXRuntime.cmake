# Locates the vendored official ONNX Runtime (DirectML-enabled) package
# and defines the imported target ONNXRUNTIME::ONNXRUNTIME.
#
# Layout expected under third_party/onnxruntime:
#   include/onnxruntime_cxx_api.h  (headers)
#   lib/onnxruntime.lib            (import library)
#   lib/onnxruntime.dll            (runtime)
#   lib/onnxruntime_providers_shared.dll
#   lib/DirectML.dll               (GPU acceleration)

set(MS_ONNXRUNTIME_DIR "" CACHE PATH "Path to the vendored ONNX Runtime package")

if(NOT MS_ONNXRUNTIME_DIR)
    set(MS_ONNXRUNTIME_DIR "${CMAKE_CURRENT_SOURCE_DIR}/third_party/onnxruntime")
endif()

if(NOT EXISTS "${MS_ONNXRUNTIME_DIR}/include/onnxruntime_cxx_api.h" OR
   NOT EXISTS "${MS_ONNXRUNTIME_DIR}/lib/onnxruntime.lib")
    message(FATAL_ERROR
        "ONNX Runtime was not found in ${MS_ONNXRUNTIME_DIR}. "
        "Download the official Microsoft.ML.OnnxRuntime.DirectML package and "
        "place headers + libs in third_party/onnxruntime/ (see README).")
endif()

add_library(ONNXRUNTIME::ONNXRUNTIME SHARED IMPORTED)
set_target_properties(ONNXRUNTIME::ONNXRUNTIME PROPERTIES
    INTERFACE_INCLUDE_DIRECTORIES "${MS_ONNXRUNTIME_DIR}/include"
    IMPORTED_IMPLIB "${MS_ONNXRUNTIME_DIR}/lib/onnxruntime.lib"
    IMPORTED_LOCATION "${MS_ONNXRUNTIME_DIR}/lib/onnxruntime.dll")

set(ONNXRUNTIME_FOUND TRUE)
