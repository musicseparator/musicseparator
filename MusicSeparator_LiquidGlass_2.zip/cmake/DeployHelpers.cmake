# Post-build deployment for MusicSeparator.exe
#
# 1. Runs windeployqt so Qt plugins (platforms/qwindows.dll, multimedia
#    backends, image formats...) end up next to the exe.
# 2. Copies the models/ folder when present.
# 3. Copies yt-dlp.exe when present.
# 4. Copies vendored ONNX Runtime / DirectML runtime files when present.

function(ms_deploy target)
    if(NOT WIN32)
        return()
    endif()

    # Some vcpkg Qt builds do not export a Qt6::windeployqt CMake target.
    # First try that target, then locate windeployqt.exe in vcpkg/Qt tools.
    set(_windeployqt "")

    if(TARGET Qt6::windeployqt)
        set(_windeployqt "$<TARGET_FILE:Qt6::windeployqt>")
    else()
        set(_qt_tool_hints "")

        if(DEFINED VCPKG_INSTALLED_DIR AND DEFINED VCPKG_TARGET_TRIPLET)
            list(APPEND _qt_tool_hints
                "${VCPKG_INSTALLED_DIR}/${VCPKG_TARGET_TRIPLET}/tools/Qt6/bin"
                "${VCPKG_INSTALLED_DIR}/${VCPKG_TARGET_TRIPLET}/tools/Qt6"
            )
        endif()

        if(TARGET Qt6::qmake)
            get_target_property(_qt_qmake_exe Qt6::qmake IMPORTED_LOCATION)
            if(_qt_qmake_exe)
                get_filename_component(_qt_qmake_dir "${_qt_qmake_exe}" DIRECTORY)
                list(APPEND _qt_tool_hints "${_qt_qmake_dir}")
            endif()
        endif()

        find_program(_windeployqt_exe
            NAMES windeployqt windeployqt.exe
            HINTS ${_qt_tool_hints}
        )

        if(_windeployqt_exe)
            set(_windeployqt "${_windeployqt_exe}")
        endif()
    endif()

    if(_windeployqt)
        add_custom_command(TARGET ${target} POST_BUILD
            COMMAND "${_windeployqt}"
                    --no-translations
                    --no-opengl-sw
                    "$<IF:$<CONFIG:Debug>,--debug,--release>"
                    "$<TARGET_FILE:${target}>"
            COMMENT "Deploying Qt runtime next to the executable"
            VERBATIM
        )
    else()
        message(WARNING
            "windeployqt.exe was not found. The application can still be built, "
            "but Qt runtime/plugin deployment will be skipped."
        )
    endif()

    # Copy models directory only when it actually exists.
    if(EXISTS "${CMAKE_CURRENT_SOURCE_DIR}/models")
        add_custom_command(TARGET ${target} POST_BUILD
            COMMAND ${CMAKE_COMMAND} -E copy_directory
                    "${CMAKE_CURRENT_SOURCE_DIR}/models"
                    "$<TARGET_FILE_DIR:${target}>/models"
            COMMENT "Copying models folder"
            VERBATIM
        )
    endif()

    # Copy yt-dlp.exe only when present in the source tree.
    if(EXISTS "${CMAKE_CURRENT_SOURCE_DIR}/yt-dlp.exe")
        add_custom_command(TARGET ${target} POST_BUILD
            COMMAND ${CMAKE_COMMAND} -E copy_if_different
                    "${CMAKE_CURRENT_SOURCE_DIR}/yt-dlp.exe"
                    "$<TARGET_FILE_DIR:${target}>/yt-dlp.exe"
            COMMENT "Copying yt-dlp.exe"
            VERBATIM
        )
    endif()

    # Copy vendored ONNX Runtime / DirectML files only when the folder exists.
    if(EXISTS "${CMAKE_CURRENT_SOURCE_DIR}/third_party/onnxruntime/lib")
        add_custom_command(TARGET ${target} POST_BUILD
            COMMAND ${CMAKE_COMMAND} -E copy_directory
                    "${CMAKE_CURRENT_SOURCE_DIR}/third_party/onnxruntime/lib"
                    "$<TARGET_FILE_DIR:${target}>"
            COMMENT "Copying ONNX Runtime + DirectML runtime files"
            VERBATIM
        )
    endif()
endfunction()
