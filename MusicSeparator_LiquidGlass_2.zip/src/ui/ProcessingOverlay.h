#pragma once

#include <QGraphicsOpacityEffect>
#include <QPropertyAnimation>
#include <QWidget>

class QLabel;
class QProgressBar;
class QPushButton;

namespace mc {

// Full-window overlay shown during separation: "Separating your
// track..." with progress bar, percent, current stage and Cancel.
// The UI thread keeps running underneath.
class ProcessingOverlay : public QWidget
{
    Q_OBJECT
public:
    explicit ProcessingOverlay(QWidget* parent = nullptr);

    void begin(const QString& title);
    void setProgress(int percent, const QString& stage);
    void end();

    bool active() const { return m_active; }

signals:
    void cancelClicked();

protected:
    void paintEvent(QPaintEvent* event) override;

private:
    bool m_active = false;
    QLabel* m_title = nullptr;
    QLabel* m_stage = nullptr;
    QLabel* m_percent = nullptr;
    QProgressBar* m_bar = nullptr;
    QPushButton* m_cancelBtn = nullptr;
    QGraphicsOpacityEffect* m_effect = nullptr;
    QPropertyAnimation* m_anim = nullptr;
};

} // namespace mc
