#pragma once

#include <QPushButton>
#include <QSlider>
#include <QWidget>

class QLabel;

namespace mc {

// Play/Pause + time readout + seek slider, used both on the track page
// (before separation) and on the mix page (master transport).
class TransportBar : public QWidget
{
    Q_OBJECT
public:
    explicit TransportBar(QWidget* parent = nullptr);

    void setDuration(double seconds);
    void setPosition(double seconds);
    void setPlaying(bool playing);
    double duration() const { return m_duration; }

signals:
    void playPauseClicked();
    void seekRequested(double seconds);

private:
    QPushButton* m_playBtn = nullptr;
    QLabel* m_timeLabel = nullptr;
    QSlider* m_slider = nullptr;
    double m_duration = 0.0;
    bool m_seeking = false;
};

} // namespace mc
