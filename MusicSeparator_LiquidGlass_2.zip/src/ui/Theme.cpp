#include "ui/Theme.h"
#include <QApplication>
#include <QFile>
#include <QFont>
#include <QIconEngine>
#include <QPainter>
#include <QPainterPath>
#include <QPalette>
#include <QSettings>
#include <QWidget>
#include <algorithm>
#include <cmath>

namespace mc {
namespace {
class LineIcon final : public QIconEngine {
public:
    LineIcon(QString name, bool accent) : m_name(std::move(name)), m_accent(accent) {}
    QIconEngine* clone() const override { return new LineIcon(m_name, m_accent); }
    void paint(QPainter* p, const QRect& rect, QIcon::Mode mode, QIcon::State) override {
        p->save(); p->setRenderHint(QPainter::Antialiasing);
        const int side = std::min(rect.width(), rect.height());
        p->translate(rect.center().x()-side/2.0, rect.center().y()-side/2.0);
        p->scale(side/24.0, side/24.0);
        const auto palette = qApp->palette();
        const auto role = m_accent ? QPalette::HighlightedText : QPalette::WindowText;
        const QColor color = palette.color(mode == QIcon::Disabled ? QPalette::Disabled : QPalette::Active, role);
        p->setPen(QPen(color, 1.65, Qt::SolidLine, Qt::RoundCap, Qt::RoundJoin));
        p->setBrush(Qt::NoBrush);
        if (m_name == "play") {
            QPainterPath path; path.moveTo(9,5); path.lineTo(19,12); path.lineTo(9,19); path.closeSubpath();
            p->fillPath(path,color);
        } else if (m_name == "pause") {
            p->fillRect(QRectF(7,5,3,14),color); p->fillRect(QRectF(14,5,3,14),color);
        } else if (m_name == "new") {
            p->drawLine(12,5,12,19); p->drawLine(5,12,19,12);
        } else if (m_name == "folder") {
            QPainterPath path; path.moveTo(3,7); path.lineTo(3,19); path.lineTo(21,19); path.lineTo(21,8); path.lineTo(11,8); path.lineTo(9,5); path.lineTo(3,5); path.closeSubpath(); p->drawPath(path);
        } else if (m_name == "export") {
            p->drawLine(12,3,12,15); p->drawLine(8,11,12,15); p->drawLine(12,15,16,11);
            QPainterPath path; path.moveTo(4,15); path.lineTo(4,20); path.lineTo(20,20); path.lineTo(20,15); p->drawPath(path);
        } else if (m_name == "settings") {
            for (int i=0;i<3;++i) { int y=6+i*6, x=i==1?15:9; p->drawLine(4,y,20,y); p->setBrush(palette.window()); p->drawEllipse(QPointF(x,y),2.5,2.5); }
        } else if (m_name == "appearance") {
            p->drawEllipse(QRectF(4,4,16,16)); QPainterPath path; path.moveTo(12,4); path.arcTo(QRectF(4,4,16,16),90,180); path.closeSubpath(); p->fillPath(path,color);
        } else if (m_name == "back") {
            p->drawLine(5,12,19,12); p->drawLine(5,12,11,6); p->drawLine(5,12,11,18);
        } else if (m_name == "video") {
            p->drawRoundedRect(QRectF(3,6,13,12),2,2); p->drawLine(16,9,21,6); p->drawLine(21,6,21,18); p->drawLine(21,18,16,15);
        } else if (m_name == "mute") {
            QPainterPath path; path.moveTo(4,9); path.lineTo(8,9); path.lineTo(12,5); path.lineTo(12,19); path.lineTo(8,15); path.lineTo(4,15); path.closeSubpath(); p->drawPath(path);
            p->drawLine(16,9,21,15); p->drawLine(16,15,21,9);
        } else {
            const int heights[]{7,13,19,11,5};
            for (int i=0;i<5;++i) p->drawLine(QPointF(4+i*4,12-heights[i]/2.0),QPointF(4+i*4,12+heights[i]/2.0));
        }
        p->restore();
    }
    QPixmap pixmap(const QSize& size, QIcon::Mode mode, QIcon::State state) override {
        QPixmap pm(size); pm.fill(Qt::transparent); QPainter p(&pm); paint(&p,QRect(QPoint(),size),mode,state); return pm;
    }
private:
    QString m_name; bool m_accent;
};
}
const QVector<ColorPreset>& Theme::presets() {
    static const QVector<ColorPreset> values{
        {"mint", "Sky Mint / Graphite", "#25272C", "#B8F7E4"},
        {"orchid", "Electric Orchid / Deep Plum", "#2E0F35", "#E46CFF"},
        {"vanilla", "Burnt Orange / Vanilla", "#FFF4D6", "#FC6C26"},
        {"violet", "Neon Lime / Violet Ink", "#2D1B69", "#C8FF3D"},
        {"olive-lime", "Warm Lime / Olive Ink", "#2F3A1D", "#CFFF74"},
        {"compute", "Deep Graphite / Lime Compute", "#1F2329", "#B6FF2E"},
        {"champagne", "Emerald Ink / Champagne", "#F8E7C9", "#064E3B"},
        {"spark", "Lime Spark / Graphite", "#23262F", "#B6FF2E"},
        {"ghost", "Zero Black / Ghost Green", "#050505", "#D7FFE0"},
        {"sage", "Deep Teal / Soft Sage", "#152D35", "#D4ECDD"}
    }; return values;
}
Theme& Theme::instance() { static Theme theme; return theme; }
Appearance Theme::current() { return instance().m_appearance; }
bool Theme::dark() { return current().theme == QStringLiteral("dark"); }
QColor Theme::accent() { return qApp->palette().highlight().color(); }
QIcon Theme::icon(const QString& name, bool onAccent) { return QIcon(new LineIcon(name,onAccent)); }
void Theme::load() {
    QSettings s; Appearance a;
    a.preset=s.value("appearance/preset",a.preset).toString();
    a.glass=s.value("appearance/glass",a.glass).toBool();
    a.theme=s.value("appearance/theme",a.theme).toString();
    a.accent=s.value("appearance/accent",a.accent).toString();
    a.textSize=s.value("appearance/textSize",a.textSize).toInt();
    a.compact=s.value("appearance/compact",a.compact).toBool();
    a.controlsRight=s.value("appearance/controlsRight",a.controlsRight).toBool();
    a.coloredControls=s.value("appearance/coloredControls",a.coloredControls).toBool();
    apply(a);
}
void Theme::apply(Appearance a, bool save) {
    a.textSize=std::clamp(a.textSize,12,15);
    if (a.theme != "dark") a.theme="light";
    const ColorPreset* selected=nullptr;
    for(const auto& preset:presets()) if(preset.id==a.preset) selected=&preset;
    if(selected) a.theme=QColor(selected->background).lightnessF()<.5?"dark":"light";
    else a.preset="custom";
    instance().m_appearance=a;
    const bool d=dark();
    QString bg=d?"#1b1d1b":"#f5f4f0", surface=d?"#242623":"#ffffff";
    QString ink=d?"#e8e9e4":"#282c28", muted=d?"#aaafa5":"#696f66";
    QString border=d?"#3b3f38":"#dddfd7", hover=d?"#30342e":"#eeefe9";
    QString accent=d?"#c9d0c2":"#343d32";
    if(a.accent=="olive") accent=d?"#b5c39b":"#596746";
    if(a.accent=="slate") accent=d?"#a6bbc8":"#4b6574";
    if(a.accent=="sand") accent=d?"#cfbca1":"#7d6547";
    if(selected) {
        bg=selected->background; accent=selected->accent;
        surface=QColor(bg).lighter(d?135:103).name();
        hover=QColor(bg).lighter(d?160:96).name();
        border=d?"#666b70":"#b3b3a3";
        ink=d?"#f3f5f4":"#242921"; muted=d?"#bbc3c0":"#596153";
    }
    // Pick the higher-contrast foreground, including bright orange accents.
    auto linear=[](double x) { return x<=.04045?x/12.92:std::pow((x+.055)/1.055,2.4); };
    QColor ac(accent);
    double luminance=.2126*linear(ac.redF())+.7152*linear(ac.greenF())+.0722*linear(ac.blueF());
    const QString onAccent=luminance>.179?"#101713":"#ffffff";
    auto rgba=[](QColor c,int alpha) { return QString("rgba(%1,%2,%3,%4)").arg(c.red()).arg(c.green()).arg(c.blue()).arg(alpha); };
    const QString glass=a.glass?QString("qlineargradient(x1:0,y1:0,x2:0.3,y2:1,stop:0 %1,stop:0.48 %2,stop:1 %3)")
        .arg(rgba(d?QColor("#ffffff"):QColor(surface),d?24:210),rgba(QColor(surface),d?130:160),rgba(QColor(surface),d?180:195)):surface;
    const QString rim=a.glass?(d?"rgba(255,255,255,48)":"rgba(255,255,255,230)"):border;
    QPalette p;
    p.setColor(QPalette::Window,QColor(bg)); p.setColor(QPalette::Base,QColor(surface));
    p.setColor(QPalette::AlternateBase,QColor(hover)); p.setColor(QPalette::WindowText,QColor(ink));
    p.setColor(QPalette::Text,QColor(ink)); p.setColor(QPalette::Button,QColor(surface));
    p.setColor(QPalette::ButtonText,QColor(ink)); p.setColor(QPalette::Mid,QColor(border));
    p.setColor(QPalette::PlaceholderText,QColor(muted)); p.setColor(QPalette::Highlight,QColor(accent));
    p.setColor(QPalette::HighlightedText,QColor(onAccent)); p.setColor(QPalette::ToolTipBase,QColor(surface));
    p.setColor(QPalette::ToolTipText,QColor(ink));
    p.setColor(QPalette::Disabled,QPalette::Text,QColor(muted));
    p.setColor(QPalette::Disabled,QPalette::WindowText,QColor(muted));
    p.setColor(QPalette::Disabled,QPalette::ButtonText,QColor(muted));
    qApp->setPalette(p);
    QFont font(QStringLiteral("Segoe UI")); font.setPixelSize(a.textSize); qApp->setFont(font);
    QFile file(":/style.qss");
    if(file.open(QIODevice::ReadOnly)) {
        QString qss=QString::fromUtf8(file.readAll());
        qss.replace("@glass",glass).replace("@rim",rim).replace("@bg",bg).replace("@surface",surface).replace("@ink",ink).replace("@muted",muted)
           .replace("@border",border).replace("@hover",hover).replace("@onAccent",onAccent).replace("@accent",accent)
           .replace("@arrow",d?":/icons/chevron-dark.png":":/icons/chevron-light.png")
           .replace("@check",d?":/icons/check-dark.png":":/icons/check-light.png")
           .replace("@font",QString::number(a.textSize)).replace("@pad",a.compact?"6":"9");
        qApp->setStyleSheet(qss);
    }
    if(save) {
        QSettings s; s.setValue("appearance/preset",a.preset); s.setValue("appearance/glass",a.glass); s.setValue("appearance/theme",a.theme); s.setValue("appearance/accent",a.accent);
        s.setValue("appearance/textSize",a.textSize); s.setValue("appearance/compact",a.compact);
        s.setValue("appearance/controlsRight",a.controlsRight); s.setValue("appearance/coloredControls",a.coloredControls);
    }
    emit instance().changed();
    for(auto* w:QApplication::allWidgets()) w->update();
}
}
