#pragma once

#include "export/ExportFormat.h"
#include "separation/SeparationTypes.h"
#include "ui/TrackCard.h"
#include "ui/TransportBar.h"

#include <QColor>
#include <QComboBox>
#include <QWidget>

class QPushButton;
class QVBoxLayout;

namespace mc {

// Mini mixing console: master transport + one TrackCard per stem.
class MixConsoleWidget : public QWidget
{
    Q_OBJECT
public:
    explicit MixConsoleWidget(QWidget* parent = nullptr);

    void setStems(const QVector<StemResult>& stems);
    void clear();

    void setPosition(double seconds);
    void setDuration(double seconds);
    void setPlaying(bool playing);

signals:
    void playPauseClicked();
    void seekRequested(double seconds);

    void trackPlayClicked(int index);
    void trackMuteChanged(int index, bool muted);
    void trackSoloChanged(int index, bool solo);
    void trackGainChanged(int index, float gain);
    void trackExportClicked(int index);

    void exportAllClicked(mc::ExportFormat format);
    void openOutputFolderRequested();

private:
    TransportBar* m_transport = nullptr;
    QComboBox* m_formatCombo = nullptr;
    QPushButton* m_exportAllBtn = nullptr;
    QPushButton* m_openFolderBtn = nullptr;
    QVBoxLayout* m_cardsLayout = nullptr;
    QVector<TrackCard*> m_cards;

    static QColor colorFor(int index);
};

} // namespace mc
