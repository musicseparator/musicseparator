#pragma once
#include <QObject>
#include <QColor>
#include <QIcon>
#include <QString>
#include <QVector>

namespace mc {
struct Appearance {
    QString theme = QStringLiteral("light");
    QString accent = QStringLiteral("graphite");
    QString preset = QStringLiteral("custom");
    bool glass = true;
    int textSize = 13;
    bool compact = false;
    bool controlsRight = false;
    bool coloredControls = true;
};
struct ColorPreset { QString id, name, background, accent; };
class Theme : public QObject {
    Q_OBJECT
public:
    static Theme& instance();
    static const QVector<ColorPreset>& presets();
    static Appearance current();
    static void load();
    static void apply(Appearance appearance, bool save = false);
    static QColor accent();
    static QIcon icon(const QString& name, bool onAccent = false);
    static bool dark();
signals:
    void changed();
private:
    Appearance m_appearance;
};
}
