#include "ui/AppearanceDialog.h"
#include "ui/Theme.h"
#include <QCheckBox>
#include <QComboBox>
#include <QDialogButtonBox>
#include <QFormLayout>
#include <QLabel>
#include <QPushButton>
#include <QStyle>
#include <QPainter>
#include <QVBoxLayout>
namespace mc {
AppearanceDialog::AppearanceDialog(QWidget* parent) : QDialog(parent) {
    setWindowTitle(tr("Appearance")); setMinimumWidth(580); setModal(true);
    auto original=Theme::current();
    auto* root=new QVBoxLayout(this); root->setContentsMargins(28,26,28,24); root->setSpacing(20);
    auto* title=new QLabel(tr("Make it your workspace"),this); title->setObjectName("cardTitle"); root->addWidget(title);
    auto* hint=new QLabel(tr("Changes preview immediately. Save to keep them."),this); hint->setObjectName("metaLabel"); root->addWidget(hint);
    auto* form=new QFormLayout; form->setSpacing(16); form->setFieldGrowthPolicy(QFormLayout::AllNonFixedFieldsGrow);
    auto* presets=new QComboBox(this); presets->setIconSize(QSize(52,22));
    presets->addItem(tr("Personalized neutral"),"custom");
    for(const auto& item:Theme::presets()) {
        QPixmap swatch(52,22); swatch.fill(Qt::transparent); QPainter painter(&swatch);
        painter.setRenderHint(QPainter::Antialiasing); painter.setPen(Qt::NoPen);
        painter.setBrush(QColor(item.background)); painter.drawRoundedRect(0,0,52,22,6,6);
        painter.setBrush(QColor(item.accent)); painter.drawRoundedRect(26,2,24,18,5,5); painter.end();
        presets->addItem(QIcon(swatch),item.name,item.id);
    }
    presets->setCurrentIndex(qMax(0,presets->findData(original.preset)));
    auto* hex=new QLabel(this); hex->setObjectName("metaLabel");
    auto* glass=new QCheckBox(tr("Liquid Glass · translucent surfaces and reflections"),this); glass->setChecked(original.glass);
    auto* theme=new QComboBox(this); theme->addItem(tr("Light · Stone"),"light"); theme->addItem(tr("Dark · Charcoal"),"dark"); theme->setCurrentIndex(theme->findData(original.theme));
    auto* accent=new QComboBox(this); accent->addItem(tr("Graphite"),"graphite"); accent->addItem(tr("Olive"),"olive"); accent->addItem(tr("Slate"),"slate"); accent->addItem(tr("Sand"),"sand"); accent->setCurrentIndex(qMax(0,accent->findData(original.accent)));
    auto* size=new QComboBox(this); for(int i=12;i<=15;++i) size->addItem(QString::number(i)+" px",i); size->setCurrentIndex(size->findData(original.textSize));
    auto* density=new QComboBox(this); density->addItem(tr("Comfortable"),false); density->addItem(tr("Compact"),true); density->setCurrentIndex(original.compact?1:0);
    auto* position=new QComboBox(this); position->addItem(tr("Left · macOS style"),false); position->addItem(tr("Right"),true); position->setCurrentIndex(original.controlsRight?1:0);
    auto* color=new QCheckBox(tr("Colored window controls"),this); color->setChecked(original.coloredControls);
    form->addRow(tr("Color combination"),presets); form->addRow(QString(),hex); form->addRow(QString(),glass);
    form->addRow(tr("Neutral theme"),theme); form->addRow(tr("Accent"),accent); form->addRow(tr("Text size"),size); form->addRow(tr("Spacing"),density); form->addRow(tr("Window controls"),position); form->addRow(QString(),color); root->addLayout(form);
    const auto read=[=] { Appearance a; a.preset=presets->currentData().toString(); a.glass=glass->isChecked(); a.theme=theme->currentData().toString(); a.accent=accent->currentData().toString(); a.textSize=size->currentData().toInt(); a.compact=density->currentData().toBool(); a.controlsRight=position->currentData().toBool(); a.coloredControls=color->isChecked(); return a; };
    auto sync=[=] {
        bool custom=presets->currentData().toString()=="custom";
        theme->setEnabled(custom); accent->setEnabled(custom);
        hex->setText(tr("Choose a neutral theme and accent below."));
        for(const auto& item:Theme::presets()) if(item.id==presets->currentData().toString())
            hex->setText(tr("Background %1   /   Accent %2").arg(item.background,item.accent));
    }; sync();
    connect(presets,&QComboBox::currentIndexChanged,this,sync);
    const auto preview=[read] { Theme::apply(read()); };
    for(auto* combo:{presets,theme,accent,size,density,position}) connect(combo,&QComboBox::currentIndexChanged,this,preview);
    connect(glass,&QCheckBox::toggled,this,preview);
    connect(color,&QCheckBox::toggled,this,preview);
    auto* buttons=new QDialogButtonBox(QDialogButtonBox::Save|QDialogButtonBox::Cancel|QDialogButtonBox::RestoreDefaults,this);
    buttons->button(QDialogButtonBox::Save)->setObjectName("primaryButton");
    buttons->button(QDialogButtonBox::Save)->style()->unpolish(buttons->button(QDialogButtonBox::Save));
    buttons->button(QDialogButtonBox::Save)->style()->polish(buttons->button(QDialogButtonBox::Save)); root->addWidget(buttons);
    connect(buttons,&QDialogButtonBox::accepted,this,[this,read] { Theme::apply(read(),true); accept(); });
    connect(buttons,&QDialogButtonBox::rejected,this,&QDialog::reject);
    connect(this,&QDialog::rejected,this,[original] { Theme::apply(original); });
    connect(buttons->button(QDialogButtonBox::RestoreDefaults),&QPushButton::clicked,this,[=] {
        presets->setCurrentIndex(0); glass->setChecked(true); theme->setCurrentIndex(0); accent->setCurrentIndex(0); size->setCurrentIndex(1); density->setCurrentIndex(0); position->setCurrentIndex(0); color->setChecked(true); preview();
    });
}
}
