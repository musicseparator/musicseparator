#pragma once

#include "separation/SeparationTypes.h"
#include "ui/WaveformWidget.h"

#include <QFrame>

class QLabel;
class QPushButton;
class QSlider;

namespace mc {

// One mixer channel: waveform, Play, Mute, Solo, volume, Export.
class TrackCard : public QFrame
{
    Q_OBJECT
public:
    explicit TrackCard(int index, QWidget* parent = nullptr);

    void setStem(const StemResult& result, const QColor& color);
    void setPlayheadFraction(double fraction);
    void setTransportPlaying(bool playing);
    int index() const { return m_index; }

signals:
    void playClicked(int index);
    void muteChanged(int index, bool muted);
    void soloChanged(int index, bool solo);
    void gainChanged(int index, float gain);
    void exportClicked(int index);

private:
    int m_index;
    WaveformWidget* m_wave = nullptr;
    QPushButton* m_playBtn = nullptr;
    QPushButton* m_muteBtn = nullptr;
    QPushButton* m_soloBtn = nullptr;
    QPushButton* m_exportBtn = nullptr;
    QSlider* m_volume = nullptr;
    QLabel* m_name = nullptr;
};

} // namespace mc
