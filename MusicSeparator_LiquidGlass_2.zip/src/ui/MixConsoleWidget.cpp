#include "ui/Theme.h"
#include "ui/MixConsoleWidget.h"

#include <QHBoxLayout>
#include <QIcon>
#include <QLabel>
#include <QPushButton>
#include <QScrollArea>
#include <QVBoxLayout>

namespace mc {

namespace {


} // namespace

MixConsoleWidget::MixConsoleWidget(QWidget* parent)
    : QWidget(parent)
{
    auto* root = new QVBoxLayout(this);
    root->setContentsMargins(24, 12, 24, 12);
    root->setSpacing(18);

    // Toolbar: master transport + export row.
    auto* toolbar = new QHBoxLayout();
    toolbar->setSpacing(10);

    auto* title = new QLabel(tr("Transport"), this);
    title->setObjectName(QStringLiteral("cardTitle"));
    title->setStyleSheet(QStringLiteral("font-size:14px;font-weight:600;"));
    toolbar->addWidget(title);
    toolbar->addSpacing(12);

    m_transport = new TransportBar(this);
    toolbar->addWidget(m_transport, 1);

    m_formatCombo = new QComboBox(this);
    m_formatCombo->addItem(QStringLiteral("WAV"), static_cast<int>(ExportFormat::Wav));
    m_formatCombo->addItem(QStringLiteral("MP3"), static_cast<int>(ExportFormat::Mp3));
    m_formatCombo->addItem(QStringLiteral("FLAC"), static_cast<int>(ExportFormat::Flac));
    toolbar->addWidget(m_formatCombo);

    m_exportAllBtn = new QPushButton(tr("Export tracks"), this);
    m_exportAllBtn->setObjectName(QStringLiteral("primaryButton"));
    toolbar->addWidget(m_exportAllBtn);

    m_openFolderBtn = new QPushButton(this);
    m_openFolderBtn->setObjectName(QStringLiteral("iconBtn"));
    m_openFolderBtn->setIcon(Theme::icon(QStringLiteral("folder")));
    m_openFolderBtn->setIconSize(QSize(15, 15));
    m_openFolderBtn->setToolTip(tr("Open output folder"));
    toolbar->addWidget(m_openFolderBtn);

    root->addLayout(toolbar);

    auto* scroll = new QScrollArea(this);
    scroll->setWidgetResizable(true);
    scroll->setFrameShape(QFrame::NoFrame);
    auto* container = new QWidget(scroll);
    m_cardsLayout = new QVBoxLayout(container);
    m_cardsLayout->setContentsMargins(0, 0, 8, 0);
    m_cardsLayout->setSpacing(8);
    m_cardsLayout->addStretch(1);
    scroll->setWidget(container);
    root->addWidget(scroll, 1);

    connect(m_transport, &TransportBar::playPauseClicked, this, &MixConsoleWidget::playPauseClicked);
    connect(m_transport, &TransportBar::seekRequested, this, &MixConsoleWidget::seekRequested);
    connect(m_exportAllBtn, &QPushButton::clicked, this, [this] {
        emit exportAllClicked(static_cast<ExportFormat>(m_formatCombo->currentData().toInt()));
    });
    connect(m_openFolderBtn, &QPushButton::clicked, this, &MixConsoleWidget::openOutputFolderRequested);
}

QColor MixConsoleWidget::colorFor(int index)
{
    Q_UNUSED(index);
    return Theme::accent();
}

void MixConsoleWidget::setStems(const QVector<StemResult>& stems)
{
    clear();
    for (int i = 0; i < stems.size(); ++i) {
        auto* card = new TrackCard(i, this);
        card->setStem(stems[i], colorFor(i));
        m_cardsLayout->insertWidget(m_cardsLayout->count() - 1, card);

        connect(card, &TrackCard::playClicked, this, &MixConsoleWidget::trackPlayClicked);
        connect(card, &TrackCard::muteChanged, this, &MixConsoleWidget::trackMuteChanged);
        connect(card, &TrackCard::soloChanged, this, &MixConsoleWidget::trackSoloChanged);
        connect(card, &TrackCard::gainChanged, this, &MixConsoleWidget::trackGainChanged);
        connect(card, &TrackCard::exportClicked, this, &MixConsoleWidget::trackExportClicked);
        m_cards.append(card);
    }
    m_transport->setDuration(stems.isEmpty() ? 0.0 : stems.first().buffer.durationSeconds());
    m_transport->setPosition(0.0);
}

void MixConsoleWidget::clear()
{
    for (TrackCard* card : m_cards) {
        m_cardsLayout->removeWidget(card);
        card->deleteLater();
    }
    m_cards.clear();
}

void MixConsoleWidget::setPosition(double seconds)
{
    m_transport->setPosition(seconds);
    for (TrackCard* card : m_cards)
        card->setPlayheadFraction(m_transport->duration() > 0.0
                                      ? seconds / m_transport->duration()
                                      : 0.0);
}

void MixConsoleWidget::setDuration(double seconds)
{
    m_transport->setDuration(seconds);
}

void MixConsoleWidget::setPlaying(bool playing)
{
    m_transport->setPlaying(playing);
    for (TrackCard* card : m_cards)
        card->setTransportPlaying(playing);
}

} // namespace mc
