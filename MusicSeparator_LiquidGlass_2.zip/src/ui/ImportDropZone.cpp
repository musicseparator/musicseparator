#include "ui/ImportDropZone.h"
#include "ui/Theme.h"
#include <QApplication>
#include <QDragEnterEvent>
#include <QDragLeaveEvent>
#include <QDropEvent>
#include <QHBoxLayout>
#include <QLabel>
#include <QLineEdit>
#include <QMimeData>
#include <QPainter>
#include <QPushButton>
#include <QVBoxLayout>
namespace mc {
ImportDropZone::ImportDropZone(QWidget* parent) : QWidget(parent) {
    setAcceptDrops(true); setMinimumSize(600,430);
    auto* root=new QVBoxLayout(this); root->setContentsMargins(40,36,40,36); root->setSpacing(14); root->addStretch();
    auto* eyebrow=new QLabel(tr("AUDIO WORKSPACE"),this); eyebrow->setObjectName("eyebrow"); eyebrow->setAlignment(Qt::AlignCenter); root->addWidget(eyebrow);
    m_title=new QLabel(tr("Start a new session"),this); m_title->setObjectName("pageTitle"); m_title->setAlignment(Qt::AlignCenter); root->addWidget(m_title);
    auto* description=new QLabel(tr("Separate your recording into individual voices and instruments."),this); description->setObjectName("metaLabel"); description->setWordWrap(true); description->setAlignment(Qt::AlignCenter); root->addWidget(description);
    root->addSpacing(20);
    auto* icon=new QLabel(this); icon->setAlignment(Qt::AlignCenter);
    auto refresh=[icon] { icon->setPixmap(Theme::icon("music").pixmap(QSize(42,42))); };
    connect(&Theme::instance(),&Theme::changed,icon,refresh); refresh(); root->addWidget(icon);
    auto* drop=new QLabel(tr("Drop an audio or video file here"),this); drop->setAlignment(Qt::AlignCenter); root->addWidget(drop);
    auto* types=new QLabel(QStringLiteral("MP3   WAV   FLAC   M4A   MP4"),this); types->setObjectName("eyebrow"); types->setAlignment(Qt::AlignCenter); root->addWidget(types);
    auto* buttons=new QHBoxLayout; buttons->setSpacing(10); buttons->addStretch();
    auto* audio=new QPushButton(tr("Choose audio file"),this); audio->setObjectName("primaryButton");
    auto* video=new QPushButton(tr("Import video"),this); video->setObjectName("ghostButton");
    buttons->addWidget(audio); buttons->addWidget(video); buttons->addStretch(); root->addLayout(buttons);
    root->addSpacing(20);
    auto* urlBox=new QWidget(this); urlBox->setFixedWidth(460); auto* row=new QHBoxLayout(urlBox); row->setContentsMargins(0,0,0,0);
    m_urlEdit=new QLineEdit(this); m_urlEdit->setPlaceholderText(tr("Or paste a YouTube link")); m_urlEdit->setAccessibleName(tr("YouTube link")); row->addWidget(m_urlEdit,1);
    auto* urlButton=new QPushButton(tr("Import link"),this); row->addWidget(urlButton); root->addWidget(urlBox,0,Qt::AlignHCenter);
    m_legal=new QLabel(tr("Use recordings you have permission to process."),this); m_legal->setObjectName("metaLabel"); m_legal->setAlignment(Qt::AlignCenter); root->addWidget(m_legal); root->addStretch();
    connect(audio,&QPushButton::clicked,this,&ImportDropZone::importAudioClicked);
    connect(video,&QPushButton::clicked,this,&ImportDropZone::importVideoClicked);
    auto submit=[this] { const auto url=m_urlEdit->text().trimmed(); if(!url.isEmpty()) emit urlSubmitted(url); };
    connect(urlButton,&QPushButton::clicked,this,submit); connect(m_urlEdit,&QLineEdit::returnPressed,this,submit);
}
void ImportDropZone::paintEvent(QPaintEvent*) {
    QPainter p(this); p.setRenderHint(QPainter::Antialiasing);
    p.setPen(QPen(m_dragActive?Theme::accent():palette().color(QPalette::Mid),1));
    QColor fill=qApp->palette().base().color();
    fill.setAlpha(Theme::current().glass?175:255);
    QLinearGradient sheen(0,0,width()*.3,height());
    QColor top=Theme::dark()?QColor(255,255,255,28):QColor(255,255,255,225);
    sheen.setColorAt(0,Theme::current().glass?top:fill); sheen.setColorAt(1,fill);
    p.setBrush(sheen); p.drawRoundedRect(rect().adjusted(1,1,-2,-2),24,24);
}
void ImportDropZone::dragEnterEvent(QDragEnterEvent* event) {
    if(event->mimeData()->hasUrls() && !event->mimeData()->urls().isEmpty() && event->mimeData()->urls().first().isLocalFile()) {
        m_dragActive=true; update(); event->acceptProposedAction();
    }
}
void ImportDropZone::dragLeaveEvent(QDragLeaveEvent* event) { m_dragActive=false; update(); event->accept(); }
void ImportDropZone::dropEvent(QDropEvent* event) {
    m_dragActive=false; update(); const auto urls=event->mimeData()->urls();
    if(urls.isEmpty()) return;
    const auto path=urls.first().toLocalFile();
    if(!path.isEmpty()) { event->acceptProposedAction(); emit fileImported(path); }
}
}
