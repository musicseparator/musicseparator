#include "ui/TrackCard.h"
#include "ui/Theme.h"
#include <QHBoxLayout>
#include <QLabel>
#include <QPushButton>
#include <QSlider>
#include <QVBoxLayout>
namespace mc {
TrackCard::TrackCard(int index,QWidget* parent) : QFrame(parent), m_index(index) {
    setObjectName(QStringLiteral("trackCard"));
    auto* root=new QHBoxLayout(this); root->setContentsMargins(18,14,18,14); root->setSpacing(20);
    auto* identity=new QVBoxLayout; identity->setSpacing(6);
    auto* number=new QLabel(QStringLiteral("TRACK %1").arg(index+1,2,10,QLatin1Char('0')),this);
    number->setObjectName(QStringLiteral("eyebrow")); identity->addWidget(number);
    m_name=new QLabel(this); m_name->setObjectName(QStringLiteral("stemName")); m_name->setMinimumWidth(105); identity->addWidget(m_name);
    root->addLayout(identity);
    m_wave=new WaveformWidget(this); m_wave->setMinimumWidth(180); m_wave->setFixedHeight(62); root->addWidget(m_wave,1);
    auto* controls=new QVBoxLayout; controls->setSpacing(10);
    auto* buttons=new QHBoxLayout; buttons->setSpacing(6);
    m_playBtn=new QPushButton(this); m_playBtn->setObjectName("iconBtn"); m_playBtn->setIcon(Theme::icon("play")); m_playBtn->setCheckable(true);
    m_playBtn->setToolTip(tr("Play / pause all tracks")); m_playBtn->setAccessibleName(tr("Play / pause all tracks"));
    m_muteBtn=new QPushButton(QStringLiteral("M"),this); m_muteBtn->setObjectName("trackToggle"); m_muteBtn->setCheckable(true); m_muteBtn->setToolTip(tr("Mute this track")); m_muteBtn->setAccessibleName(tr("Mute track"));
    m_soloBtn=new QPushButton(QStringLiteral("S"),this); m_soloBtn->setObjectName("trackToggle"); m_soloBtn->setCheckable(true); m_soloBtn->setToolTip(tr("Listen to this track solo")); m_soloBtn->setAccessibleName(tr("Solo track"));
    m_exportBtn=new QPushButton(this); m_exportBtn->setObjectName("iconBtn"); m_exportBtn->setIcon(Theme::icon("export")); m_exportBtn->setToolTip(tr("Export this track")); m_exportBtn->setAccessibleName(tr("Export track"));
    for(auto* button:{m_playBtn,m_muteBtn,m_soloBtn,m_exportBtn}) { button->setIconSize(QSize(16,16)); buttons->addWidget(button); }
    controls->addLayout(buttons);
    auto* volume=new QHBoxLayout; volume->setSpacing(10);
    m_volume=new QSlider(Qt::Horizontal,this); m_volume->setRange(0,150); m_volume->setValue(100); m_volume->setFixedWidth(105); m_volume->setAccessibleName(tr("Track volume"));
    auto* value=new QLabel(QStringLiteral("100%"),this); value->setObjectName("metaLabel"); value->setFixedWidth(38); value->setAlignment(Qt::AlignRight);
    volume->addWidget(m_volume); volume->addWidget(value); controls->addLayout(volume); root->addLayout(controls);
    connect(m_playBtn,&QPushButton::clicked,this,[this] { emit playClicked(m_index); });
    connect(m_muteBtn,&QPushButton::toggled,this,[this](bool on) { emit muteChanged(m_index,on); });
    connect(m_soloBtn,&QPushButton::toggled,this,[this](bool on) { emit soloChanged(m_index,on); });
    connect(m_volume,&QSlider::valueChanged,this,[this,value](int v) { value->setText(QString::number(v)+"%"); emit gainChanged(m_index,v/100.f); });
    connect(m_exportBtn,&QPushButton::clicked,this,[this] { emit exportClicked(m_index); });
    const auto spacing=[this,root] { bool compact=Theme::current().compact; root->setContentsMargins(18,compact?9:14,18,compact?9:14); m_wave->setFixedHeight(compact?50:62); };
    connect(&Theme::instance(),&Theme::changed,this,spacing); spacing();
}
void TrackCard::setStem(const StemResult& result,const QColor& color) {
    m_name->setText(result.displayName); m_wave->setBuffer(&result.buffer); m_wave->setColor(color);
}
void TrackCard::setPlayheadFraction(double fraction) { m_wave->setPlayheadFraction(fraction); }
void TrackCard::setTransportPlaying(bool playing) {
    m_playBtn->blockSignals(true); m_playBtn->setChecked(playing); m_playBtn->blockSignals(false);
    m_playBtn->setIcon(Theme::icon(playing?"pause":"play"));
}
}
