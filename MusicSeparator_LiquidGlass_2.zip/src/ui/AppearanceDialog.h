#pragma once
#include <QDialog>
namespace mc {
class AppearanceDialog : public QDialog {
public:
    explicit AppearanceDialog(QWidget* parent = nullptr);
};
}
