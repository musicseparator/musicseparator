#include "ui/Theme.h"
#include "ui/TransportBar.h"

#include <QHBoxLayout>
#include <QIcon>
#include <QLabel>

namespace mc {

namespace {
QString formatTime(double seconds)
{
    const int total = static_cast<int>(seconds);
    const int m = total / 60;
    const int s = total % 60;
    return QStringLiteral("%1:%2").arg(m).arg(s, 2, 10, QLatin1Char('0'));
}
} // namespace

TransportBar::TransportBar(QWidget* parent)
    : QWidget(parent)
{
    auto* layout = new QHBoxLayout(this);
    layout->setContentsMargins(0, 0, 0, 0);
    layout->setSpacing(10);

    m_playBtn = new QPushButton(this);
    m_playBtn->setObjectName(QStringLiteral("playBtn"));
    m_playBtn->setIcon(Theme::icon(QStringLiteral("play"), true));
    m_playBtn->setIconSize(QSize(14, 14));
    m_playBtn->setCheckable(true);
    m_playBtn->setFixedSize(36, 36);
    m_playBtn->setToolTip(tr("Play / Pause"));
    m_playBtn->setAccessibleName(tr("Play / Pause"));
    layout->addWidget(m_playBtn);

    m_timeLabel = new QLabel(QStringLiteral("0:00 / 0:00"), this);
    m_timeLabel->setObjectName(QStringLiteral("metaLabel"));
    m_timeLabel->setMinimumWidth(120);
    layout->addWidget(m_timeLabel);

    m_slider = new QSlider(Qt::Horizontal, this);
    m_slider->setRange(0, 10000);
    m_slider->setValue(0);
    layout->addWidget(m_slider, 1);

    connect(m_playBtn, &QPushButton::clicked, this, &TransportBar::playPauseClicked);

    connect(m_slider, &QSlider::sliderPressed, this, [this] { m_seeking = true; });
    connect(m_slider, &QSlider::sliderReleased, this, [this] {
        m_seeking = false;
        emit seekRequested(m_duration * (m_slider->value() / 10000.0));
    });
    connect(m_slider, &QSlider::valueChanged, this, [this](int value) {
        if (m_seeking) {
            m_timeLabel->setText(formatTime(m_duration * (value / 10000.0)) +
                                 QStringLiteral(" / ") + formatTime(m_duration));
        }
    });
}

void TransportBar::setDuration(double seconds)
{
    m_duration = seconds;
    if (!m_seeking)
        m_timeLabel->setText(formatTime(0.0) + QStringLiteral(" / ") + formatTime(seconds));
}

void TransportBar::setPosition(double seconds)
{
    if (m_seeking) return;
    if (m_duration > 0.0) {
        m_slider->setValue(static_cast<int>(seconds / m_duration * 10000.0));
        m_timeLabel->setText(formatTime(seconds) + QStringLiteral(" / ") + formatTime(m_duration));
    }
}

// FIX (Bug 2): blockSignals prevents setChecked from re-emitting clicked
// and causing a double-toggle when the engine updates the UI state.
void TransportBar::setPlaying(bool playing)
{
    m_playBtn->blockSignals(true);
    m_playBtn->setChecked(playing);
    m_playBtn->blockSignals(false);
    m_playBtn->setIcon(Theme::icon(playing ? QStringLiteral("pause") : QStringLiteral("play"), true));
}

} // namespace mc
