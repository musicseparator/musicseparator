#include "ui/WaveformWidget.h"
#include "ui/Theme.h"

#include <QMouseEvent>
#include <QPainter>
#include <QPainterPath>

namespace mc {

WaveformWidget::WaveformWidget(QWidget* parent)
    : QWidget(parent)
{
    setMinimumHeight(64);
    setMouseTracking(true);
    setCursor(Qt::PointingHandCursor);
}

void WaveformWidget::setBuffer(const AudioBuffer* buffer)
{
    m_buffer = buffer;
    recomputePeaks();
    update();
}

void WaveformWidget::setColor(const QColor& color)
{
    m_color = color;
    update();
}

void WaveformWidget::setPlayheadFraction(double fraction)
{
    m_playheadFraction = std::clamp(fraction, 0.0, 1.0);
    update();
}

void WaveformWidget::clear()
{
    m_buffer = nullptr;
    m_peaks = WavePeaks{};
    update();
}

double WaveformWidget::fractionAt(int x) const
{
    if (width() <= 0) return 0.0;
    return std::clamp(static_cast<double>(x) / width(), 0.0, 1.0);
}

void WaveformWidget::recomputePeaks()
{
    if (!m_buffer || width() <= 0) {
        m_peaks = WavePeaks{};
        return;
    }
    Waveform::computePeaks(m_buffer->pcm.data(), m_buffer->pcm.size() / m_buffer->channels,
                           m_buffer->channels, width(), &m_peaks);
}

void WaveformWidget::paintEvent(QPaintEvent*)
{
    QPainter p(this);
    p.setRenderHint(QPainter::Antialiasing, true);

    const QRectF bgRect = rect().adjusted(0, 0, -1, -1);
    p.setPen(Qt::NoPen);
    p.setBrush(palette().color(QPalette::AlternateBase));
    p.drawRoundedRect(bgRect, 8, 8);

    if (!m_buffer || m_peaks.width == 0) {
        p.setPen(palette().color(QPalette::PlaceholderText));
        p.drawText(rect(), Qt::AlignCenter, QStringLiteral("No audio"));
        return;
    }

    const int w = width();
    const int h = height();
    const double center = h / 2.0;
    const double half = (h - 10.0) / 2.0;

    const QColor baseColor = Theme::accent();
    QColor fillColor = baseColor;
    fillColor.setAlpha(150);
    QColor playedColor = baseColor;
    playedColor.setAlpha(210);

    // Envelope path (max above center, min below).
    QPainterPath env;
    env.moveTo(0, center - m_peaks.maxVals[0] * half);
    for (int x = 1; x < w; ++x)
        env.lineTo(x, center - m_peaks.maxVals[x] * half);
    for (int x = w - 1; x >= 0; --x)
        env.lineTo(x, center + m_peaks.maxVals[x] * half);
    env.closeSubpath();

    // Played portion clipped on top.
    p.save();
    p.setPen(Qt::NoPen);
    p.setBrush(fillColor);
    p.drawPath(env);

    const double playedX = m_playheadFraction * w;
    p.setClipRect(0, 0, static_cast<int>(playedX), h);
    p.setBrush(playedColor);
    p.drawPath(env);
    p.restore();

    // Center line.
    p.setPen(palette().color(QPalette::Mid));
    p.drawLine(0, static_cast<int>(center), w, static_cast<int>(center));

    // Playhead.
    if (playedX > 0 && playedX < w) {
        p.setPen(palette().color(QPalette::WindowText));
        p.drawLine(static_cast<int>(playedX), 4, static_cast<int>(playedX), h - 4);
    }

    // Hover seek line.
    if (m_hoverActive && m_hoverFraction >= 0.0) {
        const int hx = static_cast<int>(m_hoverFraction * w);
        p.setPen(palette().color(QPalette::PlaceholderText));
        p.drawLine(hx, 2, hx, h - 2);
    }
}

void WaveformWidget::resizeEvent(QResizeEvent* event)
{
    QWidget::resizeEvent(event);
    recomputePeaks();
    update();
}

void WaveformWidget::mousePressEvent(QMouseEvent* event)
{
    if (event->button() != Qt::LeftButton || !m_buffer) return;
    m_seeking = true;
    const double frac = fractionAt(event->position().x());
    m_playheadFraction = frac;
    emit seekRequested(frac);
    update();
}

void WaveformWidget::mouseMoveEvent(QMouseEvent* event)
{
    m_hoverActive = true;
    m_hoverFraction = fractionAt(event->position().x());
    if (m_seeking) {
        const double frac = m_hoverFraction;
        m_playheadFraction = frac;
        emit seekRequested(frac);
    }
    update();
}

void WaveformWidget::mouseReleaseEvent(QMouseEvent* event)
{
    if (event->button() == Qt::LeftButton)
        m_seeking = false;
}

void WaveformWidget::leaveEvent(QEvent* event)
{
    QWidget::leaveEvent(event);
    m_hoverActive = false;
    update();
}

} // namespace mc
