#include "ui/StudioWindow.h"
#include "ui/Theme.h"
#include <QApplication>
#include <QHBoxLayout>
#include <QLabel>
#include <QMouseEvent>
#include <QPainter>
#include <QPushButton>
#include <QWindow>
#ifdef Q_OS_WIN
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>
#include <windowsx.h>
#endif

namespace mc {
namespace {
class WindowControl : public QPushButton {
public:
    explicit WindowControl(int action, QWidget* parent) : QPushButton(parent), m_action(action) {
        setFixedSize(26,30); setFocusPolicy(Qt::StrongFocus);
        const QString names[]{tr("Close window"),tr("Minimize window"),tr("Maximize / Restore window")};
        setToolTip(names[action]); setAccessibleName(names[action]);
        setObjectName(QStringLiteral("windowControl"));
        connect(this,&QPushButton::clicked,this,[this] {
            auto* w=window();
            if(m_action==0) w->close();
            else if(m_action==1) w->showMinimized();
            else if(w->isMaximized()) w->showNormal(); else w->showMaximized();
        });
    }
protected:
    void paintEvent(QPaintEvent*) override {
        QPainter p(this); p.setRenderHint(QPainter::Antialiasing);
        const QColor colors[]{QColor("#d9786b"),QColor("#d6ae59"),QColor("#83a883")};
        QColor c=Theme::current().coloredControls ? colors[m_action] : palette().color(QPalette::Mid);
        if(isDown()) c=c.darker(115);
        p.setPen(QPen(c.darker(112),.7)); p.setBrush(c);
        const QPointF center=rect().center(); p.drawEllipse(center,6,6);
        if(underMouse() || hasFocus()) {
            p.setPen(QPen(Theme::current().coloredControls?QColor("#34382f"):palette().color(QPalette::WindowText),1.2,Qt::SolidLine,Qt::RoundCap));
            const qreal x=center.x(), y=center.y();
            if(m_action==0) { p.drawLine(QPointF(x-2,y-2),QPointF(x+2,y+2)); p.drawLine(QPointF(x+2,y-2),QPointF(x-2,y+2)); }
            else { p.drawLine(QPointF(x-3,y),QPointF(x+3,y)); if(m_action==2) p.drawLine(QPointF(x,y-3),QPointF(x,y+3)); }
        }
        if(hasFocus()) { p.setBrush(Qt::NoBrush); p.setPen(palette().highlight().color()); p.drawEllipse(center,10,10); }
    }
private:
    int m_action;
};
}
StudioWindow::StudioWindow(QWidget* parent) : QMainWindow(parent) {
    setWindowFlags(Qt::Window | Qt::FramelessWindowHint | Qt::WindowMinMaxButtonsHint | Qt::WindowSystemMenuHint);
    setMinimumSize(940,660); setMouseTracking(true);
    qApp->installEventFilter(this);
}
bool StudioWindow::eventFilter(QObject* watched,QEvent* event) {
#ifndef Q_OS_WIN
    // Native Windows hit tests handle the same edges below.
    auto* widget=qobject_cast<QWidget*>(watched);
    if(widget && widget->window()==this && !isMaximized() && event->type()==QEvent::MouseButtonPress) {
        auto* mouse=static_cast<QMouseEvent*>(event);
        const QPoint p=mapFromGlobal(mouse->globalPosition().toPoint());
        Qt::Edges edges;
        if(p.x()<6) edges|=Qt::LeftEdge; else if(p.x()>width()-7) edges|=Qt::RightEdge;
        if(p.y()<6) edges|=Qt::TopEdge; else if(p.y()>height()-7) edges|=Qt::BottomEdge;
        if(edges && mouse->button()==Qt::LeftButton && windowHandle()) return windowHandle()->startSystemResize(edges);
    }
#else
    Q_UNUSED(watched);
    Q_UNUSED(event);
#endif
    return QMainWindow::eventFilter(watched,event);
}
void StudioWindow::paintEvent(QPaintEvent*) {
    QPainter p(this); p.setRenderHint(QPainter::Antialiasing);
    p.fillRect(rect(),qApp->palette().window());
    if(!Theme::current().glass) return;
    // Soft, static light fields behind translucent surfaces; no animation on the audio path.
    const auto glow=[&](QPointF center,qreal radius,QColor color,int alpha) {
        QRadialGradient gradient(center,radius); color.setAlpha(alpha);
        gradient.setColorAt(0,color); color.setAlpha(0); gradient.setColorAt(1,color);
        p.fillRect(rect(),gradient);
    };
    glow(QPointF(width()*.12,height()*.1),width()*.85,Theme::accent(),Theme::dark()?34:24);
    glow(QPointF(width()*.95,height()*.85),width()*.7,Theme::accent(),Theme::dark()?22:18);
    glow(QPointF(width()*.65,0),width()*.55,Qt::white,Theme::dark()?10:95);
}

bool StudioWindow::nativeEvent(const QByteArray& type,void* message,qintptr* result) {
#ifdef Q_OS_WIN
    auto* msg=static_cast<MSG*>(message);
    if(msg->message==WM_NCHITTEST && !isMaximized() && !isFullScreen()) {
        RECT r; GetWindowRect(msg->hwnd,&r);
        const int x=GET_X_LPARAM(msg->lParam),y=GET_Y_LPARAM(msg->lParam);
        const int edge=qRound(6*devicePixelRatioF());
        const bool l=x<r.left+edge,rt=x>=r.right-edge,t=y<r.top+edge,b=y>=r.bottom-edge;
        if(l||rt||t||b) {
            *result=t?(l?HTTOPLEFT:rt?HTTOPRIGHT:HTTOP):b?(l?HTBOTTOMLEFT:rt?HTBOTTOMRIGHT:HTBOTTOM):l?HTLEFT:HTRIGHT;
            return true;
        }
    }
    if(msg->message==WM_GETMINMAXINFO) {
        auto* info=reinterpret_cast<MINMAXINFO*>(msg->lParam);
        MONITORINFO monitor{}; monitor.cbSize=sizeof(monitor);
        if(GetMonitorInfo(MonitorFromWindow(msg->hwnd,MONITOR_DEFAULTTONEAREST),&monitor)) {
            info->ptMaxPosition.x=monitor.rcWork.left-monitor.rcMonitor.left;
            info->ptMaxPosition.y=monitor.rcWork.top-monitor.rcMonitor.top;
            info->ptMaxSize.x=monitor.rcWork.right-monitor.rcWork.left;
            info->ptMaxSize.y=monitor.rcWork.bottom-monitor.rcWork.top;
            info->ptMinTrackSize.x=qRound(minimumWidth()*devicePixelRatioF());
            info->ptMinTrackSize.y=qRound(minimumHeight()*devicePixelRatioF());
            *result=0; return true;
        }
    }
#endif
    return QMainWindow::nativeEvent(type,message,result);
}
StudioTitleBar::StudioTitleBar(QWidget* parent) : QFrame(parent) {
    setObjectName(QStringLiteral("titleBar")); setFixedHeight(52);
    auto* row=new QHBoxLayout(this); row->setContentsMargins(16,6,16,6);
    auto* left=new QWidget(this); auto* right=new QWidget(this);
    left->setFixedWidth(100); right->setFixedWidth(100);
    m_left=new QHBoxLayout(left); m_right=new QHBoxLayout(right);
    m_left->setContentsMargins(0,0,0,0); m_right->setContentsMargins(0,0,0,0);
    m_left->setAlignment(Qt::AlignLeft); m_right->setAlignment(Qt::AlignRight);
    m_controls=new QWidget(this); auto* controls=new QHBoxLayout(m_controls);
    controls->setContentsMargins(0,0,0,0); controls->setSpacing(0);
    for(int i=0;i<3;++i) controls->addWidget(new WindowControl(i,m_controls));
    row->addWidget(left); row->addStretch();
    auto* title=new QLabel(QStringLiteral("MusicSeparator"),this); title->setObjectName(QStringLiteral("appTitle"));
    title->setAttribute(Qt::WA_TransparentForMouseEvents); row->addWidget(title);
    row->addStretch(); row->addWidget(right);
    auto position=[this] {
        m_left->removeWidget(m_controls); m_right->removeWidget(m_controls);
        (Theme::current().controlsRight?m_right:m_left)->addWidget(m_controls);
    };
    connect(&Theme::instance(),&Theme::changed,this,position); position();
}
void StudioTitleBar::mousePressEvent(QMouseEvent* event) {
    if(event->button()==Qt::LeftButton && window()->windowHandle()) {
        window()->windowHandle()->startSystemMove(); event->accept(); return;
    }
    QFrame::mousePressEvent(event);
}
void StudioTitleBar::mouseDoubleClickEvent(QMouseEvent* event) {
    if(event->button()==Qt::LeftButton) {
        if(window()->isMaximized()) window()->showNormal(); else window()->showMaximized();
        event->accept(); return;
    }
    QFrame::mouseDoubleClickEvent(event);
}
}
