#include "export/AudioExporter.h"

#include "settings/Settings.h"

#include <QDir>
#include <QFileInfo>

#include <windows.h>

extern "C" {
#include <libavcodec/avcodec.h>
#include <libavformat/avformat.h>
#include <libavutil/channel_layout.h>
#include <libavutil/error.h>
#include <libavutil/opt.h>
#include <libavutil/samplefmt.h>
#include <libswresample/swresample.h>
}

#include <algorithm>
#include <cctype>

namespace mc {

namespace {

constexpr int kSampleRate = 44100;

QString avErr(int err)
{
    char buf[AV_ERROR_MAX_STRING_SIZE] = {0};
    av_strerror(err, buf, sizeof(buf));
    return QString::fromUtf8(buf);
}

bool hasFreeSpace(const QString& dirPath, std::size_t neededBytes)
{
    const QString root = QDir(dirPath).rootPath();
    ULARGE_INTEGER freeBytes{};
    if (!GetDiskFreeSpaceExW(reinterpret_cast<LPCWSTR>(root.utf16()), &freeBytes, nullptr, nullptr))
        return true; // can't query — let the write itself report errors
    return freeBytes.QuadPart >= static_cast<ULONGLONG>(neededBytes);
}

// Encodes an interleaved stereo float32 buffer to the requested format.
ErrorCode encodePcm(const QString& path, const std::vector<float>& pcm,
                    ExportFormat fmt, int bitrateKbps, QString* error)
{
    AVCodecID codecId = AV_CODEC_ID_PCM_F32LE;
    const char* formatName = "wav";
    switch (fmt) {
    case ExportFormat::Wav:  codecId = AV_CODEC_ID_PCM_F32LE; formatName = "wav"; break;
    case ExportFormat::Mp3:  codecId = AV_CODEC_ID_MP3;       formatName = "mp3"; break;
    case ExportFormat::Flac: codecId = AV_CODEC_ID_FLAC;      formatName = "flac"; break;
    }

    const QByteArray pathUtf8 = path.toUtf8();

    AVFormatContext* ofmt = nullptr;
    int err = avformat_alloc_output_context2(&ofmt, nullptr, formatName, pathUtf8.constData());
    if (err < 0 || !ofmt) {
        *error = QStringLiteral("Could not create the output container: %1").arg(avErr(err));
        return ErrorCode::FfmpegError;
    }

    const AVCodec* codec = avcodec_find_encoder(codecId);
    if (!codec) {
        *error = QStringLiteral("No encoder available for this format.");
        avformat_free_context(ofmt);
        return ErrorCode::FfmpegError;
    }

    AVStream* stream = avformat_new_stream(ofmt, codec);
    AVCodecContext* cctx = avcodec_alloc_context3(codec);
    if (!stream || !cctx) {
        *error = QStringLiteral("Out of memory while preparing the encoder.");
        avcodec_free_context(&cctx);
        avformat_free_context(ofmt);
        return ErrorCode::OutOfMemory;
    }

    cctx->sample_rate = kSampleRate;
    av_channel_layout_default(&cctx->ch_layout, 2);
    // FFmpeg 9 no longer exposes AVCodec::sample_fmts publicly.
    // Query the supported sample formats through the public API instead.
    const void* sampleFmtConfig = nullptr;
    const int cfgErr = avcodec_get_supported_config(
        cctx, codec, AV_CODEC_CONFIG_SAMPLE_FORMAT, 0, &sampleFmtConfig, nullptr);

    if (cfgErr >= 0 && sampleFmtConfig) {
        cctx->sample_fmt = static_cast<const AVSampleFormat*>(sampleFmtConfig)[0];
    } else {
        // Conservative fallback; normally avcodec_get_supported_config succeeds.
        switch (fmt) {
        case ExportFormat::Wav:  cctx->sample_fmt = AV_SAMPLE_FMT_FLT;  break;
        case ExportFormat::Mp3:  cctx->sample_fmt = AV_SAMPLE_FMT_FLTP; break;
        case ExportFormat::Flac: cctx->sample_fmt = AV_SAMPLE_FMT_S32;  break;
        }
    }
    if (fmt == ExportFormat::Mp3) {
        cctx->bit_rate = static_cast<int64_t>(bitrateKbps) * 1000;
        cctx->compression_level = 2;
    } else if (fmt == ExportFormat::Flac) {
        cctx->compression_level = 8;
    }

    err = avcodec_open2(cctx, codec, nullptr);
    if (err < 0) {
        *error = QStringLiteral("Could not open the encoder (%1): %2")
                     .arg(QString::fromUtf8(codec->name), avErr(err));
        avcodec_free_context(&cctx);
        avformat_free_context(ofmt);
        return ErrorCode::FfmpegError;
    }

    stream->time_base = AVRational{1, kSampleRate};
    err = avcodec_parameters_from_context(stream->codecpar, cctx);
    if (err < 0) {
        *error = QStringLiteral("Could not copy encoder parameters: %1").arg(avErr(err));
        avcodec_free_context(&cctx);
        avformat_free_context(ofmt);
        return ErrorCode::FfmpegError;
    }

    err = avio_open(&ofmt->pb, pathUtf8.constData(), AVIO_FLAG_WRITE);
    if (err < 0) {
        *error = QStringLiteral("Could not write to %1 (%2). Check disk space and permissions.")
                     .arg(path, avErr(err));
        avcodec_free_context(&cctx);
        avformat_free_context(ofmt);
        return ErrorCode::DiskFull;
    }

    err = avformat_write_header(ofmt, nullptr);
    if (err < 0) {
        *error = QStringLiteral("Could not write the container header: %1").arg(avErr(err));
        avio_closep(&ofmt->pb);
        avcodec_free_context(&cctx);
        avformat_free_context(ofmt);
        return ErrorCode::FfmpegError;
    }

    // Resampler: interleaved float32 -> encoder format.
    SwrContext* swr = nullptr;
    AVChannelLayout inLayout;
    av_channel_layout_default(&inLayout, 2);
    err = swr_alloc_set_opts2(&swr, &cctx->ch_layout, cctx->sample_fmt, kSampleRate,
                              &inLayout, AV_SAMPLE_FMT_FLT, kSampleRate, 0, nullptr);
    if (err < 0 || !swr || swr_init(swr) < 0) {
        *error = QStringLiteral("Could not initialize the resampler.");
        swr_free(&swr);
        av_write_trailer(ofmt);
        avio_closep(&ofmt->pb);
        avcodec_free_context(&cctx);
        avformat_free_context(ofmt);
        return ErrorCode::FfmpegError;
    }

    const int frameSize = cctx->frame_size > 0 ? cctx->frame_size : 1024;
    uint8_t* outBuf[AV_NUM_DATA_POINTERS] = {nullptr};
    if (av_samples_alloc(outBuf, nullptr, 2, frameSize, cctx->sample_fmt, 0) < 0) {
        *error = QStringLiteral("Out of memory allocating the encode buffer.");
        swr_free(&swr);
        av_write_trailer(ofmt);
        avio_closep(&ofmt->pb);
        avcodec_free_context(&cctx);
        avformat_free_context(ofmt);
        return ErrorCode::OutOfMemory;
    }

    AVFrame* frame = av_frame_alloc();
    AVPacket* pkt = av_packet_alloc();
    if (!frame || !pkt) {
        *error = QStringLiteral("Out of memory allocating encode structures.");
        av_freep(&outBuf[0]);
        swr_free(&swr);
        av_write_trailer(ofmt);
        avio_closep(&ofmt->pb);
        avcodec_free_context(&cctx);
        avformat_free_context(ofmt);
        return ErrorCode::OutOfMemory;
    }
    frame->format = cctx->sample_fmt;
    frame->sample_rate = kSampleRate;
    av_channel_layout_copy(&frame->ch_layout, &cctx->ch_layout);

    bool failed = false;
    QString failMsg;
    int64_t nextPts = 0;
    const std::size_t totalFrames = pcm.size() / 2;
    std::size_t consumed = 0;

    auto writePackets = [&]() {
        while (avcodec_receive_packet(cctx, pkt) == 0) {
            av_packet_rescale_ts(pkt, AVRational{1, kSampleRate}, stream->time_base);
            const int w = av_interleaved_write_frame(ofmt, pkt);
            av_packet_unref(pkt);
            if (w < 0) {
                failed = true;
                failMsg = QStringLiteral("Write failed: %1").arg(avErr(w));
                return;
            }
        }
    };

    while (!failed && consumed < totalFrames) {
        const std::size_t in = std::min<std::size_t>(frameSize, totalFrames - consumed);
        const uint8_t* inPlane = reinterpret_cast<const uint8_t*>(pcm.data() + consumed * 2);
        const int got = swr_convert(swr, outBuf, static_cast<int>(in), &inPlane, static_cast<int>(in));
        if (got < 0) {
            failed = true;
            failMsg = QStringLiteral("Resampling failed: %1").arg(avErr(got));
            break;
        }
        frame->nb_samples = got;
        frame->pts = nextPts;
        nextPts += got;

        // Point the frame planes at the resampled output.
        for (int i = 0; i < 2; ++i)
            frame->data[i] = outBuf[i];
        const int lineSize = av_samples_get_buffer_size(nullptr, cctx->ch_layout.nb_channels,
                                                        got, cctx->sample_fmt, 1);
        frame->linesize[0] = lineSize;
        frame->linesize[1] = lineSize;

        const int s = avcodec_send_frame(cctx, frame);
        if (s < 0) {
            failed = true;
            failMsg = QStringLiteral("Encode failed: %1").arg(avErr(s));
            break;
        }
        writePackets();
        consumed += in;
    }

    if (!failed) {
        avcodec_send_frame(cctx, nullptr); // flush
        writePackets();
    }

    av_write_trailer(ofmt);

    ErrorCode result = failed ? ErrorCode::FfmpegError : ErrorCode::None;
    if (failed) *error = failMsg;

    av_packet_free(&pkt);
    av_frame_free(&frame);
    av_freep(&outBuf[0]);
    swr_free(&swr);
    avio_closep(&ofmt->pb);
    avcodec_free_context(&cctx);
    avformat_free_context(ofmt);
    return result;
}

} // namespace

QString AudioExporter::sanitizeName(const QString& name)
{
    QString out = name;
    for (QChar& c : out) {
        const ushort u = c.unicode();
        if (u < 32 || c == QLatin1Char('/') || c == QLatin1Char('\\') || c == QLatin1Char(':') ||
            c == QLatin1Char('*') || c == QLatin1Char('?') || c == QLatin1Char('"') ||
            c == QLatin1Char('<') || c == QLatin1Char('>') || c == QLatin1Char('|'))
            c = QLatin1Char('_');
    }
    out = out.trimmed();
    if (out.isEmpty()) out = QStringLiteral("Track");
    return out.left(60);
}

QString AudioExporter::stemFolder(const QString& title, const QString& outputDir)
{
    return QDir(outputDir).filePath(sanitizeName(title) + QStringLiteral("_Stems"));
}

ErrorCode AudioExporter::exportStems(const QVector<StemResult>& stems, const QString& title,
                                     const QString& outputDir, ExportFormat fmt, int mp3Bitrate,
                                     const std::function<bool(double)>& progress, QString* error)
{
    if (stems.isEmpty()) {
        *error = QStringLiteral("Nothing to export.");
        return ErrorCode::Unknown;
    }

    const QString folder = stemFolder(title, outputDir);
    if (!QDir().mkpath(folder)) {
        *error = QStringLiteral("Could not create the output folder: %1").arg(folder);
        return ErrorCode::DiskFull;
    }

    // Rough disk-space estimate before writing anything.
    std::size_t needed = 0;
    for (const StemResult& s : stems)
        needed += s.buffer.pcm.size() * sizeof(float);
    switch (fmt) {
    case ExportFormat::Wav:  break; // float32 WAV ≈ same size as the buffers
    case ExportFormat::Flac: needed /= 2; break;
    case ExportFormat::Mp3:  needed /= 12; break;
    }
    needed += static_cast<std::size_t>(1024 * 1024);
    if (!hasFreeSpace(folder, needed)) {
        *error = QStringLiteral("The output drive has less than %1 MB free.")
                     .arg(needed / (1024 * 1024));
        return ErrorCode::DiskFull;
    }

    const QString ext = exportFormatExtension(fmt);
    for (int i = 0; i < stems.size(); ++i) {
        if (progress && !progress(static_cast<double>(i) / stems.size()))
            return ErrorCode::Cancelled;
        const QString filePath = QDir(folder).filePath(sanitizeName(stems[i].id) + QLatin1Char('.') + ext);
        const ErrorCode ec = encodePcm(filePath, stems[i].buffer.pcm, fmt, mp3Bitrate, error);
        if (ec != ErrorCode::None) return ec;
    }
    if (progress) progress(1.0);
    return ErrorCode::None;
}

ErrorCode AudioExporter::exportOne(const StemResult& stem, const QString& title,
                                   const QString& outputDir, ExportFormat fmt, int mp3Bitrate,
                                   QString* error)
{
    const QString folder = stemFolder(title, outputDir);
    if (!QDir().mkpath(folder)) {
        *error = QStringLiteral("Could not create the output folder: %1").arg(folder);
        return ErrorCode::DiskFull;
    }
    const QString filePath = QDir(folder).filePath(
        sanitizeName(stem.id) + QLatin1Char('.') + exportFormatExtension(fmt));
    return encodePcm(filePath, stem.buffer.pcm, fmt, mp3Bitrate, error);
}

ExportWorker::ExportWorker(QVector<StemResult> stems, QString title, QString outputDir,
                           ExportFormat fmt, QObject* parent)
    : QThread(parent)
    , m_stems(std::move(stems))
    , m_title(std::move(title))
    , m_outputDir(std::move(outputDir))
    , m_format(fmt)
{
    qRegisterMetaType<mc::ErrorCode>("mc::ErrorCode");
}

ExportWorker::~ExportWorker()
{
    requestCancel();
    wait();
}

void ExportWorker::requestCancel()
{
    m_cancel.store(true, std::memory_order_relaxed);
}

ErrorCode ExportWorker::errorCode() const
{
    return m_error;
}

QString ExportWorker::errorDetail() const
{
    return m_errorDetail;
}

QString ExportWorker::exportPath() const
{
    return m_exportPath;
}

void ExportWorker::run()
{
    emit progressChanged(0, tr("Exporting…"));
    QString error;
    auto progress = [this](double frac) {
        if (m_cancel.load(std::memory_order_relaxed)) return false;
        emit progressChanged(static_cast<int>(frac * 100.0), tr("Exporting…"));
        return true;
    };
    m_exportPath = AudioExporter::stemFolder(m_title, m_outputDir);

    const int bitrate = Settings::instance().mp3Bitrate();
    const ErrorCode ec = AudioExporter::exportStems(m_stems, m_title, m_outputDir,
                                                    m_format, bitrate, progress, &error);
    if (ec == ErrorCode::Cancelled) {
        m_error = ec;
        m_errorDetail = tr("Export cancelled.");
        emit failed(ec, m_errorDetail);
        return;
    }
    if (ec != ErrorCode::None) {
        m_error = ec;
        m_errorDetail = error;
        emit failed(ec, error);
        return;
    }
    emit progressChanged(100, tr("Done"));
    emit done();
}

} // namespace mc
