#pragma once

#include <QString>

namespace mc {

enum class ExportFormat { Wav, Mp3, Flac };

inline QString exportFormatExtension(ExportFormat fmt)
{
    switch (fmt) {
    case ExportFormat::Wav:  return QStringLiteral("wav");
    case ExportFormat::Mp3:  return QStringLiteral("mp3");
    case ExportFormat::Flac: return QStringLiteral("flac");
    }
    return QStringLiteral("wav");
}

} // namespace mc
