#pragma once

#include "common/ErrorCodes.h"
#include "export/ExportFormat.h"
#include "separation/SeparationTypes.h"

#include <QThread>
#include <QVector>

#include <atomic>
#include <functional>
#include <vector>

namespace mc {

// Encodes stems to WAV / MP3 / FLAC with FFmpeg and writes them into
// a "<Title>_Stems" folder. Pure functions run fine on a worker thread.
class AudioExporter
{
public:
    static ErrorCode exportStems(const QVector<StemResult>& stems, const QString& title,
                                 const QString& outputDir, ExportFormat fmt, int mp3Bitrate,
                                 const std::function<bool(double)>& progress, QString* error);

    static ErrorCode exportOne(const StemResult& stem, const QString& title,
                               const QString& outputDir, ExportFormat fmt, int mp3Bitrate,
                               QString* error);

    // Creates "<title>_Stems" under outputDir.
    static QString stemFolder(const QString& title, const QString& outputDir);
    static QString sanitizeName(const QString& name);
};

// Runs an export off the UI thread.
class ExportWorker : public QThread
{
    Q_OBJECT
public:
    ExportWorker(QVector<StemResult> stems, QString title, QString outputDir,
                 ExportFormat fmt, QObject* parent = nullptr);
    ~ExportWorker() override;

    void requestCancel();
    ErrorCode errorCode() const;
    QString errorDetail() const;
    QString exportPath() const;

signals:
    void progressChanged(int percent, const QString& stage);
    void done();
    void failed(mc::ErrorCode code, const QString& detail);

protected:
    void run() override;

private:
    QVector<StemResult> m_stems;
    QString m_title;
    QString m_outputDir;
    ExportFormat m_format;
    std::atomic<bool> m_cancel{false};
    QString m_exportPath;
    ErrorCode m_error = ErrorCode::None;
    QString m_errorDetail;
};

} // namespace mc
