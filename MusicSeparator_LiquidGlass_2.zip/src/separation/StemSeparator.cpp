#include "separation/StemSeparator.h"

#include "separation/ChunkedInference.h"

#include <map>

namespace mc {

QVector<StemInfo> stemsForMode(StemMode mode)
{
    QVector<StemInfo> list;
    switch (mode) {
    case StemMode::TwoStems:
        list.append({QStringLiteral("vocals"), QStringLiteral("Vocals")});
        list.append({QStringLiteral("instrumental"), QStringLiteral("Instrumental")});
        break;
    case StemMode::FourStems:
        list.append({QStringLiteral("vocals"), QStringLiteral("Vocals")});
        list.append({QStringLiteral("drums"), QStringLiteral("Drums")});
        list.append({QStringLiteral("bass"), QStringLiteral("Bass")});
        break;
    case StemMode::SixStems:
        list.append({QStringLiteral("vocals"), QStringLiteral("Vocals")});
        list.append({QStringLiteral("drums"), QStringLiteral("Drums")});
        list.append({QStringLiteral("bass"), QStringLiteral("Bass")});
        list.append({QStringLiteral("guitar"), QStringLiteral("Guitar")});
        list.append({QStringLiteral("piano"), QStringLiteral("Piano")});
        break;
    }
    return list;
}

bool StemSeparator::separate(const std::vector<float>& mix, int sampleRate,
                             IModelRunner& model, StemMode mode,
                             const std::function<bool(double)>& progress,
                             QVector<StemResult>* out, std::string* error)
{
    if (!out || sampleRate != 44100 || mix.empty() || mix.size() % 2 != 0) {
        if (error) *error = "Expected non-empty stereo audio at 44100 Hz.";
        return false;
    }
    const std::size_t totalFrames = mix.size() / 2;

    std::vector<std::vector<float>> stems;
    if (!runChunkedInference(mix.data(), totalFrames, model, progress, &stems, error))
        return false;

    // Map runner output rows to stem ids.
    std::map<std::string, const std::vector<float>*> byName;
    const std::vector<std::string> names = model.sourceNames();
    for (std::size_t i = 0; i < names.size() && i < stems.size(); ++i)
        byName[names[i]] = &stems[i];

    const auto vocalsIt = byName.find("vocals");
    if (vocalsIt == byName.end()) {
        if (error) *error = "Model did not produce a vocals stem.";
        return false;
    }
    const std::vector<float>& vocals = *vocalsIt->second;

    out->clear();
    for (const StemInfo& info : stemsForMode(mode)) {
        StemResult result;
        result.id = info.id;
        result.displayName = info.displayName;
        result.buffer.name = info.displayName;
        result.buffer.sampleRate = sampleRate;
        result.buffer.channels = 2;

        if (info.id == QLatin1String("instrumental")) {
            // instrumental = mix - vocals  (perfect reconstruction)
            result.buffer.pcm.resize(mix.size());
            for (std::size_t i = 0; i < mix.size(); ++i)
                result.buffer.pcm[i] = mix[i] - vocals[i];
        } else {
            const auto it = byName.find(info.id.toStdString());
            if (it == byName.end()) {
                if (error) *error = "Model did not produce stem: " + info.id.toStdString();
                return false;
            }
            result.buffer.pcm = *it->second;
        }
        out->append(std::move(result));
    }
    return true;
}

} // namespace mc
