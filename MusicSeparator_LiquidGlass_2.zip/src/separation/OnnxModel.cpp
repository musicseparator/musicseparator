#include "separation/OnnxModel.h"
#include "separation/StereoTensor.h"

#include <onnxruntime_cxx_api.h>

#if __has_include(<dml_provider_factory.h>)
#include <dml_provider_factory.h>
#define MS_HAS_ORT_DML_FACTORY 1
#elif __has_include(<onnxruntime/core/providers/dml/dml_provider_factory.h>)
#include <onnxruntime/core/providers/dml/dml_provider_factory.h>
#define MS_HAS_ORT_DML_FACTORY 1
#else
#define MS_HAS_ORT_DML_FACTORY 0
#endif

#include <array>
#include <cstring>
#include <filesystem>
#include <stdexcept>

namespace mc {

OnnxModel::~OnnxModel() = default;

std::vector<std::string> OnnxModel::availableProviders()
{
    std::vector<std::string> result;
    const OrtApi* api = OrtGetApiBase()->GetApi(ORT_API_VERSION);
    if (!api) return result;

    char** names = nullptr;
    int count = 0;
    OrtStatus* st = api->GetAvailableProviders(&names, &count);
    if (st) {
        api->ReleaseStatus(st);
        return result;
    }

    for (int i = 0; i < count; ++i)
        if (names[i]) result.emplace_back(names[i]);

    api->ReleaseAvailableProviders(names, count);
    return result;
}

std::string OnnxModel::load(const std::string& path, int sources,
                            const std::vector<std::string>& sourceNames,
                            int segment, int overlap,
                            const std::vector<std::string>& epPriority)
{
    try {
        m_session.reset();
        m_provider = ProviderInfo{ProviderKind::Cpu, "CPUExecutionProvider"};

        m_env = std::make_unique<Ort::Env>(ORT_LOGGING_LEVEL_WARNING, "MusicSeparator");
        m_mem = std::make_unique<Ort::MemoryInfo>(
            Ort::MemoryInfo::CreateCpu(OrtArenaAllocator, OrtMemTypeDefault));

        Ort::SessionOptions opts;
        opts.SetGraphOptimizationLevel(GraphOptimizationLevel::ORT_ENABLE_ALL);
        opts.SetIntraOpNumThreads(0);

        // DirectML requires sequential execution and memory-pattern optimization disabled.
        // These settings are also safe for CPU/CUDA fallback.
        opts.DisableMemPattern();
        opts.SetExecutionMode(ExecutionMode::ORT_SEQUENTIAL);

        const OrtApi* api = OrtGetApiBase()->GetApi(ORT_API_VERSION);
        if (!api)
            return "ONNX Runtime API is unavailable.";

        for (const std::string& name : epPriority) {
            OrtStatus* st = nullptr;

            if (name == "DMLExecutionProvider") {
#if MS_HAS_ORT_DML_FACTORY
                st = OrtSessionOptionsAppendExecutionProvider_DML(opts, 0);
#else
                continue;
#endif
            } else if (name == "CUDAExecutionProvider") {
                // Use the concrete legacy CUDA options struct instead of
                // OrtCUDAProviderOptionsV2 (which is intentionally opaque).
                OrtCUDAProviderOptions cudaOpts;
                cudaOpts.device_id = 0;
                cudaOpts.do_copy_in_default_stream = 1;
                st = api->SessionOptionsAppendExecutionProvider_CUDA(opts, &cudaOpts);
            } else {
                continue;
            }

            if (!st) {
                m_provider = (name == "DMLExecutionProvider")
                                 ? ProviderInfo{ProviderKind::Dml, name}
                                 : ProviderInfo{ProviderKind::Cuda, name};
                break;
            }

            // Provider may be listed but fail at initialization (missing driver,
            // unavailable CUDA runtime, etc.). Release the status and try next.
            api->ReleaseStatus(st);
        }

#ifdef _WIN32
        const std::filesystem::path modelPath(path);
        m_session = std::make_unique<Ort::Session>(*m_env, modelPath.c_str(), opts);
#else
        m_session = std::make_unique<Ort::Session>(*m_env, path.c_str(), opts);
#endif

        if (sources <= 0 || sourceNames.size() != static_cast<std::size_t>(sources))
            throw std::runtime_error("Invalid stem names/count configuration.");
        if (m_session->GetInputCount() != 1 || m_session->GetOutputCount() != 1)
            throw std::runtime_error("Unsupported model: expected one waveform input and one stems output.");
        const auto inputInfo = m_session->GetInputTypeInfo(0);
        const auto outputInfo = m_session->GetOutputTypeInfo(0);
        const auto inTensor = inputInfo.GetTensorTypeAndShapeInfo();
        const auto outTensor = outputInfo.GetTensorTypeAndShapeInfo();
        if (inTensor.GetElementType() != ONNX_TENSOR_ELEMENT_DATA_TYPE_FLOAT ||
            outTensor.GetElementType() != ONNX_TENSOR_ELEMENT_DATA_TYPE_FLOAT ||
            !matchesTensorShape(inTensor.GetShape(), {1, 2, segment}, true) ||
            !matchesTensorShape(outTensor.GetShape(), {1, sources, 2, segment}, true))
            throw std::runtime_error("Incompatible model layout. Expected float32 [1,2,343980] -> [1,S,2,343980]. Use the HT-Demucs waveform exports; spectrogram MDX models are not supported.");
        Ort::AllocatorWithDefaultOptions allocator;
        const auto inName = m_session->GetInputNameAllocated(0, allocator);
        const auto outName = m_session->GetOutputNameAllocated(0, allocator);
        m_inputName = inName.get();
        m_outputName = outName.get();

        m_sources = sources;
        m_names = sourceNames;
        m_segment = segment;
        m_overlap = overlap;
        return std::string();
    } catch (const Ort::Exception& e) {
        m_session.reset();
        return std::string("ONNX Runtime error: ") + e.what();
    } catch (const std::exception& e) {
        m_session.reset();
        return std::string("Model load error: ") + e.what();
    }
}

bool OnnxModel::run(const float* chunk, int n, float* out, std::string* error)
{
    if (!m_session) {
        if (error) *error = "Model session is not loaded.";
        return false;
    }

    if (!chunk || !out || n != m_segment) {
        if (error) *error = "Invalid inference buffer or segment length.";
        return false;
    }
    try {
        std::vector<float> planar(static_cast<std::size_t>(n) * 2);
        stereoToPlanar(chunk, static_cast<std::size_t>(n), planar.data());
        std::array<int64_t, 3> shape{1, 2, n};
        Ort::Value input = Ort::Value::CreateTensor<float>(
            *m_mem, planar.data(),
            static_cast<size_t>(2) * static_cast<size_t>(n),
            shape.data(), shape.size());

        const char* inName = m_inputName.c_str();
        const char* outName = m_outputName.c_str();
        Ort::RunOptions runOpts;
        auto outputs = m_session->Run(runOpts, &inName, &input, 1, &outName, 1);

        if (outputs.empty() || !outputs[0].IsTensor()) {
            if (error) *error = "Model returned no tensor output.";
            return false;
        }

        const auto info = outputs[0].GetTensorTypeAndShapeInfo();
        if (info.GetElementType() != ONNX_TENSOR_ELEMENT_DATA_TYPE_FLOAT ||
            !matchesTensorShape(info.GetShape(), {1, m_sources, 2, n}, false)) {
            if (error) *error = "The model returned an unexpected tensor shape or type; separation aborted.";
            return false;
        }
        if (!stemsToInterleaved(outputs[0].GetTensorData<float>(),
                                static_cast<std::size_t>(n),
                                static_cast<std::size_t>(m_sources), out)) {
            if (error) *error = "The model returned non-finite audio samples. Try CPU processing.";
            return false;
        }
        return true;
    } catch (const Ort::Exception& e) {
        if (error) *error = std::string("ONNX Runtime run error: ") + e.what();
        return false;
    } catch (const std::exception& e) {
        if (error) *error = std::string("Inference error: ") + e.what();
        return false;
    }
}

} // namespace mc
