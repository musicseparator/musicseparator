#pragma once

#include "audio/AudioBuffer.h"

#include <QString>
#include <QVector>
#include <vector>

namespace mc {

enum class StemMode { TwoStems, FourStems, SixStems };
enum class Quality { Fast, Balanced, Best };

struct StemInfo {
    QString id;         // machine id, used for file names and mapping
    QString displayName; // UI label
};

// Display order: vocals first, then the rest.
QVector<StemInfo> stemsForMode(StemMode mode);

struct StemResult {
    QString id;
    QString displayName;
    AudioBuffer buffer;
};

} // namespace mc
