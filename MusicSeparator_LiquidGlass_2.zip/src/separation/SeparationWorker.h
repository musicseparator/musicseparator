#pragma once

#include "common/ErrorCodes.h"
#include "separation/SeparationTypes.h"

#include <QMutex>
#include <QThread>
#include <QVector>

#include <atomic>
#include <vector>

namespace mc {

// Runs the whole separation pipeline (model load + chunked inference)
// off the UI thread. Results are read after separationDone() has been
// emitted; the worker never touches the UI.
class SeparationWorker : public QThread
{
    Q_OBJECT
public:
    SeparationWorker(std::vector<float> mix, int sampleRate,
                     StemMode mode, Quality quality, QObject* parent = nullptr);
    ~SeparationWorker() override;

    void requestCancel();
    QVector<StemResult> results() const;

signals:
    void progressChanged(int percent, const QString& stage);
    void separationDone();
    void separationFailed(mc::ErrorCode code, const QString& detail);

protected:
    void run() override;

private:
    std::vector<float> m_mix;
    int m_sampleRate;
    StemMode m_mode;
    Quality m_quality;

    std::atomic<bool> m_cancel{false};
    mutable QMutex m_mutex;
    QVector<StemResult> m_results;
    ErrorCode m_error = ErrorCode::None;
    QString m_errorDetail;
};

} // namespace mc
