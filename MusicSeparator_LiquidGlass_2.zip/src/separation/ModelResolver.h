#pragma once

#include "separation/IModelRunner.h"
#include "separation/SeparationTypes.h"

#include <memory>
#include <string>
#include <vector>

namespace mc {

// Builds the right IModelRunner for a (mode, quality) pair from the
// .onnx files shipped in the models/ directory.
//
//   TwoStems  Fast     -> MDX-Net Kim_Vocal_2 (vocals only, fastest)
//   TwoStems  Balanced -> htdemucs single file (vocals; instrumental = mix - vocals)
//   TwoStems  Best     -> htdemucs_ft specialist bag
//   FourStems Fast     -> htdemucs fp16weights
//   FourStems Balanced -> htdemucs fp32
//   FourStems Best     -> htdemucs_ft bag (falls back to single file)
//   SixStems  *        -> htdemucs_6s (fp16weights for Fast, fp32 otherwise)
class ModelResolver
{
public:
    static constexpr int kHtdemucsSegment = 343980; // 7.8 s @ 44.1 kHz
    static constexpr int kHtdemucsOverlap = kHtdemucsSegment / 4;
    static constexpr int kMdxSegment = 110080;
    static constexpr int kMdxOverlap = kMdxSegment / 4;

    // Returns nullptr + a readable error when a required model is missing.
    static std::unique_ptr<IModelRunner> create(const std::string& modelsDir,
                                                StemMode mode, Quality quality,
                                                const std::vector<std::string>& epPriority,
                                                std::string* error);
};

} // namespace mc
