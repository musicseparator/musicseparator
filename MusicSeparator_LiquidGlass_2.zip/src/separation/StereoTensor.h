#pragma once
#include <cstddef>
#include <cstdint>
#include <cmath>
#include <vector>

namespace mc {
// Audio buffers are LRLR; ONNX [batch, channel, time] is LLL...RRR...
inline void stereoToPlanar(const float* input, std::size_t frames, float* output)
{
    for (std::size_t i = 0; i < frames; ++i) {
        output[i] = input[2 * i];
        output[frames + i] = input[2 * i + 1];
    }
}
inline bool stemsToInterleaved(const float* input, std::size_t frames,
                               std::size_t sources, float* output)
{
    for (std::size_t s = 0; s < sources; ++s) {
        const std::size_t base = s * frames * 2;
        for (std::size_t i = 0; i < frames; ++i) {
            const float l = input[base + i], r = input[base + frames + i];
            if (!std::isfinite(l) || !std::isfinite(r)) return false;
            output[base + 2 * i] = l;
            output[base + 2 * i + 1] = r;
        }
    }
    return true;
}
inline bool matchesTensorShape(const std::vector<int64_t>& shape,
                                const std::vector<int64_t>& expected,
                                bool allowDynamic)
{
    if (shape.size() != expected.size()) return false;
    for (std::size_t i = 0; i < shape.size(); ++i)
        if (shape[i] != expected[i] && !(allowDynamic && shape[i] == -1)) return false;
    return true;
}
} // namespace mc
