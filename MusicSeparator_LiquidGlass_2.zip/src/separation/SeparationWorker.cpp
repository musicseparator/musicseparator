#include "separation/SeparationWorker.h"

#include "AppContext.h"
#include "separation/ModelResolver.h"
#include "separation/OnnxModel.h"
#include "separation/StemSeparator.h"
#include "settings/Settings.h"

#include <QMetaType>

#include <algorithm>
#include <cctype>
#include <exception>
#include <new>

namespace mc {

namespace {

// Maps the DevicePref setting + this machine's providers onto an ORT
// provider priority list. The GPU preference never fails: it falls back
// to CPU providers when nothing GPU-ish is available.
std::vector<std::string> providerPriority(DevicePref pref,
                                          const std::vector<std::string>& available)
{
    auto has = [&](const char* name) {
        return std::find(available.begin(), available.end(), name) != available.end();
    };
    std::vector<std::string> order;
    switch (pref) {
    case DevicePref::Cpu:
        break;
    case DevicePref::Gpu:
        if (has("CUDAExecutionProvider")) order.emplace_back("CUDAExecutionProvider");
        if (has("DMLExecutionProvider")) order.emplace_back("DMLExecutionProvider");
        break;
    case DevicePref::Auto:
        if (has("CUDAExecutionProvider")) order.emplace_back("CUDAExecutionProvider");
        if (has("DMLExecutionProvider")) order.emplace_back("DMLExecutionProvider");
        break;
    }
    return order;
}

ErrorCode runnerErrorToCode(const std::string& message)
{
    std::string low = message;
    std::transform(low.begin(), low.end(), low.begin(),
                   [](unsigned char c) { return static_cast<char>(std::tolower(c)); });
    if (low.find("out of memory") != std::string::npos) return ErrorCode::OutOfMemory;
    if (low.find("vram") != std::string::npos) return ErrorCode::OutOfVram;
    if (low.find("cuda") != std::string::npos) return ErrorCode::CudaError;
    return ErrorCode::OnnxError;
}

} // namespace

SeparationWorker::SeparationWorker(std::vector<float> mix, int sampleRate,
                                   StemMode mode, Quality quality, QObject* parent)
    : QThread(parent)
    , m_mix(std::move(mix))
    , m_sampleRate(sampleRate)
    , m_mode(mode)
    , m_quality(quality)
{
    qRegisterMetaType<mc::ErrorCode>("mc::ErrorCode");
}

SeparationWorker::~SeparationWorker()
{
    requestCancel();
    wait();
}

void SeparationWorker::requestCancel()
{
    m_cancel.store(true, std::memory_order_relaxed);
}

QVector<StemResult> SeparationWorker::results() const
{
    QMutexLocker lock(&m_mutex);
    return m_results;
}

void SeparationWorker::run()
try {
    emit progressChanged(1, tr("Loading model…"));

    const auto providers = OnnxModel::availableProviders();
    const auto epPriority = providerPriority(Settings::instance().device(), providers);

    std::string error;
    auto runner = ModelResolver::create(AppContext::modelsDir().toStdString(),
                                        m_mode, m_quality, epPriority, &error);
    if (!runner) {
        const ErrorCode code = error.find("Missing") != std::string::npos ||
                                       error.find("missing") != std::string::npos
                                   ? ErrorCode::ModelMissing
                                   : ErrorCode::OnnxError;
        emit separationFailed(code, QString::fromStdString(error));
        return;
    }

    if (m_cancel.load(std::memory_order_relaxed)) {
        emit separationFailed(ErrorCode::Cancelled, tr("Separation cancelled."));
        return;
    }

    int lastPercent = 0;
    auto progress = [this, &lastPercent](double frac) {
        if (m_cancel.load(std::memory_order_relaxed)) return false;
        const int pct = 2 + static_cast<int>(frac * 93.0);
        if (pct > lastPercent) {
            lastPercent = pct;
            emit progressChanged(pct, tr("Separating stems…"));
        }
        return true;
    };

    QVector<StemResult> results;
    if (!StemSeparator::separate(m_mix, m_sampleRate, *runner, m_mode, progress,
                                 &results, &error)) {
        if (m_cancel.load(std::memory_order_relaxed)) {
            emit separationFailed(ErrorCode::Cancelled, tr("Separation cancelled."));
            return;
        }
        emit separationFailed(runnerErrorToCode(error), QString::fromStdString(error));
        return;
    }

    if (m_cancel.load(std::memory_order_relaxed)) {
        emit separationFailed(ErrorCode::Cancelled, tr("Separation cancelled."));
        return;
    }

    emit progressChanged(98, tr("Finalizing…"));
    {
        QMutexLocker lock(&m_mutex);
        m_results = std::move(results);
    }
    emit progressChanged(100, tr("Done"));
    emit separationDone();
}

catch (const std::bad_alloc&) {
    emit separationFailed(ErrorCode::OutOfMemory, tr("Not enough memory to separate this track."));
}
catch (const std::exception& e) {
    emit separationFailed(ErrorCode::OnnxError, QString::fromUtf8(e.what()));
}

} // namespace mc
