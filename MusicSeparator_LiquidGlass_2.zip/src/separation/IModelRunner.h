#pragma once

#include <string>
#include <vector>

namespace mc {

// Abstraction over an ONNX model (or a bag of models) that turns one
// stereo chunk into N stereo stems. Kept Qt-free so the chunking math
// can be tested standalone.
class IModelRunner
{
public:
    virtual ~IModelRunner() = default;

    virtual int sources() const = 0;
    virtual std::vector<std::string> sourceNames() const = 0;

    // Chunk geometry baked into the exported graphs:
    //   htdemucs family: 343980 samples (7.8 s @ 44.1 kHz)
    //   MDX-Net:         110080 samples
    virtual int segmentSize() const = 0;
    virtual int overlapSize() const = 0;

    // Runs the model on a zero-padded chunk of exactly `n` samples
    // (interleaved stereo). Fills `out` with sources()*2*n floats,
    // each source being `2*n` interleaved stereo samples.
    virtual bool run(const float* chunk, int n, float* out, std::string* error) = 0;
};

} // namespace mc
