#include "separation/ModelResolver.h"

#include "separation/OnnxModel.h"

#include <algorithm>
#include <cstdio>

namespace mc {

namespace {

bool fileExists(const std::string& path)
{
    FILE* f = std::fopen(path.c_str(), "rb");
    if (!f) return false;
    std::fclose(f);
    return true;
}

std::string missingModelError(const std::string& modelsDir, const std::string& fileName)
{
    return "Required model file is missing: " + modelsDir + "/" + fileName +
           ". Run RECOMPILER_ET_LANCER.cmd to install the 6-source model.";
}

const std::vector<std::string> kHtdemucsNames{"drums", "bass", "other", "vocals"};
const std::vector<std::string> kSixStemsNames{"drums", "bass", "other", "vocals", "guitar", "piano"};

// htdemucs_ft bag: 4 specialist networks, each contributing only its own
// stem row (one-hot aggregation, bit-exact with the official ensemble).
class BagModel : public IModelRunner
{
public:
    bool load(const std::string& modelsDir, const std::vector<std::string>& stems,
              const std::vector<std::string>& epPriority, std::string* error)
    {
        for (const std::string& stem : stems) {
            const std::string path = modelsDir + "/htdemucs_ft_" + stem + "_fp16weights.onnx";
            if (!fileExists(path)) {
                *error = missingModelError(modelsDir, "htdemucs_ft_" + stem + "_fp16weights.onnx");
                return false;
            }
            auto model = std::make_unique<OnnxModel>();
            const std::string loadErr = model->load(path, 4, kHtdemucsNames,
                                                    ModelResolver::kHtdemucsSegment,
                                                    ModelResolver::kHtdemucsOverlap,
                                                    epPriority);
            if (!loadErr.empty()) {
                *error = loadErr;
                return false;
            }
            m_models.push_back(std::move(model));
            m_stems.push_back(stem);
        }
        return true;
    }

    int sources() const override { return 4; }
    std::vector<std::string> sourceNames() const override { return kHtdemucsNames; }
    int segmentSize() const override { return ModelResolver::kHtdemucsSegment; }
    int overlapSize() const override { return ModelResolver::kHtdemucsOverlap; }

    bool run(const float* chunk, int n, float* out, std::string* error) override
    {
        std::vector<float> rows(static_cast<size_t>(4) * 2 * n);
        for (size_t k = 0; k < m_models.size(); ++k) {
            if (!m_models[k]->run(chunk, n, rows.data(), error)) return false;
            const size_t targetRow = k; // specialist k fills stem row k
            const float* src = rows.data() + targetRow * 2 * n;
            float* dst = out + k * 2 * n;
            std::copy(src, src + static_cast<size_t>(2) * n, dst);
        }
        return true;
    }

private:
    std::vector<std::unique_ptr<OnnxModel>> m_models;
    std::vector<std::string> m_stems;
};

std::unique_ptr<IModelRunner> makeSingle(const std::string& modelsDir,
                                         const std::string& fileName,
                                         int sources,
                                         const std::vector<std::string>& names,
                                         int segment, int overlap,
                                         const std::vector<std::string>& epPriority,
                                         std::string* error)
{
    const std::string path = modelsDir + "/" + fileName;
    if (!fileExists(path)) {
        *error = missingModelError(modelsDir, fileName);
        return nullptr;
    }
    auto model = std::make_unique<OnnxModel>();
    const std::string loadErr = model->load(path, sources, names, segment, overlap, epPriority);
    if (!loadErr.empty()) {
        *error = loadErr;
        return nullptr;
    }
    return model;
}

} // namespace

std::unique_ptr<IModelRunner> ModelResolver::create(const std::string& modelsDir,
                                                    StemMode mode, Quality quality,
                                                    const std::vector<std::string>& epPriority,
                                                    std::string* error)
{
    // The installer supplies a checksummed six-source waveform model.
    // Reuse it for vocal/instrumental mode too, so both visible modes work
    // without requiring an unrelated four-source or spectrogram download.
    const std::string verified = "ms_htdemucs_6s_verified.onnx";
    if (fileExists(modelsDir + "/" + verified))
        return makeSingle(modelsDir, verified, 6, kSixStemsNames,
                          kHtdemucsSegment, kHtdemucsOverlap, epPriority, error);
    switch (mode) {
    case StemMode::TwoStems: {
        if (quality == Quality::Fast) {
            // MDX spectrogram models require a different frontend; never feed PCM to them.
            if (auto runner = makeSingle(modelsDir, "htdemucs_fp16weights.onnx", 4, kHtdemucsNames,
                                         kHtdemucsSegment, kHtdemucsOverlap, epPriority, error))
                return runner;
            return nullptr;
        }
        if (quality == Quality::Best) {
            auto bag = std::make_unique<BagModel>();
            if (bag->load(modelsDir, kHtdemucsNames, epPriority, error)) return bag;
            error->clear();
            if (auto runner = makeSingle(modelsDir, "htdemucs.onnx", 4, kHtdemucsNames,
                                         kHtdemucsSegment, kHtdemucsOverlap, epPriority, error))
                return runner;
            return nullptr;
        }
        // Balanced
        if (auto runner = makeSingle(modelsDir, "htdemucs.onnx", 4, kHtdemucsNames,
                                     kHtdemucsSegment, kHtdemucsOverlap, epPriority, error))
            return runner;
        if (auto runner = makeSingle(modelsDir, "htdemucs_fp16weights.onnx", 4, kHtdemucsNames,
                                     kHtdemucsSegment, kHtdemucsOverlap, epPriority, error))
            return runner;
        return nullptr;
    }

    case StemMode::FourStems: {
        if (quality == Quality::Best) {
            auto bag = std::make_unique<BagModel>();
            if (bag->load(modelsDir, kHtdemucsNames, epPriority, error)) return bag;
            error->clear();
        }
        const std::string preferred = quality == Quality::Fast ? "htdemucs_fp16weights.onnx"
                                                               : "htdemucs.onnx";
        const std::string fallback = preferred == "htdemucs.onnx" ? "htdemucs_fp16weights.onnx"
                                                                  : "htdemucs.onnx";
        if (auto runner = makeSingle(modelsDir, preferred, 4, kHtdemucsNames,
                                     kHtdemucsSegment, kHtdemucsOverlap, epPriority, error))
            return runner;
        error->clear();
        if (auto runner = makeSingle(modelsDir, fallback, 4, kHtdemucsNames,
                                     kHtdemucsSegment, kHtdemucsOverlap, epPriority, error))
            return runner;
        return nullptr;
    }

    case StemMode::SixStems: {
        const std::string fileName = quality == Quality::Fast ? "htdemucs_6s_fp16weights.onnx"
                                                              : "htdemucs_6s.onnx";
        if (auto runner = makeSingle(modelsDir, fileName, 6, kSixStemsNames,
                                     kHtdemucsSegment, kHtdemucsOverlap, epPriority, error))
            return runner;
        error->clear();
        if (auto runner = makeSingle(modelsDir, "htdemucs_6s_fp16weights.onnx", 6, kSixStemsNames,
                                     kHtdemucsSegment, kHtdemucsOverlap, epPriority, error))
            return runner;
        return nullptr;
    }
    }
    if (error) *error = "Unknown separation mode.";
    return nullptr;
}

} // namespace mc
