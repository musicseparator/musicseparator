#pragma once

#include "separation/IModelRunner.h"

#include <algorithm>
#include <cstddef>
#include <functional>
#include <string>
#include <vector>

namespace mc {

// Overlap-add inference over interleaved stereo PCM. Every sample has positive weight.
inline bool runChunkedInference(const float* mix, std::size_t totalFrames,
                                IModelRunner& model,
                                const std::function<bool(double)>& progress,
                                std::vector<std::vector<float>>* stemsOut,
                                std::string* error)
{
    if (!mix || !stemsOut || totalFrames == 0) {
        if (error) *error = "No audio to separate.";
        return false;
    }
    const int segment = model.segmentSize();
    const int overlap = model.overlapSize();
    if (segment <= 0 || overlap <= 0 || overlap >= segment) {
        if (error) *error = "Invalid segment geometry.";
        return false;
    }
    const int stride = segment - overlap;
    const std::size_t nChunks = std::max<std::size_t>(1, (totalFrames + stride - 1) / stride);
    const int sources = model.sources();
    if (sources <= 0) {
        if (error) *error = "Model reports zero sources.";
        return false;
    }

    // Triangular transition window (linear fade in/out over `overlap`).
    std::vector<float> win(static_cast<std::size_t>(segment), 1.0f);
    for (int i = 0; i < overlap; ++i) {
        const float v = static_cast<float>(i + 1) / static_cast<float>(overlap + 1);
        win[static_cast<std::size_t>(i)] = v;
        win[static_cast<std::size_t>(segment - 1 - i)] = v;
    }

    std::vector<std::vector<float>> out(
        static_cast<std::size_t>(sources), std::vector<float>(totalFrames * 2, 0.0f));
    std::vector<float> weight(totalFrames, 0.0f);
    std::vector<float> chunk(static_cast<std::size_t>(segment) * 2, 0.0f);
    std::vector<float> raw(static_cast<std::size_t>(sources) * static_cast<std::size_t>(segment) * 2, 0.0f);

    for (std::size_t i = 0; i < nChunks; ++i) {
        const std::size_t start = i * static_cast<std::size_t>(stride);
        const std::size_t end = std::min(start + static_cast<std::size_t>(segment), totalFrames);
        const std::size_t len = end - start;

        if (progress && !progress(static_cast<double>(i) / static_cast<double>(nChunks))) {
            if (error) *error = "Separation cancelled.";
            return false;
        }
        std::fill(raw.begin(), raw.end(), 0.0f);
        std::fill(chunk.begin(), chunk.end(), 0.0f);
        std::copy(mix + start * 2, mix + end * 2, chunk.begin());

        if (!model.run(chunk.data(), segment, raw.data(), error)) return false;

        for (int s = 0; s < sources; ++s) {
            const float* src = raw.data() + static_cast<std::size_t>(s) * static_cast<std::size_t>(segment) * 2;
            float* dst = out[static_cast<std::size_t>(s)].data() + start * 2;
            for (std::size_t j = 0; j < len; ++j) {
                const float w = win[j];
                dst[j * 2] += src[j * 2] * w;
                dst[j * 2 + 1] += src[j * 2 + 1] * w;
            }
        }
        for (std::size_t j = 0; j < len; ++j)
            weight[start + j] += win[j];

        if (progress && !progress(static_cast<double>(i + 1) / static_cast<double>(nChunks)))
            return false;
    }

    for (int s = 0; s < sources; ++s) {
        float* dst = out[static_cast<std::size_t>(s)].data();
        for (std::size_t j = 0; j < totalFrames; ++j) {
            const float w = std::max(weight[j], 1e-8f);
            dst[j * 2] /= w;
            dst[j * 2 + 1] /= w;
        }
    }

    *stemsOut = std::move(out);
    return true;
}

} // namespace mc
