#pragma once

#include "separation/IModelRunner.h"

#include <onnxruntime_cxx_api.h>

#include <memory>
#include <string>
#include <vector>

namespace mc {

enum class ProviderKind { Cpu, Dml, Cuda };

struct ProviderInfo {
    ProviderKind kind = ProviderKind::Cpu;
    std::string name; // ORT provider name, e.g. "DMLExecutionProvider"
};

// Single ONNX session wrapper. Chooses the best available execution
// provider and falls back to CPU when a GPU EP cannot initialize.
class OnnxModel : public IModelRunner
{
public:
    OnnxModel() = default;
    ~OnnxModel() override;

    OnnxModel(const OnnxModel&) = delete;
    OnnxModel& operator=(const OnnxModel&) = delete;

    // epPriority: provider names in order of preference
    // (e.g. {"CUDAExecutionProvider", "DMLExecutionProvider"}).
    // Returns empty string on success, otherwise a message.
    std::string load(const std::string& path, int sources,
                     const std::vector<std::string>& sourceNames,
                     int segment, int overlap,
                     const std::vector<std::string>& epPriority);

    static std::vector<std::string> availableProviders();

    ProviderInfo provider() const { return m_provider; }

    int sources() const override { return m_sources; }
    std::vector<std::string> sourceNames() const override { return m_names; }
    int segmentSize() const override { return m_segment; }
    int overlapSize() const override { return m_overlap; }
    bool run(const float* chunk, int n, float* out, std::string* error) override;

private:
    std::unique_ptr<Ort::Env> m_env;
    std::unique_ptr<Ort::Session> m_session;
    std::unique_ptr<Ort::MemoryInfo> m_mem;
    int m_sources = 0;
    int m_segment = 0;
    int m_overlap = 0;
    std::vector<std::string> m_names;
    std::string m_inputName = "mix";
    std::string m_outputName = "stems";
    ProviderInfo m_provider{ProviderKind::Cpu, "CPUExecutionProvider"};
};

} // namespace mc
