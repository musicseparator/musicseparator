#pragma once

#include "separation/IModelRunner.h"
#include "separation/SeparationTypes.h"

#include <functional>
#include <string>
#include <vector>

namespace mc {

// Orchestrates the chunked inference and produces the final stems in
// display order. For TwoStems the instrumental stem is derived as
// `mix - vocals`, which guarantees perfect reconstruction.
class StemSeparator
{
public:
    static bool separate(const std::vector<float>& mix, int sampleRate,
                         IModelRunner& model, StemMode mode,
                         const std::function<bool(double)>& progress,
                         QVector<StemResult>* out, std::string* error);
};

} // namespace mc
