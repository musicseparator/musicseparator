#pragma once

#include "audio/AudioDecoder.h"
#include "audio/AudioEngine.h"
#include "common/ErrorCodes.h"
#include "export/AudioExporter.h"
#include "separation/SeparationWorker.h"
#include "ui/ImportDropZone.h"
#include "ui/MixConsoleWidget.h"
#include "ui/ProcessingOverlay.h"
#include "ui/TransportBar.h"
#include "ui/WaveformWidget.h"
#include "youtube/YouTubeImporter.h"

#include <QFutureWatcher>
#include "ui/StudioWindow.h"
#include <QStackedWidget>
#include <QTimer>

class QButtonGroup;
class QComboBox;
class QLabel;
class QPushButton;

namespace mc {

class MainWindow : public StudioWindow
{
    Q_OBJECT
public:
    explicit MainWindow(QWidget* parent = nullptr);

protected:
    void resizeEvent(QResizeEvent* event) override;
    void closeEvent(QCloseEvent* event) override;

private slots:
    void onDecodeFinished();
    void onWorkerProgress(int percent, const QString& stage);
    void onWorkerDone();
    void onWorkerFailed(mc::ErrorCode code, const QString& detail);
    void onExportWorkerProgress(int percent, const QString& stage);
    void onExportWorkerDone();
    void onExportWorkerFailed(mc::ErrorCode code, const QString& detail);

private:
    void buildUi();
    void updateGpuChip();
    void switchToPage(int index);

    void openAudioDialog();
    void openVideoDialog();
    void submitUrl(const QString& url);
    void importPath(const QString& path);
    void decodeFile(const QString& path);
    void showTrackView(const DecodedAudio& decoded);
    void loadCover(const QByteArray& data);

    void onSeparateClicked();
    void onCancelProcessing();

    void updateTransportUi();
    void startExportAll(ExportFormat format);
    void startExportOne(int index);
    void openOutputFolder();

    void openSettings();
    void setBusy(bool busy);

    QString trackTitle() const;
    QString outputFolderForExport() const;

    // --- Services ---
    AudioEngine m_engine;
    YouTubeImporter* m_yt = nullptr;
    QFutureWatcher<DecodedAudio>* m_decodeWatcher = nullptr;
    SeparationWorker* m_worker = nullptr;
    ExportWorker* m_exporter = nullptr;
    QTimer m_uiTimer;

    // --- State ---
    DecodedAudio m_decoded;
    QVector<StemResult> m_stems;
    YtMetadata m_ytMeta;
    bool m_hasYoutubeMeta = false;
    bool m_importCancelled = false;

    // --- UI ---
    QStackedWidget* m_pages = nullptr;
    ImportDropZone* m_dropZone = nullptr;
    ProcessingOverlay* m_overlay = nullptr;
    QLabel* m_gpuChip = nullptr;

    // Track page
    QLabel* m_coverLabel = nullptr;
    QLabel* m_titleLabel = nullptr;
    QLabel* m_metaLabel = nullptr;
    WaveformWidget* m_trackWaveform = nullptr;
    TransportBar* m_trackTransport = nullptr;
    QButtonGroup* m_modeGroup = nullptr;
    QComboBox* m_qualityCombo = nullptr;
    QPushButton* m_separateBtn = nullptr;

    // Mix page
    MixConsoleWidget* m_mix = nullptr;
    QPushButton* m_backBtn = nullptr;
};

} // namespace mc
