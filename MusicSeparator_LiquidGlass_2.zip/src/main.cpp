#include "MainWindow.h"

#include "common/ErrorCodes.h"
#include "ui/Theme.h"

#include <QApplication>
#include <QFile>
#include <QFont>
#include <QIcon>

#include <QMetaType>

int main(int argc, char* argv[])
{
    QApplication app(argc, argv);
    app.setOrganizationName(QStringLiteral("MusicSeparator"));
    app.setApplicationName(QStringLiteral("MusicSeparator"));
    app.setApplicationVersion(QStringLiteral("1.0.0"));
    app.setWindowIcon(QIcon(QStringLiteral(":/icons/app.svg")));

    app.setStyle(QStringLiteral("Fusion"));
    mc::Theme::load();

    qRegisterMetaType<mc::ErrorCode>("mc::ErrorCode");

    mc::MainWindow window;
    window.show();
    return app.exec();
}
