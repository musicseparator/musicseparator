#include "settings/Settings.h"

#include <QDir>
#include <QSettings>
#include <QStandardPaths>

namespace mc {

Settings& Settings::instance()
{
    static Settings s;
    return s;
}

namespace {
constexpr auto kDeviceKey = "processing/device";
constexpr auto kQualityKey = "processing/quality";
constexpr auto kFormatKey = "export/format";
constexpr auto kBitrateKey = "export/mp3Bitrate";
constexpr auto kOutputKey = "export/outputFolder";
}

DevicePref Settings::device() const
{
    const QString v = QSettings().value(kDeviceKey, QStringLiteral("auto")).toString();
    if (v == QLatin1String("cpu")) return DevicePref::Cpu;
    if (v == QLatin1String("gpu")) return DevicePref::Gpu;
    return DevicePref::Auto;
}

void Settings::setDevice(DevicePref value)
{
    const QString v = value == DevicePref::Cpu ? QStringLiteral("cpu")
                    : value == DevicePref::Gpu ? QStringLiteral("gpu")
                                               : QStringLiteral("auto");
    QSettings().setValue(kDeviceKey, v);
}

QualityPref Settings::quality() const
{
    const QString v = QSettings().value(kQualityKey, QStringLiteral("balanced")).toString();
    if (v == QLatin1String("fast")) return QualityPref::Fast;
    if (v == QLatin1String("best")) return QualityPref::Best;
    return QualityPref::Balanced;
}

void Settings::setQuality(QualityPref value)
{
    const QString v = value == QualityPref::Fast ? QStringLiteral("fast")
                    : value == QualityPref::Best ? QStringLiteral("best")
                                                 : QStringLiteral("balanced");
    QSettings().setValue(kQualityKey, v);
}

ExportFormatPref Settings::exportFormat() const
{
    const QString v = QSettings().value(kFormatKey, QStringLiteral("wav")).toString();
    if (v == QLatin1String("mp3")) return ExportFormatPref::Mp3;
    if (v == QLatin1String("flac")) return ExportFormatPref::Flac;
    return ExportFormatPref::Wav;
}

void Settings::setExportFormat(ExportFormatPref value)
{
    const QString v = value == ExportFormatPref::Mp3 ? QStringLiteral("mp3")
                    : value == ExportFormatPref::Flac ? QStringLiteral("flac")
                                                      : QStringLiteral("wav");
    QSettings().setValue(kFormatKey, v);
}

int Settings::mp3Bitrate() const
{
    return QSettings().value(kBitrateKey, 320).toInt();
}

void Settings::setMp3Bitrate(int kbps)
{
    QSettings().setValue(kBitrateKey, kbps);
}

QString Settings::outputFolder() const
{
    return QSettings().value(kOutputKey).toString();
}

void Settings::setOutputFolder(const QString& path)
{
    QSettings().setValue(kOutputKey, path);
}

QString Settings::effectiveOutputFolder() const
{
    const QString custom = outputFolder();
    if (!custom.isEmpty()) return custom;
    return QStandardPaths::writableLocation(QStandardPaths::MusicLocation)
           + QStringLiteral("/MusicSeparator");
}

QString deviceLabel(DevicePref value)
{
    switch (value) {
    case DevicePref::Cpu:  return QStringLiteral("CPU");
    case DevicePref::Gpu:  return QStringLiteral("GPU");
    case DevicePref::Auto: return QStringLiteral("Auto");
    }
    return QStringLiteral("Auto");
}

QString qualityLabel(QualityPref value)
{
    switch (value) {
    case QualityPref::Fast:     return QStringLiteral("Fast");
    case QualityPref::Balanced: return QStringLiteral("Balanced");
    case QualityPref::Best:     return QStringLiteral("Best Quality");
    }
    return QStringLiteral("Balanced");
}

QString exportFormatLabel(ExportFormatPref value)
{
    switch (value) {
    case ExportFormatPref::Wav:  return QStringLiteral("WAV");
    case ExportFormatPref::Mp3:  return QStringLiteral("MP3");
    case ExportFormatPref::Flac: return QStringLiteral("FLAC");
    }
    return QStringLiteral("WAV");
}

} // namespace mc
