#pragma once

#include <QString>

namespace mc {

enum class DevicePref { Auto, Cpu, Gpu };
enum class QualityPref { Fast, Balanced, Best };
enum class ExportFormatPref { Wav, Mp3, Flac };

// Persistent user settings (QSettings). Thread-safe reads are done on
// the main thread only.
class Settings
{
public:
    static Settings& instance();

    DevicePref device() const;
    void setDevice(DevicePref value);

    QualityPref quality() const;
    void setQuality(QualityPref value);

    ExportFormatPref exportFormat() const;
    void setExportFormat(ExportFormatPref value);

    int mp3Bitrate() const;
    void setMp3Bitrate(int kbps);

    // Empty string = automatic (source folder).
    QString outputFolder() const;
    void setOutputFolder(const QString& path);

    QString effectiveOutputFolder() const;

private:
    Settings() = default;
};

QString deviceLabel(DevicePref value);
QString qualityLabel(QualityPref value);
QString exportFormatLabel(ExportFormatPref value);

} // namespace mc
