#pragma once

#include "settings/Settings.h"

#include <QDialog>

namespace mc {

class SettingsDialog : public QDialog
{
    Q_OBJECT
public:
    explicit SettingsDialog(QWidget* parent = nullptr);

signals:
    void settingsChanged();

private:
    void apply();

    DevicePref m_device = DevicePref::Auto;
    QualityPref m_quality = QualityPref::Balanced;
    ExportFormatPref m_format = ExportFormatPref::Wav;
    QString m_outputFolder;
};

} // namespace mc
