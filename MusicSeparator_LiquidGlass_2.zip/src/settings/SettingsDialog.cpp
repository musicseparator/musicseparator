#include "settings/SettingsDialog.h"
#include "ui/AppearanceDialog.h"

#include <QComboBox>
#include <QDialogButtonBox>
#include <QFileDialog>
#include <QFormLayout>
#include <QHBoxLayout>
#include <QLabel>
#include <QLineEdit>
#include <QPushButton>
#include <QVBoxLayout>

namespace mc {

SettingsDialog::SettingsDialog(QWidget* parent)
    : QDialog(parent)
{
    setWindowTitle(tr("Settings"));
    setModal(true);
    setMinimumWidth(440);

    auto* root = new QVBoxLayout(this);
    root->setContentsMargins(24, 24, 24, 20);
    root->setSpacing(12);

    auto* appearance = new QPushButton(tr("Customize appearance…"),this);
    connect(appearance,&QPushButton::clicked,this,[this] { AppearanceDialog dialog(this); dialog.exec(); });
    root->addWidget(appearance);
    auto* form = new QFormLayout();
    form->setSpacing(14);
    form->setLabelAlignment(Qt::AlignLeft);

    auto* deviceCombo = new QComboBox(this);
    deviceCombo->addItem(QStringLiteral("Auto"), static_cast<int>(DevicePref::Auto));
    deviceCombo->addItem(QStringLiteral("CPU"), static_cast<int>(DevicePref::Cpu));
    deviceCombo->addItem(QStringLiteral("GPU"), static_cast<int>(DevicePref::Gpu));
    deviceCombo->setCurrentIndex(deviceCombo->findData(static_cast<int>(Settings::instance().device())));
    form->addRow(tr("Processing device"), deviceCombo);

    auto* qualityCombo = new QComboBox(this);
    qualityCombo->addItem(QStringLiteral("Fast"), static_cast<int>(QualityPref::Fast));
    qualityCombo->addItem(QStringLiteral("Balanced"), static_cast<int>(QualityPref::Balanced));
    qualityCombo->addItem(QStringLiteral("Best Quality"), static_cast<int>(QualityPref::Best));
    qualityCombo->setCurrentIndex(qualityCombo->findData(static_cast<int>(Settings::instance().quality())));
    form->addRow(tr("Separation quality"), qualityCombo);

    auto* formatCombo = new QComboBox(this);
    formatCombo->addItem(QStringLiteral("WAV (lossless float)"), static_cast<int>(ExportFormatPref::Wav));
    formatCombo->addItem(QStringLiteral("MP3 (320 kbps)"), static_cast<int>(ExportFormatPref::Mp3));
    formatCombo->addItem(QStringLiteral("FLAC (lossless)"), static_cast<int>(ExportFormatPref::Flac));
    formatCombo->setCurrentIndex(formatCombo->findData(static_cast<int>(Settings::instance().exportFormat())));
    form->addRow(tr("Export format"), formatCombo);

    auto* outRow = new QHBoxLayout();
    auto* outEdit = new QLineEdit(Settings::instance().outputFolder(), this);
    outEdit->setPlaceholderText(tr("Automatic (Music/MusicSeparator)"));
    outEdit->setReadOnly(true);
    auto* browseBtn = new QPushButton(tr("Browse…"), this);
    browseBtn->setObjectName(QStringLiteral("ghostButton"));
    outRow->addWidget(outEdit, 1);
    outRow->addWidget(browseBtn);
    form->addRow(tr("Output folder"), outRow);
    root->addLayout(form);

    connect(browseBtn, &QPushButton::clicked, this, [this, outEdit] {
        const QString dir = QFileDialog::getExistingDirectory(
            this, tr("Choose output folder"),
            outEdit->text().isEmpty() ? Settings::instance().effectiveOutputFolder()
                                      : outEdit->text());
        if (!dir.isEmpty()) outEdit->setText(dir);
    });

    auto* box = new QDialogButtonBox(QDialogButtonBox::Ok | QDialogButtonBox::Cancel, this);
    connect(box, &QDialogButtonBox::accepted, this, [this, deviceCombo, qualityCombo, formatCombo, outEdit] {
        m_device = static_cast<DevicePref>(deviceCombo->currentData().toInt());
        m_quality = static_cast<QualityPref>(qualityCombo->currentData().toInt());
        m_format = static_cast<ExportFormatPref>(formatCombo->currentData().toInt());
        m_outputFolder = outEdit->text();
        apply();
        accept();
    });
    connect(box, &QDialogButtonBox::rejected, this, &QDialog::reject);
    root->addWidget(box);
}

void SettingsDialog::apply()
{
    Settings::instance().setDevice(m_device);
    Settings::instance().setQuality(m_quality);
    Settings::instance().setExportFormat(m_format);
    Settings::instance().setOutputFolder(m_outputFolder);
    emit settingsChanged();
}

} // namespace mc
