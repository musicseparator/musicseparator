#include "youtube/YtDlpRunner.h"

#include <QDir>
#include <QFileInfo>
#include <QJsonDocument>
#include <QJsonParseError>
#include <QRegularExpression>

namespace mc {

YtDlpRunner::YtDlpRunner(const QString& ytDlpPath, QObject* parent)
    : QObject(parent)
    , m_path(ytDlpPath)
{
}

bool YtDlpRunner::available() const
{
    return QFileInfo::exists(m_path);
}

bool YtDlpRunner::isBusy() const
{
    return m_process != nullptr && m_process->state() != QProcess::NotRunning;
}

void YtDlpRunner::cancel()
{
    if (m_process && m_process->state() != QProcess::NotRunning)
        m_process->kill();
}

void YtDlpRunner::fetchInfoJson(const QString& url)
{
    if (isBusy()) return;
    m_process = new QProcess(this);
    m_process->setProcessChannelMode(QProcess::SeparateChannels);
    connect(m_process, qOverload<int, QProcess::ExitStatus>(&QProcess::finished),
            this, [this](int exitCode, QProcess::ExitStatus) { onInfoFinished(exitCode); });

    QStringList args;
    args << QStringLiteral("-J") << QStringLiteral("--no-playlist")
         << QStringLiteral("--no-warnings") << QStringLiteral("--skip-download")
         << url;
    m_process->start(m_path, args);
}

void YtDlpRunner::downloadAudio(const QString& url, const QString& videoId,
                                const QString& outputDir)
{
    if (isBusy()) return;
    m_downloadDir = outputDir;
    m_downloadId = videoId;
    QDir().mkpath(outputDir);
    const QString templatePath = QDir(outputDir).filePath(videoId + QStringLiteral(".%(ext)s"));

    m_process = new QProcess(this);
    m_process->setProcessChannelMode(QProcess::SeparateChannels);
    connect(m_process, qOverload<int, QProcess::ExitStatus>(&QProcess::finished),
            this, [this](int exitCode, QProcess::ExitStatus) { onDownloadFinished(exitCode); });
    connect(m_process, &QProcess::readyReadStandardError,
            this, &YtDlpRunner::onDownloadStderr);

    QStringList args;
    args << QStringLiteral("--no-playlist") << QStringLiteral("--no-warnings")
         << QStringLiteral("--newline") << QStringLiteral("-f")
         << QStringLiteral("bestaudio[ext=m4a]/bestaudio/best")
         << QStringLiteral("-o") << templatePath
         << url;
    m_process->start(m_path, args);
}

void YtDlpRunner::onInfoFinished(int exitCode)
{
    const QByteArray stdoutBytes = m_process->readAllStandardOutput();
    const QString stderrText = QString::fromUtf8(m_process->readAllStandardError());
    m_process->deleteLater();
    m_process = nullptr;

    if (exitCode != 0) {
        emit infoFailed(stderrText);
        return;
    }

    QJsonParseError parseError{};
    const QJsonDocument doc = QJsonDocument::fromJson(stdoutBytes, &parseError);
    if (parseError.error != QJsonParseError::NoError || !doc.isObject()) {
        emit infoFailed(QStringLiteral("Could not parse yt-dlp output: %1")
                            .arg(parseError.errorString()));
        return;
    }
    emit infoJsonReady(doc.object());
}

void YtDlpRunner::onDownloadFinished(int exitCode)
{
    const QString stderrText = QString::fromUtf8(m_process->readAllStandardError());
    m_process->deleteLater();
    m_process = nullptr;

    if (exitCode != 0) {
        emit downloadFailed(stderrText);
        return;
    }

    const QDir dir(m_downloadDir);
    QString found;
    const QStringList entries = dir.entryList(QDir::Files, QDir::Time);
    for (const QString& entry : entries) {
        if (entry.startsWith(m_downloadId + QLatin1Char('.'))) {
            found = dir.filePath(entry);
            break;
        }
    }
    if (found.isEmpty()) {
        emit downloadFailed(QStringLiteral("yt-dlp finished but no audio file was produced."));
        return;
    }
    emit downloadFinished(found);
}

void YtDlpRunner::onDownloadStderr()
{
    if (!m_process) return;
    const QByteArray bytes = m_process->readAllStandardError();
    const QString text = QString::fromUtf8(bytes);
    const QStringList lines = text.split(QLatin1Char('\n'));

    static const QRegularExpression percentRe(QStringLiteral("(\\d+(?:\\.\\d+)?)%"));
    for (const QString& line : lines) {
        const QString trimmed = line.trimmed();
        if (trimmed.startsWith(QStringLiteral("[download]")) &&
            trimmed.contains(QStringLiteral("% of"))) {
            const QRegularExpressionMatch match = percentRe.match(trimmed);
            if (match.hasMatch())
                emit downloadProgress(match.captured(1).toDouble(), trimmed);
        } else if (trimmed.startsWith(QStringLiteral("[Merger]")) ||
                   trimmed.startsWith(QStringLiteral("[ExtractAudio]"))) {
            emit downloadProgress(-1.0, trimmed);
        }
    }
}

} // namespace mc
