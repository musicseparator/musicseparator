#pragma once

#include <QJsonObject>
#include <QObject>
#include <QProcess>
#include <QString>

namespace mc {

// Thin wrapper around the yt-dlp.exe subprocess. Kept separate from
// YouTubeImporter so the whole YouTube pipeline can be re-pointed at a
// different backend (API, invidious, ...) without touching the UI.
class YtDlpRunner : public QObject
{
    Q_OBJECT
public:
    explicit YtDlpRunner(const QString& ytDlpPath, QObject* parent = nullptr);

    bool available() const;
    bool isBusy() const;

    // Fetches the full info JSON for a video (-J).
    void fetchInfoJson(const QString& url);

    // Downloads the best audio-only stream to
    // `outputDir/<videoId>.<ext>`.
    void downloadAudio(const QString& url, const QString& videoId,
                       const QString& outputDir);

    void cancel();

signals:
    void infoJsonReady(const QJsonObject& info);
    void infoFailed(const QString& stderrText);

    void downloadProgress(double percent, const QString& status);
    void downloadFinished(const QString& filePath);
    void downloadFailed(const QString& stderrText);

private slots:
    void onInfoFinished(int exitCode);
    void onDownloadFinished(int exitCode);
    void onDownloadStderr();

private:
    void startInfoProcess(const QString& url);
    void startDownloadProcess(const QString& url, const QString& outputTemplate);

    QString m_path;
    QProcess* m_process = nullptr;
    QString m_downloadDir;
    QString m_downloadId;
};

} // namespace mc
