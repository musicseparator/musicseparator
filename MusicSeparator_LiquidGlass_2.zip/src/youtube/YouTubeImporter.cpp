#include "youtube/YouTubeImporter.h"

#include "AppContext.h"

#include <QFileInfo>
#include <QJsonObject>
#include <QNetworkReply>
#include <QUrl>

namespace mc {

namespace {

ErrorCode mapYtError(const QString& stderrText)
{
    const QString t = stderrText.toLower();
    if (t.contains(QStringLiteral("unsupported url")) ||
        t.contains(QStringLiteral("not a valid url")))
        return ErrorCode::YoutubeInvalidUrl;
    if (t.contains(QStringLiteral("video unavailable")) ||
        t.contains(QStringLiteral("private video")) ||
        t.contains(QStringLiteral("sign in")) ||
        t.contains(QStringLiteral("age-restricted")) ||
        t.contains(QStringLiteral("playback on other websites")) ||
        t.contains(QStringLiteral("copyright")))
        return ErrorCode::YoutubeUnavailable;
    return ErrorCode::YoutubeDownloadFailed;
}

} // namespace

YouTubeImporter::YouTubeImporter(QObject* parent)
    : QObject(parent)
    , m_runner(AppContext::ytDlpPath(), this)
{
    qRegisterMetaType<mc::YtMetadata>("mc::YtMetadata");
    connect(&m_runner, &YtDlpRunner::infoJsonReady, this, &YouTubeImporter::onInfoJson);
    connect(&m_runner, &YtDlpRunner::infoFailed, this, &YouTubeImporter::onInfoFailed);
    connect(&m_runner, &YtDlpRunner::downloadProgress, this, &YouTubeImporter::downloadProgress);
    connect(&m_runner, &YtDlpRunner::downloadFinished, this, &YouTubeImporter::audioDownloaded);
    connect(&m_runner, &YtDlpRunner::downloadFailed, this, [this](const QString& stderrText) {
        emit downloadFailed(mapYtError(stderrText), stderrText.trimmed());
    });
}

bool YouTubeImporter::isUsable() const
{
    return m_runner.available();
}

bool YouTubeImporter::isYouTubeUrl(const QString& url) const
{
    const QString host = QUrl(url).host().toLower();
    return host == QLatin1String("www.youtube.com") || host == QLatin1String("youtube.com") ||
           host == QLatin1String("youtu.be") || host == QLatin1String("m.youtube.com") ||
           host == QLatin1String("music.youtube.com");
}

bool YouTubeImporter::isBusy() const
{
    return m_runner.isBusy() || m_fetching;
}

void YouTubeImporter::fetchMetadata(const QString& url)
{
    if (m_runner.isBusy()) return;
    m_fetching = true;
    m_meta = YtMetadata{};
    m_runner.fetchInfoJson(url);
}

void YouTubeImporter::downloadAudio(const YtMetadata& meta)
{
    if (m_runner.isBusy()) return;
    m_runner.downloadAudio(meta.webpageUrl.isEmpty() ? QStringLiteral("https://www.youtube.com/watch?v=") + meta.id
                                                     : meta.webpageUrl,
                           meta.id, AppContext::tempDir());
}

void YouTubeImporter::cancel()
{
    m_runner.cancel();
    m_fetching = false;
}

void YouTubeImporter::onInfoJson(const QJsonObject& info)
{
    m_fetching = false;
    YtMetadata meta;
    meta.id = info.value(QStringLiteral("id")).toString();
    meta.title = info.value(QStringLiteral("title")).toString();
    meta.uploader = info.value(QStringLiteral("uploader")).toString();
    meta.durationSeconds = info.value(QStringLiteral("duration")).toDouble();
    meta.thumbnailUrl = info.value(QStringLiteral("thumbnail")).toString();
    meta.webpageUrl = info.value(QStringLiteral("webpage_url")).toString();
    meta.valid = !meta.id.isEmpty() && !meta.title.isEmpty();
    if (!meta.valid) {
        emit metadataFailed(ErrorCode::YoutubeUnavailable,
                            QStringLiteral("yt-dlp returned incomplete metadata."));
        return;
    }
    m_meta = meta;
    emit metadataReady(meta);

    // Fetch the thumbnail (fire and forget).
    if (!meta.thumbnailUrl.isEmpty()) {
        QNetworkRequest request{QUrl(meta.thumbnailUrl)};
        request.setTransferTimeout(10000);
        QNetworkReply* reply = m_net.get(request);
        connect(reply, &QNetworkReply::finished, this, &YouTubeImporter::onThumbnailDownloaded);
    }
}

void YouTubeImporter::onInfoFailed(const QString& stderrText)
{
    m_fetching = false;
    emit metadataFailed(mapYtError(stderrText), stderrText.trimmed());
}

void YouTubeImporter::onThumbnailDownloaded()
{
    auto* reply = qobject_cast<QNetworkReply*>(sender());
    if (!reply) return;
    reply->deleteLater();
    if (reply->error() != QNetworkReply::NoError) return;

    const QImage image = QImage::fromData(reply->readAll());
    if (!image.isNull()) {
        const QString path = AppContext::tempDir() + QStringLiteral("/thumb_") + m_meta.id + QStringLiteral(".jpg");
        image.save(path, "JPG", 90);
    }
}

} // namespace mc
