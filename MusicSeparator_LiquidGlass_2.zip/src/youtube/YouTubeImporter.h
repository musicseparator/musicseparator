#pragma once

#include "youtube/YtDlpRunner.h"
#include "common/ErrorCodes.h"

#include <QImage>
#include <QNetworkAccessManager>
#include <QObject>
#include <QString>

namespace mc {

struct YtMetadata {
    QString id;
    QString title;
    QString uploader;
    double durationSeconds = 0.0;
    QString thumbnailUrl;
    QString webpageUrl;
    bool valid = false;
};

// Isolated YouTube front-end. All yt-dlp specifics live in YtDlpRunner;
// this class maps results onto the rest of the app and can be swapped
// for another backend without touching the UI.
class YouTubeImporter : public QObject
{
    Q_OBJECT
public:
    explicit YouTubeImporter(QObject* parent = nullptr);

    bool isUsable() const;          // yt-dlp.exe present
    bool isYouTubeUrl(const QString& url) const;
    bool isBusy() const;

    // Step 1: metadata (+ thumbnail download).
    void fetchMetadata(const QString& url);

    // Step 2: best audio-only stream -> tempDir/<id>.<ext>.
    void downloadAudio(const YtMetadata& meta);

    void cancel();

    const YtMetadata& metadata() const { return m_meta; }

signals:
    void metadataReady(const mc::YtMetadata& meta);
    void metadataFailed(mc::ErrorCode code, const QString& detail);

    void downloadProgress(double percent, const QString& status);
    void audioDownloaded(const QString& filePath);
    void downloadFailed(mc::ErrorCode code, const QString& detail);

private slots:
    void onInfoJson(const QJsonObject& info);
    void onInfoFailed(const QString& stderrText);
    void onThumbnailDownloaded();

private:
    YtDlpRunner m_runner;
    QNetworkAccessManager m_net;
    YtMetadata m_meta;
    bool m_fetching = false;
};

} // namespace mc

Q_DECLARE_METATYPE(mc::YtMetadata)
