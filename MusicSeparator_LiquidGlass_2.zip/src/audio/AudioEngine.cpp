#include "audio/AudioEngine.h"

#include <QMediaDevices>

#include <algorithm>
#include <QtGlobal>

namespace mc {

#if QT_VERSION >= QT_VERSION_CHECK(6, 7, 0)
namespace AudioState = QtAudio;
#else
namespace AudioState = QAudio;
#endif

AudioEngine::AudioEngine(QObject* parent)
    : QObject(parent)
{
    m_device = new MixerDevice(this);
    m_device->open(QIODevice::ReadOnly | QIODevice::Unbuffered);
    initializeOutput();
}

bool AudioEngine::initializeOutput()
{
    if (m_sink) return true;
    const auto out = QMediaDevices::defaultAudioOutput();
    if (out.isNull()) return false;
    QAudioFormat fmt;
    fmt.setSampleRate(44100);
    fmt.setChannelCount(2);
    fmt.setSampleFormat(QAudioFormat::Float);
    if (!out.isFormatSupported(fmt)) {
        fmt.setSampleFormat(QAudioFormat::Int16);
        if (!out.isFormatSupported(fmt)) return false;
    }
    m_floatOutput = fmt.sampleFormat() == QAudioFormat::Float;
    m_device->setFloatOutput(m_floatOutput);
    m_device->setChannels(2);
    m_sink = std::make_unique<QAudioSink>(out, fmt);
    m_sink->setVolume(1.0);
    connect(m_sink.get(), &QAudioSink::stateChanged, this, [this] {
        if (!m_device->isPlaying()) return;
        if (m_sink->error() != AudioState::NoError) {
            m_device->setPlaying(false);
            emit playbackStateChanged(false);
            emit playbackError(tr("Audio output failed (code %1). Check the Windows output device and volume mixer, then try Play again.").arg(int(m_sink->error())));
        } else if (m_sink->state() == AudioState::IdleState && m_device->atEnd()) {
            m_device->setPlaying(false);
            emit playbackStateChanged(false);
            emit playbackFinished();
        }
    });
    m_available = true;
    return true;
}

AudioEngine::~AudioEngine()
{
    m_device->setPlaying(false);
    if (m_sink) m_sink->reset();
}

void AudioEngine::loadOriginal(const AudioBuffer& buffer)
{
    clear(); // Stop audio BEFORE releasing any PCM referenced by readData.
    m_buffers.append(buffer);
    m_trackPtrs.append(&m_buffers[0]);
    m_device->setTracks(m_trackPtrs);
}

void AudioEngine::setStemBuffers(const QVector<AudioBuffer*>& stems)
{
    clear();
    m_trackPtrs = stems;
    m_device->setTracks(m_trackPtrs);
}

void AudioEngine::clear()
{
    m_device->setPlaying(false);
    if (m_sink) m_sink->reset();
    m_device->clear();
    m_trackPtrs.clear();
    m_buffers.clear();
    emit playbackStateChanged(false);
}

bool AudioEngine::startPlayback()
{
    if (isPlaying()) return true;
    if (m_trackPtrs.isEmpty() || m_device->totalFrames() <= 0) {
        emit playbackStateChanged(false);
        return false;
    }
    if (!initializeOutput()) {
        emit playbackStateChanged(false);
        emit playbackError(tr("No compatible audio output is available. Select speakers or headphones in Windows (stereo, 44100 Hz), then try Play again."));
        return false;
    }
    if (m_device->atEnd()) {
        m_sink->reset();
        m_device->setPlayhead(0.0);
    }
    m_device->setPlaying(true);
    if (m_sink->state() == AudioState::SuspendedState) m_sink->resume();
    else {
        m_sink->reset();
        m_sink->start(m_device);
    }
    const bool playing = m_device->isPlaying() && m_sink->error() == AudioState::NoError;
    m_device->setPlaying(playing);
    emit playbackStateChanged(playing);
    return playing;
}

void AudioEngine::pause()
{
    if (!m_available) return;
    // suspend() keeps the sink in SuspendedState so resume() works correctly next time.
    if (m_sink) m_sink->suspend();
    m_device->setPlaying(false);
    emit playbackStateChanged(false);
}

void AudioEngine::togglePlayback()
{
    if (isPlaying()) pause();
    else startPlayback();
}

void AudioEngine::stop()
{
    if (!m_available) return;
    m_device->setPlaying(false);
    if (m_sink) m_sink->stop();
    m_device->setPlayhead(0.0);
    emit playbackStateChanged(false);
}

void AudioEngine::seekToFraction(double fraction) { seekToSeconds(durationSeconds() * fraction); }
void AudioEngine::seekToSeconds(double seconds)
{
    const bool resume = isPlaying();
    m_device->setPlaying(false);
    if (m_sink) m_sink->reset(); // Discard audio queued before the seek.
    m_device->setPlayhead(seconds * 44100.0);
    if (resume && !m_device->atEnd()) startPlayback();
    else emit playbackStateChanged(false);
}
bool AudioEngine::isPlaying() const { return m_device->isPlaying(); }
double AudioEngine::positionSeconds() const { return m_device->playhead() / 44100.0; }
double AudioEngine::durationSeconds() const { return m_device->totalFrames() / 44100.0; }
double AudioEngine::positionFraction() const
{
    const double total = durationSeconds();
    return total > 0.0 ? std::clamp(positionSeconds() / total, 0.0, 1.0) : 0.0;
}
int AudioEngine::trackCount() const { return static_cast<int>(m_trackPtrs.size()); }
void AudioEngine::setTrackGain(int i, float g) { m_device->setGain(i, g); }
void AudioEngine::setTrackMuted(int i, bool m) { m_device->setMuted(i, m); }
void AudioEngine::setTrackSolo(int i, bool s) { m_device->setSolo(i, s); }
bool AudioEngine::trackMuted(int i) const { return m_device->trackMuted(i); }
bool AudioEngine::trackSolo(int i) const { return m_device->trackSolo(i); }
float AudioEngine::trackGain(int i) const { return m_device->trackGain(i); }

} // namespace mc
