#include "audio/Waveform.h"

#include <algorithm>
#include <cmath>

namespace mc {
namespace Waveform {

void computePeaks(const float* pcm, std::size_t frames, int channels, int width,
                  WavePeaks* out)
{
    if (!out || width <= 0 || frames == 0 || channels <= 0) {
        if (out) {
            out->width = 0;
            out->minVals.clear();
            out->maxVals.clear();
        }
        return;
    }
    if (pcm == nullptr) {
        out->width = width;
        out->minVals.assign(static_cast<std::size_t>(width), 0.0f);
        out->maxVals.assign(static_cast<std::size_t>(width), 0.0f);
        return;
    }

    out->width = width;
    out->minVals.assign(static_cast<std::size_t>(width), 0.0f);
    out->maxVals.assign(static_cast<std::size_t>(width), 0.0f);

    const double framesPerBin = static_cast<double>(frames) / width;
    std::size_t bin = 0;
    float binMin = 0.0f;
    float binMax = 0.0f;
    double nextBoundary = framesPerBin;

    for (std::size_t f = 0; f < frames; ++f) {
        float v = std::fabs(pcm[f * static_cast<std::size_t>(channels)]);
        for (int c = 1; c < channels; ++c)
            v = std::max(v, std::fabs(pcm[f * static_cast<std::size_t>(channels) + c]));

        if (bin == 0 && f == 0) {
            binMin = binMax = v;
        } else if (f < frames) {
            binMin = std::min(binMin, v);
            binMax = std::max(binMax, v);
        }

        while (static_cast<double>(f + 1) >= nextBoundary && bin + 1 < static_cast<std::size_t>(width)) {
            out->minVals[bin] = binMin;
            out->maxVals[bin] = binMax;
            ++bin;
            nextBoundary = (bin + 1) * framesPerBin;
            binMin = binMax = v;
        }
    }
    out->minVals[bin] = binMin;
    out->maxVals[bin] = binMax;
}

} // namespace Waveform
} // namespace mc
