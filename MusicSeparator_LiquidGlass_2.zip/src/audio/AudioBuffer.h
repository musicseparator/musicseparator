#pragma once

#include <QString>
#include <vector>

namespace mc {

// Interleaved stereo float32 PCM at 44.1 kHz — the canonical format
// used by the decoder, the model and the playback engine.
struct AudioBuffer {
    QString name;
    std::vector<float> pcm; // interleaved L/R
    int sampleRate = 44100;
    int channels = 2;

    double durationSeconds() const
    {
        if (sampleRate <= 0 || channels <= 0) return 0.0;
        return static_cast<double>(pcm.size()) / (channels * sampleRate);
    }
};

} // namespace mc
