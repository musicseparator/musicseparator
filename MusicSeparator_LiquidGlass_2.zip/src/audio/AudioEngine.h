#pragma once

#include "audio/AudioBuffer.h"
#include "audio/MixerDevice.h"

#include <QAudioFormat>
#include <QAudioSink>
#include <QObject>
#include <QVector>

#include <memory>

namespace mc {

// Owns the output audio device and the MixerDevice. All stems share a
// single master playhead, so playback is sample-accurate across tracks.
// Transport calls are safe from the UI thread.
class AudioEngine : public QObject
{
    Q_OBJECT
public:
    explicit AudioEngine(QObject* parent = nullptr);
    ~AudioEngine() override;

    bool audioAvailable() const { return m_available; }

    void loadOriginal(const AudioBuffer& buffer);
    // References buffers owned by the caller (no copy) — used for stems
    // to avoid duplicating hundreds of MB of PCM.
    void setStemBuffers(const QVector<AudioBuffer*>& stems);
    void clear();

    bool startPlayback();
    void pause();
    void togglePlayback();
    void stop();
    void seekToFraction(double fraction);
    void seekToSeconds(double seconds);

    bool isPlaying() const;
    double positionSeconds() const;
    double durationSeconds() const;
    double positionFraction() const;

    int trackCount() const;
    void setTrackGain(int index, float gain);
    void setTrackMuted(int index, bool muted);
    void setTrackSolo(int index, bool solo);
    bool trackMuted(int index) const;
    bool trackSolo(int index) const;
    float trackGain(int index) const;

signals:
    void playbackError(const QString& message);
    void playbackFinished();
    void playbackStateChanged(bool playing);

private:
    bool initializeOutput();
    bool m_available = false;
    bool m_floatOutput = true;
    std::unique_ptr<QAudioSink> m_sink;
    MixerDevice* m_device = nullptr;
    QVector<AudioBuffer> m_buffers; // owns the PCM
    QVector<AudioBuffer*> m_trackPtrs;
};

} // namespace mc
