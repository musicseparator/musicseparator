#pragma once

#include "audio/AudioBuffer.h"
#include "common/ErrorCodes.h"

#include <QByteArray>
#include <QString>

namespace mc {

struct DecodedAudio {
    AudioBuffer buffer;
    QString title;
    QString artist;
    QString album;
    QByteArray coverData;      // raw JPEG/PNG bytes of the embedded art
    QString containerLabel;    // human-readable format, e.g. "MP3 • 3:45 • 44.1 kHz"
    QString codecName;
    ErrorCode error = ErrorCode::None;
    QString errorDetail;
};

// Decodes MP3 / WAV / MP4 / M4A / FLAC / OGG / AAC to the canonical
// float32 stereo 44.1 kHz format using FFmpeg. Also extracts tags and
// embedded cover art. Safe to call from a worker thread.
class AudioDecoder
{
public:
    static ErrorCode decodeFile(const QString& filePath, DecodedAudio* out);
};

} // namespace mc
