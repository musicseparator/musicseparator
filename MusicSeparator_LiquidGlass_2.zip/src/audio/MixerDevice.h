#pragma once

#include "audio/AudioBuffer.h"

#include <QIODevice>
#include <QMutex>
#include <QVector>

#include <atomic>
#include <cstdint>

namespace mc {

// Sequential PCM source. The mutex protects mixing, seeking and track replacement.
// Owners must stop the sink before destroying referenced buffers.
class MixerDevice : public QIODevice
{
    Q_OBJECT
public:
    explicit MixerDevice(QObject* parent = nullptr);

    void setTracks(const QVector<AudioBuffer*>& tracks);
    void clear();

    void setFloatOutput(bool floating);
    void setChannels(int channels);

    void setPlaying(bool playing);
    bool isPlaying() const;
    void setPlayhead(double frames);
    double playhead() const;
    double totalFrames() const;
    bool atEnd() const override;
    bool isSequential() const override { return true; }
    qint64 bytesAvailable() const override;

    void setGain(int index, float gain);
    void setMuted(int index, bool muted);
    void setSolo(int index, bool solo);
    bool trackMuted(int index) const;
    bool trackSolo(int index) const;
    float trackGain(int index) const;

signals:
    void finished();

protected:
    qint64 readData(char* data, qint64 maxlen) override;
    qint64 writeData(const char*, qint64) override { return -1; }

private:
    // Called with m_mutex already held.
    double totalFramesLocked() const;

    QVector<AudioBuffer*> m_tracks;
    QVector<float> m_gains;
    QVector<bool> m_muted;
    QVector<bool> m_solo;
    mutable QMutex m_mutex;
    std::atomic<bool> m_playing{false};
    double m_playheadFrames = 0.0;
    bool m_floatOutput = true;
    int m_channels = 2;
};

} // namespace mc
