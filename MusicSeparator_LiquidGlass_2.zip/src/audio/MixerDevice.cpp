#include "audio/MixerDevice.h"

#include <algorithm>
#include <cmath>
#include <cstring>

namespace mc {

MixerDevice::MixerDevice(QObject* parent) : QIODevice(parent) {}

void MixerDevice::setTracks(const QVector<AudioBuffer*>& tracks)
{
    QMutexLocker lock(&m_mutex);
    m_tracks = tracks;
    m_gains.assign(static_cast<qsizetype>(tracks.size()), 1.0f);
    m_muted.assign(static_cast<qsizetype>(tracks.size()), false);
    m_solo.assign(static_cast<qsizetype>(tracks.size()), false);
    m_playheadFrames = 0.0;


}

void MixerDevice::clear()
{
    QMutexLocker lock(&m_mutex);
    m_tracks.clear(); m_gains.clear(); m_muted.clear(); m_solo.clear();
    m_playheadFrames = 0.0;
}

void MixerDevice::setFloatOutput(bool floating) { m_floatOutput = floating; }
void MixerDevice::setChannels(int channels) { m_channels = channels; }
void MixerDevice::setPlaying(bool playing) { m_playing.store(playing, std::memory_order_relaxed); }
bool MixerDevice::isPlaying() const { return m_playing.load(std::memory_order_relaxed); }

void MixerDevice::setPlayhead(double frames)
{
    QMutexLocker lock(&m_mutex);
    m_playheadFrames = std::floor(std::clamp(std::isfinite(frames) ? frames : 0.0, 0.0, totalFramesLocked()));
}
double MixerDevice::playhead() const { QMutexLocker lock(&m_mutex); return m_playheadFrames; }

double MixerDevice::totalFramesLocked() const
{
    double total = 0.0;
    for (const AudioBuffer* t : m_tracks)
        if (t) total = std::max(total, static_cast<double>(t->pcm.size()) / (t->channels > 0 ? t->channels : 1));
    return total;
}
double MixerDevice::totalFrames() const { QMutexLocker lock(&m_mutex); return totalFramesLocked(); }
bool MixerDevice::atEnd() const { QMutexLocker lock(&m_mutex); return m_playheadFrames >= totalFramesLocked(); }

void MixerDevice::setGain(int i, float g) { QMutexLocker l(&m_mutex); if (i>=0&&i<m_gains.size()) m_gains[i]=std::clamp(g,0.f,2.f); }
void MixerDevice::setMuted(int i, bool m) { QMutexLocker l(&m_mutex); if (i>=0&&i<m_muted.size()) m_muted[i]=m; }
void MixerDevice::setSolo(int i, bool s) { QMutexLocker l(&m_mutex); if (i>=0&&i<m_solo.size()) m_solo[i]=s; }
bool MixerDevice::trackMuted(int i) const { QMutexLocker l(&m_mutex); return i>=0&&i<m_muted.size()&&m_muted[i]; }
bool MixerDevice::trackSolo(int i) const { QMutexLocker l(&m_mutex); return i>=0&&i<m_solo.size()&&m_solo[i]; }
float MixerDevice::trackGain(int i) const { QMutexLocker l(&m_mutex); return i>=0&&i<m_gains.size()?m_gains[i]:1.f; }

qint64 MixerDevice::bytesAvailable() const
{
    QMutexLocker lock(&m_mutex);
    const auto remaining = static_cast<qint64>(std::max(0.0, totalFramesLocked() - m_playheadFrames));
    return remaining * m_channels * (m_floatOutput ? 4 : 2) + QIODevice::bytesAvailable();
}

qint64 MixerDevice::readData(char* data, qint64 maxlen)
{
    const int bytesPerSample = m_floatOutput ? 4 : 2;
    const qint64 bytesPerFrame = static_cast<qint64>(m_channels) * bytesPerSample;
    if (maxlen < bytesPerFrame) return 0;

    const qint64 frames = maxlen / bytesPerFrame;
    double playhead = 0.0;
    QVector<float> gains; QVector<bool> muted, solo;
    QVector<const float*> buffers; QVector<int> channelCounts; QVector<qint64> bufferFrames;
    double total = 0.0;
    QMutexLocker lock(&m_mutex);
    {
        playhead = m_playheadFrames;
        gains = m_gains; muted = m_muted; solo = m_solo;
        for (const AudioBuffer* t : m_tracks) {
            buffers.append(t && !t->pcm.empty() ? t->pcm.data() : nullptr);
            const int ch = t ? (t->channels > 0 ? t->channels : 1) : 1;
            channelCounts.append(ch);
            bufferFrames.append(t ? (qint64)(t->pcm.size() / ch) : 0);
        }
        total = totalFramesLocked();
    }

    const bool playing = m_playing.load(std::memory_order_relaxed);

    bool anySolo = false;
    for (bool s : solo) if (s) anySolo = true;

    qint64 toFill = 0;
    if (playing) {
        const double remaining = total - playhead;
        toFill = remaining > 0 ? static_cast<qint64>(std::min<double>(frames, remaining)) : 0;
    }

    if (m_floatOutput) {
        float* out = reinterpret_cast<float*>(data);
        for (qint64 i = 0; i < toFill; ++i) {
            const qint64 fi = (qint64)playhead + i;
            float l = 0, r = 0;
            for (int t = 0; t < buffers.size(); ++t) {
                if (!buffers[t] || (anySolo ? !solo[t] : muted[t]) || fi >= bufferFrames[t]) continue;
                const qint64 biL = fi * channelCounts[t];
                const qint64 biR = channelCounts[t] > 1 ? biL + 1 : biL;
                l += buffers[t][biL] * gains[t];
                r += buffers[t][biR] * gains[t];
            }
            out[i*2] = std::clamp(l,-1.f,1.f); out[i*2+1] = std::clamp(r,-1.f,1.f);
        }
    } else {
        std::int16_t* out = reinterpret_cast<std::int16_t*>(data);
        for (qint64 i = 0; i < toFill; ++i) {
            const qint64 fi = (qint64)playhead + i;
            float l = 0, r = 0;
            for (int t = 0; t < buffers.size(); ++t) {
                if (!buffers[t] || (anySolo ? !solo[t] : muted[t]) || fi >= bufferFrames[t]) continue;
                const qint64 biL = fi * channelCounts[t];
                const qint64 biR = channelCounts[t] > 1 ? biL + 1 : biL;
                l += buffers[t][biL] * gains[t];
                r += buffers[t][biR] * gains[t];
            }
            out[i*2] = (std::int16_t)(std::clamp(l,-1.f,1.f)*32767.f);
            out[i*2+1] = (std::int16_t)(std::clamp(r,-1.f,1.f)*32767.f);
        }
    }

    m_playheadFrames = playhead + toFill;
    const qint64 filledBytes = toFill * bytesPerFrame;
    // Return only valid PCM. The sink enters IdleState after draining its tail.
    return filledBytes;
}

} // namespace mc
