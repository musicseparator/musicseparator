#pragma once

#include <cstddef>
#include <vector>

namespace mc {

// Pre-computed min/max peak envelope used to draw waveforms without
// iterating the full PCM on every paint.
struct WavePeaks {
    int width = 0;
    std::vector<float> minVals;
    std::vector<float> maxVals;
};

namespace Waveform {

// Fills per-pixel min/max peaks for an interleaved PCM buffer.
// Aggregates both channels, then collapses frames into `width` bins.
void computePeaks(const float* pcm, std::size_t frames, int channels, int width,
                  WavePeaks* out);

} // namespace Waveform

} // namespace mc
