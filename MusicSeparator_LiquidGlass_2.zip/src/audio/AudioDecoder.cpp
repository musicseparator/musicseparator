#include "audio/AudioDecoder.h"

#include <QFileInfo>

extern "C" {
#include <libavcodec/avcodec.h>
#include <libavformat/avformat.h>
#include <libavutil/channel_layout.h>
#include <libavutil/dict.h>
#include <libavutil/error.h>
#include <libavutil/samplefmt.h>
#include <libswresample/swresample.h>
}

namespace mc {

namespace {

constexpr int kTargetRate = 44100;
constexpr int kTargetChannels = 2;

QString avErrorString(int err)
{
    char buf[AV_ERROR_MAX_STRING_SIZE] = {0};
    av_strerror(err, buf, sizeof(buf));
    return QString::fromUtf8(buf);
}

} // namespace

ErrorCode AudioDecoder::decodeFile(const QString& filePath, DecodedAudio* out)
{
    if (!out) return ErrorCode::Unknown;

    AVFormatContext* fmt = nullptr;
    AVCodecContext* codec = nullptr;
    SwrContext* swr = nullptr;
    AVFrame* frame = nullptr;
    AVPacket* packet = nullptr;
    uint8_t* outBuf = nullptr;

    const QByteArray path = QFileInfo(filePath).absoluteFilePath().toUtf8();

    int err = avformat_open_input(&fmt, path.constData(), nullptr, nullptr);
    if (err < 0) {
        out->error = ErrorCode::CorruptFile;
        out->errorDetail = avErrorString(err);
        return out->error;
    }
    err = avformat_find_stream_info(fmt, nullptr);
    if (err < 0) {
        out->error = ErrorCode::CorruptFile;
        out->errorDetail = avErrorString(err);
        avformat_close_input(&fmt);
        return out->error;
    }

    // --- Tags -----------------------------------------------------------------
    AVDictionary* meta = fmt->metadata;
    if (meta) {
        if (AVDictionaryEntry* e = av_dict_get(meta, "title", nullptr, 0)) out->title = QString::fromUtf8(e->value);
        if (AVDictionaryEntry* e = av_dict_get(meta, "artist", nullptr, 0)) out->artist = QString::fromUtf8(e->value);
        if (AVDictionaryEntry* e = av_dict_get(meta, "album", nullptr, 0)) out->album = QString::fromUtf8(e->value);
    }

    // --- Embedded cover (attached picture stream) -----------------------------
    for (unsigned i = 0; i < fmt->nb_streams; ++i) {
        AVStream* st = fmt->streams[i];
        if ((st->disposition & AV_DISPOSITION_ATTACHED_PIC) && st->attached_pic.data) {
            out->coverData = QByteArray(reinterpret_cast<const char*>(st->attached_pic.data),
                                        static_cast<int>(st->attached_pic.size));
            break;
        }
    }

    // --- Audio stream ---------------------------------------------------------
    int audioIdx = av_find_best_stream(fmt, AVMEDIA_TYPE_AUDIO, -1, -1, nullptr, 0);
    if (audioIdx < 0) {
        out->error = ErrorCode::UnsupportedFormat;
        out->errorDetail = QStringLiteral("No audio stream found in this file.");
        avformat_close_input(&fmt);
        return out->error;
    }
    AVStream* stream = fmt->streams[audioIdx];

    const AVCodec* dec = avcodec_find_decoder(stream->codecpar->codec_id);
    if (!dec) {
        out->error = ErrorCode::UnsupportedFormat;
        out->errorDetail = QStringLiteral("No decoder available for codec: %1")
                               .arg(avcodec_get_name(stream->codecpar->codec_id));
        avformat_close_input(&fmt);
        return out->error;
    }

    codec = avcodec_alloc_context3(dec);
    if (!codec) {
        out->error = ErrorCode::OutOfMemory;
        avformat_close_input(&fmt);
        return out->error;
    }
    err = avcodec_parameters_to_context(codec, stream->codecpar);
    if (err < 0) {
        out->error = ErrorCode::CorruptFile;
        out->errorDetail = avErrorString(err);
        avcodec_free_context(&codec);
        avformat_close_input(&fmt);
        return out->error;
    }
    codec->pkt_timebase = stream->time_base;
    err = avcodec_open2(codec, dec, nullptr);
    if (err < 0) {
        out->error = ErrorCode::CorruptFile;
        out->errorDetail = avErrorString(err);
        avcodec_free_context(&codec);
        avformat_close_input(&fmt);
        return out->error;
    }

    // --- Resampler: anything -> stereo float 44.1 kHz --------------------------
    AVChannelLayout outLayout;
    av_channel_layout_default(&outLayout, kTargetChannels);
    err = swr_alloc_set_opts2(&swr, &outLayout, AV_SAMPLE_FMT_FLT, kTargetRate,
                              &codec->ch_layout, codec->sample_fmt, codec->sample_rate,
                              0, nullptr);
    if (err < 0 || !swr) {
        out->error = ErrorCode::FfmpegError;
        out->errorDetail = QStringLiteral("Could not configure the audio resampler.");
        avcodec_free_context(&codec);
        avformat_close_input(&fmt);
        return out->error;
    }
    if (swr_init(swr) < 0) {
        out->error = ErrorCode::FfmpegError;
        out->errorDetail = QStringLiteral("Could not initialize the audio resampler.");
        swr_free(&swr);
        avcodec_free_context(&codec);
        avformat_close_input(&fmt);
        return out->error;
    }

    // Output buffer: 2 seconds of stereo float.
    int maxOutSamples = kTargetRate * 2;
    if (av_samples_alloc(&outBuf, nullptr, kTargetChannels, maxOutSamples,
                         AV_SAMPLE_FMT_FLT, 1) < 0) {
        out->error = ErrorCode::OutOfMemory;
        swr_free(&swr);
        avcodec_free_context(&codec);
        avformat_close_input(&fmt);
        return out->error;
    }

    frame = av_frame_alloc();
    packet = av_packet_alloc();
    if (!frame || !packet) {
        out->error = ErrorCode::OutOfMemory;
        av_freep(&outBuf);
        av_frame_free(&frame);
        av_packet_free(&packet);
        swr_free(&swr);
        avcodec_free_context(&codec);
        avformat_close_input(&fmt);
        return out->error;
    }

    AudioBuffer& buf = out->buffer;
    buf.sampleRate = kTargetRate;
    buf.channels = kTargetChannels;
    buf.pcm.reserve(static_cast<std::size_t>(kTargetRate) * 2 * 600); // ~10 min headroom

    auto drainCodec = [&]() -> bool {
        while (avcodec_receive_frame(codec, frame) == 0) {
            std::vector<const uint8_t*> inPlanes(
                av_sample_fmt_is_planar(codec->sample_fmt) ? codec->ch_layout.nb_channels : 1);
            for (std::size_t p = 0; p < inPlanes.size(); ++p)
                inPlanes[p] = frame->extended_data[p];
            int outSamples = swr_convert(swr, &outBuf, maxOutSamples, inPlanes.data(), frame->nb_samples);
            if (outSamples < 0) {
                out->error = ErrorCode::FfmpegError;
                out->errorDetail = QStringLiteral("Resampling failed: %1").arg(avErrorString(outSamples));
                return false;
            }
            const float* f = reinterpret_cast<const float*>(outBuf);
            buf.pcm.insert(buf.pcm.end(), f, f + static_cast<std::size_t>(outSamples) * kTargetChannels);
        }
        return true;
    };

    while (av_read_frame(fmt, packet) >= 0) {
        if (packet->stream_index == audioIdx) {
            err = avcodec_send_packet(codec, packet);
            if (err < 0 && err != AVERROR(EAGAIN)) {
                av_packet_unref(packet);
                continue; // tolerate a few broken packets
            }
            if (!drainCodec()) break;
        }
        av_packet_unref(packet);
    }

    // Flush the decoder tail.
    if (out->error == ErrorCode::None) {
        avcodec_send_packet(codec, nullptr);
        if (!drainCodec()) { /* error recorded */ }
    }

    // Drain the resampler as well, otherwise the final samples are lost.
    while (out->error == ErrorCode::None) {
        const int n = swr_convert(swr, &outBuf, maxOutSamples, nullptr, 0);
        if (n < 0) {
            out->error = ErrorCode::FfmpegError;
            out->errorDetail = avErrorString(n);
            break;
        }
        if (n == 0) break;
        const float* f = reinterpret_cast<const float*>(outBuf);
        buf.pcm.insert(buf.pcm.end(), f, f + static_cast<std::size_t>(n) * kTargetChannels);
    }

    if (out->error == ErrorCode::None && buf.pcm.empty()) {
        out->error = ErrorCode::CorruptFile;
        out->errorDetail = QStringLiteral("The file decoded to zero audio samples.");
    }

    out->codecName = QString::fromUtf8(avcodec_get_name(stream->codecpar->codec_id));
    const double duration = fmt->duration != AV_NOPTS_VALUE
                                ? static_cast<double>(fmt->duration) / AV_TIME_BASE
                                : buf.durationSeconds();
    out->containerLabel = QStringLiteral("%1 • %2 • %3 kHz stereo")
                              .arg(QFileInfo(filePath).suffix().toUpper())
                              .arg(QString::number(duration, 'f', 0) + QLatin1String("s"))
                              .arg(kTargetRate / 1000);
    if (out->title.isEmpty()) out->title = QFileInfo(filePath).completeBaseName();

    av_freep(&outBuf);
    av_frame_free(&frame);
    av_packet_free(&packet);
    swr_free(&swr);
    avcodec_free_context(&codec);
    avformat_close_input(&fmt);

    if (out->error != ErrorCode::None)
        return out->error;

    // Refuse obviously unsupported containers up front.
    if (buf.pcm.size() > 0 && buf.pcm.size() / 2 / kTargetRate > 24 * 3600) {
        out->error = ErrorCode::OutOfMemory;
        out->errorDetail = QStringLiteral("This track is longer than 24 hours — refusing to decode.");
    }
    return out->error;
}

} // namespace mc
