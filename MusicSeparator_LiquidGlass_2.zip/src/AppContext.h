#pragma once

#include <QCoreApplication>
#include <QDir>
#include <QStandardPaths>
#include <QString>

namespace mc {

// Application-wide paths. All relative to the executable so the app is
// fully portable.
class AppContext
{
public:
    static QString appDir()
    {
        return QCoreApplication::applicationDirPath();
    }

    static QString modelsDir()
    {
        return appDir() + QStringLiteral("/models");
    }

    static QString ytDlpPath()
    {
        return appDir() + QStringLiteral("/yt-dlp.exe");
    }

    static QString tempDir()
    {
        const QString dir = QDir::temp().filePath(QStringLiteral("MusicSeparator"));
        QDir().mkpath(dir);
        return dir;
    }
};

} // namespace mc
