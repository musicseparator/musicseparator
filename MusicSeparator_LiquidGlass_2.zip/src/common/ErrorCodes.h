#pragma once

#include <QMetaType>
#include <QString>

namespace mc {

enum class ErrorCode {
    None = 0,
    UnsupportedFormat,
    CorruptFile,
    FfmpegError,
    ModelMissing,
    OnnxError,
    CudaError,
    OutOfMemory,
    OutOfVram,
    DiskFull,
    YoutubeInvalidUrl,
    YoutubeUnavailable,
    YoutubeDownloadFailed,
    Cancelled,
    Unknown
};

QString errorTitle(ErrorCode code);
QString errorMessage(ErrorCode code);

} // namespace mc

Q_DECLARE_METATYPE(mc::ErrorCode)
