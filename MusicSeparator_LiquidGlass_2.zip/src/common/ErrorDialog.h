#pragma once

#include "common/ErrorCodes.h"

#include <QDialog>
#include <QLabel>
#include <QPushButton>

namespace mc {

// Standard error dialog: friendly title + message, optional technical
// details in a collapsible section. Never exits the app on its own.
class ErrorDialog : public QDialog
{
    Q_OBJECT
public:
    explicit ErrorDialog(QWidget* parent = nullptr);

    static void showError(ErrorCode code, const QString& detail = QString(),
                          QWidget* parent = nullptr);
    static void showMessage(const QString& title, const QString& message,
                            QWidget* parent = nullptr);

private:
    QLabel* m_icon = nullptr;
    QLabel* m_title = nullptr;
    QLabel* m_message = nullptr;
    QPushButton* m_detailsBtn = nullptr;
    QWidget* m_detailsArea = nullptr;
    QLabel* m_detailsLabel = nullptr;
};

} // namespace mc
