#pragma once

#include <QString>

namespace mc {

struct StageProgress {
    QString stage;
    int percent = 0;
};

} // namespace mc
