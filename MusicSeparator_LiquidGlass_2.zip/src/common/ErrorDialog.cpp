#include "common/ErrorDialog.h"

#include <QHBoxLayout>
#include <QPixmap>
#include <QScrollArea>
#include <QVBoxLayout>

namespace mc {

ErrorDialog::ErrorDialog(QWidget* parent)
    : QDialog(parent)
{
    setWindowTitle(tr("MusicSeparator"));
    setModal(true);
    setMinimumWidth(460);

    auto* root = new QVBoxLayout(this);
    root->setContentsMargins(24, 24, 24, 20);
    root->setSpacing(10);

    auto* header = new QHBoxLayout();
    m_icon = new QLabel(this);
    m_icon->setFixedSize(36, 36);
    header->addWidget(m_icon, 0, Qt::AlignTop);
    auto* texts = new QVBoxLayout();
    m_title = new QLabel(this);
    m_title->setObjectName(QStringLiteral("cardTitle"));
    m_title->setWordWrap(true);
    m_message = new QLabel(this);
    m_message->setObjectName(QStringLiteral("metaLabel"));
    m_message->setWordWrap(true);
    texts->addWidget(m_title);
    texts->addWidget(m_message);
    header->addLayout(texts, 1);
    root->addLayout(header);

    m_detailsBtn = new QPushButton(tr("Show details"), this);
    m_detailsBtn->setObjectName(QStringLiteral("ghostButton"));
    m_detailsBtn->setVisible(false);
    root->addWidget(m_detailsBtn, 0, Qt::AlignLeft);

    auto* scroll = new QScrollArea(this);
    scroll->setWidgetResizable(true);
    scroll->setMaximumHeight(160);
    m_detailsArea = scroll;
    m_detailsLabel = new QLabel(this);
    m_detailsLabel->setObjectName(QStringLiteral("metaLabel"));
    m_detailsLabel->setTextInteractionFlags(Qt::TextSelectableByMouse);
    m_detailsLabel->setWordWrap(true);
    scroll->setWidget(m_detailsLabel);
    m_detailsArea->setVisible(false);
    root->addWidget(m_detailsArea);

    auto* closeBtn = new QPushButton(tr("Close"), this);
    closeBtn->setObjectName(QStringLiteral("primaryButton"));
    closeBtn->setMinimumWidth(120);
    connect(closeBtn, &QPushButton::clicked, this, &QDialog::accept);
    root->addWidget(closeBtn, 0, Qt::AlignRight);

    connect(m_detailsBtn, &QPushButton::clicked, this, [this] {
        m_detailsArea->setVisible(!m_detailsArea->isVisible());
        m_detailsBtn->setText(m_detailsArea->isVisible() ? tr("Hide details")
                                                         : tr("Show details"));
    });
}

void ErrorDialog::showError(ErrorCode code, const QString& detail, QWidget* parent)
{
    auto* dlg = new ErrorDialog(parent);
    dlg->m_title->setText(errorTitle(code));
    dlg->m_message->setText(errorMessage(code));
    dlg->m_icon->setPixmap(QPixmap(QStringLiteral(":/icons/music.svg"))); // placeholder severity glyph
    if (!detail.isEmpty()) {
        dlg->m_detailsLabel->setText(detail);
        dlg->m_detailsBtn->setVisible(true);
    }
    dlg->exec();
    dlg->deleteLater();
}

void ErrorDialog::showMessage(const QString& title, const QString& message, QWidget* parent)
{
    auto* dlg = new ErrorDialog(parent);
    dlg->m_title->setText(title);
    dlg->m_message->setText(message);
    dlg->exec();
    dlg->deleteLater();
}

} // namespace mc
