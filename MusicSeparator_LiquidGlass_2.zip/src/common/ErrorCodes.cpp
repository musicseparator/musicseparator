#include "common/ErrorCodes.h"

#include <QMetaType>

namespace mc {

QString errorTitle(ErrorCode code)
{
    switch (code) {
    case ErrorCode::UnsupportedFormat:      return QStringLiteral("Unsupported format");
    case ErrorCode::CorruptFile:            return QStringLiteral("Corrupted file");
    case ErrorCode::FfmpegError:            return QStringLiteral("Audio processing error");
    case ErrorCode::ModelMissing:           return QStringLiteral("AI model missing");
    case ErrorCode::OnnxError:              return QStringLiteral("AI engine error");
    case ErrorCode::CudaError:              return QStringLiteral("GPU error");
    case ErrorCode::OutOfMemory:            return QStringLiteral("Not enough memory");
    case ErrorCode::OutOfVram:              return QStringLiteral("Not enough VRAM");
    case ErrorCode::DiskFull:               return QStringLiteral("Not enough disk space");
    case ErrorCode::YoutubeInvalidUrl:      return QStringLiteral("Invalid YouTube link");
    case ErrorCode::YoutubeUnavailable:     return QStringLiteral("Video unavailable");
    case ErrorCode::YoutubeDownloadFailed:  return QStringLiteral("Download failed");
    case ErrorCode::Cancelled:              return QStringLiteral("Cancelled");
    case ErrorCode::Unknown:                return QStringLiteral("Unexpected error");
    case ErrorCode::None:                   return QStringLiteral("OK");
    }
    return QStringLiteral("Error");
}

QString errorMessage(ErrorCode code)
{
    switch (code) {
    case ErrorCode::UnsupportedFormat:
        return QStringLiteral("This file format is not supported. Please use MP3, WAV, MP4, M4A, FLAC, OGG or AAC.");
    case ErrorCode::CorruptFile:
        return QStringLiteral("The file could not be decoded. It may be corrupted or truncated.");
    case ErrorCode::FfmpegError:
        return QStringLiteral("FFmpeg failed to process the audio. See the details below.");
    case ErrorCode::ModelMissing:
        return QStringLiteral("The AI model files were not found. Run tools/download_models.ps1 "
                              "(or see models/README.md) and make sure the .onnx files are next to "
                              "MusicSeparator.exe in the models/ folder, then restart the app.");
    case ErrorCode::OnnxError:
        return QStringLiteral("The AI engine could not run the model. See the details below.");
    case ErrorCode::CudaError:
        return QStringLiteral("The GPU acceleration backend failed to initialize. "
                              "The app will fall back to the CPU automatically.");
    case ErrorCode::OutOfMemory:
        return QStringLiteral("Not enough RAM to process this track. Close other applications and try a shorter file.");
    case ErrorCode::OutOfVram:
        return QStringLiteral("Not enough GPU memory (VRAM) to process this track. "
                              "Switch the device to CPU in Settings, or use a shorter file.");
    case ErrorCode::DiskFull:
        return QStringLiteral("Not enough free disk space on the target drive for the export.");
    case ErrorCode::YoutubeInvalidUrl:
        return QStringLiteral("This does not look like a valid YouTube link. "
                              "Expected formats: https://www.youtube.com/watch?v=... or https://youtu.be/...");
    case ErrorCode::YoutubeUnavailable:
        return QStringLiteral("The video could not be accessed. It may be private, region-restricted, "
                              "removed, or require a sign-in.");
    case ErrorCode::YoutubeDownloadFailed:
        return QStringLiteral("The audio could not be downloaded from YouTube. "
                              "Make sure the yt-dlp.exe file sits next to MusicSeparator.exe, "
                              "that you are online, and that you have the right to download this content.");
    case ErrorCode::Cancelled:
        return QStringLiteral("The operation was cancelled.");
    case ErrorCode::Unknown:
        return QStringLiteral("An unexpected error occurred.");
    case ErrorCode::None:
        return QStringLiteral("OK");
    }
    return QStringLiteral("An unexpected error occurred.");
}

} // namespace mc
