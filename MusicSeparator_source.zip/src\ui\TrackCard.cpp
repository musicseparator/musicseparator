#include "ui/TrackCard.h"

#include <QHBoxLayout>
#include <QIcon>
#include <QLabel>
#include <QPushButton>
#include <QSlider>
#include <QVBoxLayout>

namespace mc {

TrackCard::TrackCard(int index, QWidget* parent)
    : QFrame(parent)
    , m_index(index)
{
    setObjectName(QStringLiteral("trackCard"));

    auto* root = new QVBoxLayout(this);
    root->setContentsMargins(16, 12, 16, 12);
    root->setSpacing(8);

    auto* header = new QHBoxLayout();
    m_name = new QLabel(this);
    m_name->setObjectName(QStringLiteral("stemName"));
    header->addWidget(m_name);
    header->addStretch(1);

    m_exportBtn = new QPushButton(this);
    m_exportBtn->setObjectName(QStringLiteral("iconBtn"));
    m_exportBtn->setIcon(QIcon(QStringLiteral(":/icons/export.svg")));
    m_exportBtn->setIconSize(QSize(14, 14));
    m_exportBtn->setToolTip(tr("Export this stem"));
    header->addWidget(m_exportBtn);
    root->addLayout(header);

    m_wave = new WaveformWidget(this);
    m_wave->setMinimumHeight(52);
    root->addWidget(m_wave);

    auto* controls = new QHBoxLayout();
    controls->setSpacing(8);

    m_playBtn = new QPushButton(this);
    m_playBtn->setObjectName(QStringLiteral("iconBtn"));
    m_playBtn->setIcon(QIcon(QStringLiteral(":/icons/play.svg")));
    m_playBtn->setIconSize(QSize(13, 13));
    m_playBtn->setCheckable(true);
    m_playBtn->setToolTip(tr("Play all tracks (synchronized)"));
    controls->addWidget(m_playBtn);

    m_muteBtn = new QPushButton(this);
    m_muteBtn->setObjectName(QStringLiteral("iconBtn"));
    m_muteBtn->setIcon(QIcon(QStringLiteral(":/icons/mute.svg")));
    m_muteBtn->setIconSize(QSize(14, 14));
    m_muteBtn->setCheckable(true);
    m_muteBtn->setToolTip(tr("Mute"));
    controls->addWidget(m_muteBtn);

    m_soloBtn = new QPushButton(this);
    m_soloBtn->setObjectName(QStringLiteral("iconBtn"));
    m_soloBtn->setIcon(QIcon(QStringLiteral(":/icons/solo.svg")));
    m_soloBtn->setIconSize(QSize(14, 14));
    m_soloBtn->setCheckable(true);
    m_soloBtn->setToolTip(tr("Solo"));
    controls->addWidget(m_soloBtn);

    m_volume = new QSlider(Qt::Horizontal, this);
    m_volume->setRange(0, 150);
    m_volume->setValue(100);
    m_volume->setFixedWidth(140);
    m_volume->setToolTip(tr("Volume"));
    controls->addSpacing(4);
    controls->addWidget(m_volume);

    controls->addStretch(1);
    root->addLayout(controls);

    connect(m_playBtn, &QPushButton::clicked, this, [this] { emit playClicked(m_index); });

    // Mute: amber tint when active (no violet)
    connect(m_muteBtn, &QPushButton::toggled, this, [this](bool on) {
        emit muteChanged(m_index, on);
        m_muteBtn->setStyleSheet(on
            ? QStringLiteral("border-color:#D4963A; background-color:#2A2218;")
            : QString());
    });

    // Solo: cool blue-white tint when active
    connect(m_soloBtn, &QPushButton::toggled, this, [this](bool on) {
        emit soloChanged(m_index, on);
        m_soloBtn->setStyleSheet(on
            ? QStringLiteral("border-color:#7CB8D4; background-color:#182228;")
            : QString());
    });

    connect(m_volume, &QSlider::valueChanged, this, [this](int value) {
        emit gainChanged(m_index, value / 100.0f);
    });
    connect(m_exportBtn, &QPushButton::clicked, this, [this] { emit exportClicked(m_index); });
}

void TrackCard::setStem(const StemResult& result, const QColor& color)
{
    m_name->setText(result.displayName.toUpper());
    m_wave->setBuffer(&result.buffer);
    m_wave->setColor(color);
}

void TrackCard::setPlayheadFraction(double fraction)
{
    m_wave->setPlayheadFraction(fraction);
}

void TrackCard::setTransportPlaying(bool playing)
{
    m_playBtn->blockSignals(true);
    m_playBtn->setChecked(playing);
    m_playBtn->blockSignals(false);
    m_playBtn->setIcon(QIcon(playing ? QStringLiteral(":/icons/pause.svg")
                                     : QStringLiteral(":/icons/play.svg")));
}

} // namespace mc
