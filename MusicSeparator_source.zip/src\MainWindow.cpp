#include "MainWindow.h"

#include "common/ErrorDialog.h"
#include "separation/OnnxModel.h"
#include "settings/Settings.h"
#include "settings/SettingsDialog.h"

#include <QButtonGroup>
#include <QCloseEvent>
#include <QComboBox>
#include <QDesktopServices>
#include <QDir>
#include <QFileDialog>
#include <QHBoxLayout>
#include <QIcon>
#include <QLabel>
#include <QLineEdit>
#include <QMouseEvent>
#include <QPixmap>
#include <QPushButton>
#include <QResizeEvent>
#include <QStandardPaths>
#include <QVBoxLayout>

#include <QtConcurrent>

#include <algorithm>
#include <windows.h>

namespace mc {

// ─── Draggable title bar ─────────────────────────────────────────────────────
class TitleBar : public QWidget
{
public:
    explicit TitleBar(QWidget* parent = nullptr) : QWidget(parent) {}

protected:
    void mousePressEvent(QMouseEvent* e) override {
        if (e->button() == Qt::LeftButton)
            m_dragPos = e->globalPosition().toPoint() - window()->frameGeometry().topLeft();
    }
    void mouseMoveEvent(QMouseEvent* e) override {
        if (e->buttons() & Qt::LeftButton && !m_dragPos.isNull())
            window()->move(e->globalPosition().toPoint() - m_dragPos);
    }
    void mouseDoubleClickEvent(QMouseEvent*) override {
        if (window()->isMaximized()) window()->showNormal();
        else window()->showMaximized();
    }
private:
    QPoint m_dragPos;
};

// ─── MainWindow ──────────────────────────────────────────────────────────────
MainWindow::MainWindow(QWidget* parent)
    : QMainWindow(parent)
    , m_engine(this)
{
    // Frameless window for full custom chrome
    setWindowFlags(Qt::FramelessWindowHint | windowFlags());
    setWindowTitle(tr("MusicSeparator"));
    setWindowIcon(QIcon(QStringLiteral(":/icons/app.svg")));
    resize(1100, 740);

    m_yt = new YouTubeImporter(this);
    buildUi();
    updateGpuChip();

    m_uiTimer.setInterval(100);
    connect(&m_uiTimer, &QTimer::timeout, this, &MainWindow::updateTransportUi);
    m_uiTimer.start();

    connect(&m_engine, &AudioEngine::playbackStateChanged, this, [this](bool playing) {
        m_trackTransport->setPlaying(playing);
        m_mix->setPlaying(playing);
    });
    connect(&m_engine, &AudioEngine::playbackError, this, [this](const QString& message) {
        ErrorDialog::showMessage(tr("Audio playback"), message, this);
    });
    connect(&m_engine, &AudioEngine::playbackFinished, this, [this] {
        m_trackTransport->setPlaying(false);
        m_mix->setPlaying(false);
    });

    connect(m_yt, &YouTubeImporter::metadataReady, this, [this](const YtMetadata& meta) {
        if (m_importCancelled) return;
        m_ytMeta = meta;
        m_hasYoutubeMeta = true;
        m_overlay->setProgress(30, tr("Fetching video info…"));
        m_yt->downloadAudio(meta);
    });
    connect(m_yt, &YouTubeImporter::metadataFailed, this, [this](ErrorCode code, const QString& detail) {
        m_overlay->end();
        if (!m_importCancelled) ErrorDialog::showError(code, detail, this);
    });
    connect(m_yt, &YouTubeImporter::downloadProgress, this, [this](double percent, const QString&) {
        if (percent >= 0.0)
            m_overlay->setProgress(30 + static_cast<int>(percent * 0.6), tr("Downloading audio…"));
    });
    connect(m_yt, &YouTubeImporter::audioDownloaded, this, [this](const QString& path) {
        if (m_importCancelled) return;
        m_overlay->setProgress(95, tr("Decoding audio…"));
        decodeFile(path);
    });
    connect(m_yt, &YouTubeImporter::downloadFailed, this, [this](ErrorCode code, const QString& detail) {
        m_overlay->end();
        if (!m_importCancelled) ErrorDialog::showError(code, detail, this);
    });
}

void MainWindow::buildUi()
{
    auto* root = new QVBoxLayout;
    root->setContentsMargins(0, 0, 0, 0);
    root->setSpacing(0);

    // ── Title bar (macOS-style traffic lights + drag area) ─────────────────
    auto* titleBar = new TitleBar(this);
    titleBar->setObjectName(QStringLiteral("titleBar"));
    titleBar->setFixedHeight(40);
    auto* tbLayout = new QHBoxLayout(titleBar);
    tbLayout->setContentsMargins(14, 0, 14, 0);
    tbLayout->setSpacing(8);

    // Traffic lights
    auto makeWin = [&](const char* id, const QString& tip) {
        auto* b = new QPushButton(titleBar);
        b->setObjectName(QString::fromLatin1(id));
        b->setToolTip(tip);
        b->setFixedSize(12, 12);
        return b;
    };
    auto* btnClose    = makeWin("btnClose",    tr("Close"));
    auto* btnMinimise = makeWin("btnMinimise", tr("Minimise"));
    auto* btnMaximise = makeWin("btnMaximise", tr("Maximise"));
    connect(btnClose,    &QPushButton::clicked, this, &QMainWindow::close);
    connect(btnMinimise, &QPushButton::clicked, this, &QMainWindow::showMinimized);
    connect(btnMaximise, &QPushButton::clicked, this, [this]{
        isMaximized() ? showNormal() : showMaximized();
    });

    tbLayout->addWidget(btnClose);
    tbLayout->addWidget(btnMinimise);
    tbLayout->addWidget(btnMaximise);
    tbLayout->addStretch(1);

    // Centred app name in title bar
    auto* winTitle = new QLabel(QStringLiteral("MusicSeparator"), titleBar);
    winTitle->setStyleSheet(QStringLiteral("font-size:12px; color:#6A6A6A; font-weight:500;"));
    tbLayout->addWidget(winTitle);
    tbLayout->addStretch(1);

    // Placeholder to balance the right side (same width as traffic lights block)
    auto* tbRightSpacer = new QWidget(titleBar);
    tbRightSpacer->setFixedWidth(60);
    tbLayout->addWidget(tbRightSpacer);

    root->addWidget(titleBar);

    // ── Secondary header (icon + name + chips + actions) ───────────────────
    auto* header = new QWidget(this);
    header->setObjectName(QStringLiteral("headerBar"));
    header->setFixedHeight(48);
    auto* headerLayout = new QHBoxLayout(header);
    headerLayout->setContentsMargins(20, 0, 20, 0);
    headerLayout->setSpacing(10);

    auto* appIcon = new QLabel(header);
    appIcon->setPixmap(QPixmap(QStringLiteral(":/icons/app.svg"))
                           .scaled(20, 20, Qt::KeepAspectRatio, Qt::SmoothTransformation));
    headerLayout->addWidget(appIcon);

    auto* appTitle = new QLabel(tr("MusicSeparator"), header);
    appTitle->setObjectName(QStringLiteral("appTitle"));
    headerLayout->addWidget(appTitle);
    headerLayout->addStretch(1);

    m_gpuChip = new QLabel(header);
    m_gpuChip->setObjectName(QStringLiteral("chipLabel"));
    headerLayout->addWidget(m_gpuChip);

    auto* newBtn = new QPushButton(header);
    newBtn->setObjectName(QStringLiteral("iconBtn"));
    newBtn->setIcon(QIcon(QStringLiteral(":/icons/new.svg")));
    newBtn->setIconSize(QSize(14, 14));
    newBtn->setToolTip(tr("New import"));
    connect(newBtn, &QPushButton::clicked, this, [this] {
        if (m_overlay->active()) return;
        m_engine.clear();
        m_stems.clear();
        m_hasYoutubeMeta = false;
        m_ytMeta = YtMetadata{};
        m_decoded = DecodedAudio{};
        m_trackWaveform->clear();
        m_mix->clear();
        switchToPage(0);
    });
    headerLayout->addWidget(newBtn);

    auto* settingsBtn = new QPushButton(header);
    settingsBtn->setObjectName(QStringLiteral("iconBtn"));
    settingsBtn->setIcon(QIcon(QStringLiteral(":/icons/settings.svg")));
    settingsBtn->setIconSize(QSize(14, 14));
    settingsBtn->setToolTip(tr("Settings"));
    connect(settingsBtn, &QPushButton::clicked, this, &MainWindow::openSettings);
    headerLayout->addWidget(settingsBtn);

    root->addWidget(header);

    // ── Pages ───────────────────────────────────────────────────────────────
    m_pages = new QStackedWidget(this);
    root->addWidget(m_pages, 1);

    // Page 0 — import
    auto* importPage   = new QWidget(this);
    auto* importLayout = new QVBoxLayout(importPage);
    importLayout->setContentsMargins(60, 40, 60, 40);
    m_dropZone = new ImportDropZone(importPage);
    importLayout->addWidget(m_dropZone, 1);
    connect(m_dropZone, &ImportDropZone::importAudioClicked, this, &MainWindow::openAudioDialog);
    connect(m_dropZone, &ImportDropZone::importVideoClicked, this, &MainWindow::openVideoDialog);
    connect(m_dropZone, &ImportDropZone::urlSubmitted, this, &MainWindow::submitUrl);
    connect(m_dropZone, &ImportDropZone::fileImported, this, &MainWindow::importPath);
    m_pages->addWidget(importPage);

    // Page 1 — track
    auto* trackPage   = new QWidget(this);
    auto* trackLayout = new QHBoxLayout(trackPage);
    trackLayout->setContentsMargins(32, 24, 32, 24);
    trackLayout->setSpacing(28);

    auto* leftCol = new QVBoxLayout();
    leftCol->setSpacing(12);
    m_coverLabel = new QLabel(trackPage);
    m_coverLabel->setFixedSize(240, 240);
    m_coverLabel->setAlignment(Qt::AlignCenter);
    m_coverLabel->setStyleSheet(QStringLiteral(
        "background:#1E1E1E; border:1px solid #2A2A2A; border-radius:8px;"));
    m_coverLabel->setPixmap(QPixmap(QStringLiteral(":/icons/music.svg"))
                                .scaled(100, 100, Qt::KeepAspectRatio, Qt::SmoothTransformation));
    leftCol->addWidget(m_coverLabel, 0, Qt::AlignCenter);

    m_titleLabel = new QLabel(tr("No track loaded"), trackPage);
    m_titleLabel->setObjectName(QStringLiteral("cardTitle"));
    m_titleLabel->setStyleSheet(QStringLiteral("font-size:18px;"));
    m_titleLabel->setWordWrap(true);
    m_titleLabel->setAlignment(Qt::AlignCenter);
    leftCol->addWidget(m_titleLabel);

    m_metaLabel = new QLabel(trackPage);
    m_metaLabel->setObjectName(QStringLiteral("metaLabel"));
    m_metaLabel->setAlignment(Qt::AlignCenter);
    leftCol->addWidget(m_metaLabel);
    leftCol->addStretch(1);
    trackLayout->addLayout(leftCol);

    auto* rightCol = new QVBoxLayout();
    rightCol->setSpacing(14);

    m_trackWaveform = new WaveformWidget(trackPage);
    m_trackWaveform->setMinimumHeight(140);
    m_trackWaveform->setColor(QColor(232, 114, 74)); // terracotta accent
    rightCol->addWidget(m_trackWaveform);

    m_trackTransport = new TransportBar(trackPage);
    connect(m_trackTransport, &TransportBar::playPauseClicked, &m_engine, &AudioEngine::togglePlayback);
    connect(m_trackTransport, &TransportBar::seekRequested, &m_engine, &AudioEngine::seekToSeconds);
    rightCol->addWidget(m_trackTransport);

    // Stem mode selector
    auto* modeRow = new QHBoxLayout();
    modeRow->setSpacing(8);
    auto* modeHint = new QLabel(tr("Stems"), trackPage);
    modeHint->setObjectName(QStringLiteral("metaLabel"));
    modeRow->addWidget(modeHint);

    m_modeGroup = new QButtonGroup(this);
    const QPair<QString, int> modes[] = {
        {tr("Vocals + Instrumental"), 2},
        {tr("5-stem"), 6},
    };
    for (const auto& [label, id] : modes) {
        auto* btn = new QPushButton(label, trackPage);
        btn->setCheckable(true);
        btn->setObjectName(QStringLiteral("ghostButton"));
        m_modeGroup->addButton(btn, id);
        modeRow->addWidget(btn);
        if (id == 6) btn->setChecked(true);
    }
    modeRow->addStretch(1);

    m_qualityCombo = new QComboBox(trackPage);
    m_qualityCombo->addItem(tr("HT-Demucs"), static_cast<int>(Quality::Balanced));
    m_qualityCombo->setCurrentIndex(0);
    modeRow->addWidget(m_qualityCombo);
    rightCol->addLayout(modeRow);

    auto* stemHint = new QLabel(
        tr("5-stem mode: Vocals, Drums, Bass, Guitar, Piano. Other sounds are excluded."),
        trackPage);
    stemHint->setWordWrap(true);
    stemHint->setObjectName(QStringLiteral("metaLabel"));
    rightCol->addWidget(stemHint);

    m_separateBtn = new QPushButton(tr("Separate Tracks"), trackPage);
    m_separateBtn->setObjectName(QStringLiteral("primaryButton"));
    m_separateBtn->setMinimumHeight(42);
    connect(m_separateBtn, &QPushButton::clicked, this, &MainWindow::onSeparateClicked);
    rightCol->addWidget(m_separateBtn);

    rightCol->addStretch(1);
    trackLayout->addLayout(rightCol, 1);
    m_pages->addWidget(trackPage);

    // Page 2 — mixer
    auto* mixPage   = new QWidget(this);
    auto* mixLayout = new QVBoxLayout(mixPage);
    mixLayout->setContentsMargins(0, 0, 0, 0);
    mixLayout->setSpacing(0);

    auto* mixHeader = new QWidget(this);
    mixHeader->setObjectName(QStringLiteral("headerBar"));
    mixHeader->setFixedHeight(44);
    auto* mixHeaderLayout = new QHBoxLayout(mixHeader);
    mixHeaderLayout->setContentsMargins(16, 0, 16, 0);
    m_backBtn = new QPushButton(tr("← Back"), mixHeader);
    m_backBtn->setObjectName(QStringLiteral("ghostButton"));
    connect(m_backBtn, &QPushButton::clicked, this, [this] {
        m_engine.loadOriginal(m_decoded.buffer);
        switchToPage(1);
    });
    mixHeaderLayout->addWidget(m_backBtn);
    mixHeaderLayout->addStretch(1);
    auto* mixTitle = new QLabel(tr("Separated tracks"), mixHeader);
    mixTitle->setObjectName(QStringLiteral("cardTitle"));
    mixHeaderLayout->addWidget(mixTitle);
    mixHeaderLayout->addStretch(1);
    auto* mixSpacer = new QWidget(mixHeader);
    mixSpacer->setFixedWidth(80);
    mixHeaderLayout->addWidget(mixSpacer);
    mixLayout->addWidget(mixHeader);

    m_mix = new MixConsoleWidget(mixPage);
    connect(m_mix, &MixConsoleWidget::playPauseClicked, &m_engine, &AudioEngine::togglePlayback);
    connect(m_mix, &MixConsoleWidget::seekRequested, &m_engine, &AudioEngine::seekToSeconds);
    connect(m_mix, &MixConsoleWidget::trackPlayClicked, this, [this](int) { m_engine.togglePlayback(); });
    connect(m_mix, &MixConsoleWidget::trackMuteChanged, this, [this](int i, bool m) { m_engine.setTrackMuted(i, m); });
    connect(m_mix, &MixConsoleWidget::trackSoloChanged, this, [this](int i, bool s) { m_engine.setTrackSolo(i, s); });
    connect(m_mix, &MixConsoleWidget::trackGainChanged, this, [this](int i, float g) { m_engine.setTrackGain(i, g); });
    connect(m_mix, &MixConsoleWidget::trackExportClicked, this, &MainWindow::startExportOne);
    connect(m_mix, &MixConsoleWidget::exportAllClicked, this, &MainWindow::startExportAll);
    connect(m_mix, &MixConsoleWidget::openOutputFolderRequested, this, &MainWindow::openOutputFolder);
    mixLayout->addWidget(m_mix, 1);
    m_pages->addWidget(mixPage);

    // ── Overlay ─────────────────────────────────────────────────────────────
    m_overlay = new ProcessingOverlay(this);
    m_overlay->setGeometry(rect());
    connect(m_overlay, &ProcessingOverlay::cancelClicked, this, &MainWindow::onCancelProcessing);

    // ── Root ────────────────────────────────────────────────────────────────
    auto* central = new QWidget(this);
    central->setLayout(root);
    setCentralWidget(central);
}

// ─── Rest of the implementation (unchanged from original) ────────────────────

void MainWindow::switchToPage(int index)
{
    m_pages->setCurrentIndex(index);
    m_uiTimer.start();
}

void MainWindow::updateGpuChip()
{
    const auto providers = OnnxModel::availableProviders();
    const bool hasCuda = std::find(providers.begin(), providers.end(), "CUDAExecutionProvider") != providers.end();
    const bool hasDml  = std::find(providers.begin(), providers.end(), "DMLExecutionProvider")  != providers.end();

    QString text;
    bool gpu = false;
    switch (Settings::instance().device()) {
    case DevicePref::Cpu:
        text = tr("CPU");
        break;
    case DevicePref::Gpu:
    case DevicePref::Auto:
        if (hasCuda)      { text = tr("CUDA");    gpu = true; }
        else if (hasDml)  { text = tr("DirectML"); gpu = true; }
        else                text = tr("CPU");
        break;
    }

    m_gpuChip->setText(text);
    m_gpuChip->setProperty("gpu", gpu);
    style()->unpolish(m_gpuChip);
    style()->polish(m_gpuChip);
}

void MainWindow::openAudioDialog()
{
    const QString path = QFileDialog::getOpenFileName(
        this, tr("Import audio"),
        QStandardPaths::writableLocation(QStandardPaths::MusicLocation),
        tr("Audio files (*.mp3 *.wav *.m4a *.flac *.ogg *.aac);;All files (*.*)"));
    if (!path.isEmpty()) importPath(path);
}

void MainWindow::openVideoDialog()
{
    const QString path = QFileDialog::getOpenFileName(
        this, tr("Import video"),
        QStandardPaths::writableLocation(QStandardPaths::MusicLocation),
        tr("Video files (*.mp4 *.mkv *.mov *.webm *.avi);;All files (*.*)"));
    if (!path.isEmpty()) importPath(path);
}

void MainWindow::submitUrl(const QString& url)
{
    if (m_overlay->active()) return;
    m_importCancelled = false;
    if (!m_yt) m_yt = new YouTubeImporter(this);
    if (!m_yt->isUsable()) {
        ErrorDialog::showError(ErrorCode::YoutubeDownloadFailed,
                               tr("yt-dlp.exe was not found next to MusicSeparator.exe."), this);
        return;
    }
    if (!m_yt->isYouTubeUrl(url)) {
        ErrorDialog::showError(ErrorCode::YoutubeInvalidUrl, QString(), this);
        return;
    }
    m_hasYoutubeMeta = false;
    m_ytMeta = YtMetadata{};
    m_overlay->begin(tr("Fetching video info…"));
    m_yt->fetchMetadata(url);
}

void MainWindow::importPath(const QString& path)
{
    if (path.isEmpty() || m_overlay->active()) return;
    m_importCancelled = false;
    m_hasYoutubeMeta = false;
    m_overlay->begin(tr("Importing audio…"));
    m_overlay->setProgress(5, tr("Importing audio…"));
    decodeFile(path);
}

void MainWindow::decodeFile(const QString& path)
{
    if (m_decodeWatcher && m_decodeWatcher->isRunning()) return;

    m_decodeWatcher = new QFutureWatcher<DecodedAudio>(this);
    connect(m_decodeWatcher, &QFutureWatcher<DecodedAudio>::finished,
            this, &MainWindow::onDecodeFinished);
    m_decodeWatcher->setFuture(QtConcurrent::run([path] {
        DecodedAudio out;
        AudioDecoder::decodeFile(path, &out);
        return out;
    }));
}

void MainWindow::onDecodeFinished()
{
    DecodedAudio decoded = m_decodeWatcher->future().result();
    m_decodeWatcher->deleteLater();
    m_decodeWatcher = nullptr;

    if (m_importCancelled) { m_overlay->end(); return; }
    if (decoded.error != ErrorCode::None) {
        m_overlay->end();
        ErrorDialog::showError(decoded.error, decoded.errorDetail, this);
        return;
    }

    if (m_hasYoutubeMeta) {
        decoded.title  = m_ytMeta.title;
        decoded.artist = m_ytMeta.uploader;
    }
    m_engine.clear();
    m_mix->clear();
    m_stems.clear();
    m_decoded = std::move(decoded);
    showTrackView(m_decoded);
    m_overlay->end();
    switchToPage(1);
}

void MainWindow::showTrackView(const DecodedAudio& decoded)
{
    loadCover(decoded.coverData);
    m_titleLabel->setText(decoded.title.isEmpty() ? tr("Untitled") : decoded.title);
    QString meta = decoded.containerLabel;
    if (!decoded.artist.isEmpty()) meta = decoded.artist + QStringLiteral("  ·  ") + meta;
    m_metaLabel->setText(meta);
    m_trackWaveform->setBuffer(&decoded.buffer);
    m_trackTransport->setDuration(decoded.buffer.durationSeconds());
    m_trackTransport->setPosition(0.0);
    m_engine.loadOriginal(decoded.buffer);
    m_separateBtn->setEnabled(true);
}

void MainWindow::loadCover(const QByteArray& data)
{
    if (!data.isEmpty()) {
        QPixmap pix;
        if (pix.loadFromData(data))
            m_coverLabel->setPixmap(
                pix.scaled(240, 240, Qt::KeepAspectRatioByExpanding, Qt::SmoothTransformation));
        else
            m_coverLabel->setPixmap(QPixmap(QStringLiteral(":/icons/music.svg"))
                                        .scaled(100, 100, Qt::KeepAspectRatio, Qt::SmoothTransformation));
    } else {
        m_coverLabel->setPixmap(QPixmap(QStringLiteral(":/icons/music.svg"))
                                    .scaled(100, 100, Qt::KeepAspectRatio, Qt::SmoothTransformation));
    }
}

void MainWindow::onSeparateClicked()
{
    if (m_worker || m_decoded.buffer.pcm.empty()) return;

    const std::size_t stemBytes = m_decoded.buffer.pcm.size() * sizeof(float);
    const int stemCount = m_modeGroup->checkedId() == 2 ? 2
                        : m_modeGroup->checkedId() == 6 ? 6 : 4;
    const std::size_t total = stemBytes * static_cast<std::size_t>(stemCount);
    MEMORYSTATUSEX mem{};
    mem.dwLength = sizeof(mem);
    if (GlobalMemoryStatusEx(&mem) && mem.ullAvailPhys > 0) {
        if (total > static_cast<std::size_t>(mem.ullAvailPhys * 0.75)) {
            ErrorDialog::showError(ErrorCode::OutOfMemory,
                                   tr("Separating this track needs about %1 MB of RAM. "
                                      "Close other applications or use a shorter file.")
                                       .arg(total / (1024 * 1024)),
                                   this);
            return;
        }
    }

    const StemMode mode = m_modeGroup->checkedId() == 2 ? StemMode::TwoStems
                        : m_modeGroup->checkedId() == 6 ? StemMode::SixStems
                                                        : StemMode::FourStems;
    const Quality quality = static_cast<Quality>(m_qualityCombo->currentData().toInt());

    m_engine.pause();
    m_worker = new SeparationWorker(m_decoded.buffer.pcm, m_decoded.buffer.sampleRate,
                                    mode, quality, this);
    connect(m_worker, &SeparationWorker::progressChanged, this, &MainWindow::onWorkerProgress);
    connect(m_worker, &SeparationWorker::separationDone, this, &MainWindow::onWorkerDone);
    connect(m_worker, &SeparationWorker::separationFailed, this, &MainWindow::onWorkerFailed);

    m_separateBtn->setEnabled(false);
    m_overlay->begin(tr("Separating your track…"));
    m_worker->start();
}

void MainWindow::onWorkerProgress(int percent, const QString& stage)
{
    m_overlay->setProgress(percent, stage);
}

void MainWindow::onWorkerDone()
{
    m_engine.clear();
    m_mix->clear();
    m_stems = m_worker->results();

    QVector<AudioBuffer*> buffers;
    for (int i = 0; i < m_stems.size(); ++i)
        buffers.append(&m_stems[i].buffer);

    m_engine.setStemBuffers(buffers);
    m_mix->setStems(m_stems);
    m_mix->setDuration(m_stems.isEmpty() ? 0.0 : m_stems.first().buffer.durationSeconds());

    m_worker->deleteLater();
    m_worker = nullptr;
    m_separateBtn->setEnabled(true);
    m_overlay->end();
    switchToPage(2);
}

void MainWindow::onWorkerFailed(ErrorCode code, const QString& detail)
{
    m_worker->deleteLater();
    m_worker = nullptr;
    m_separateBtn->setEnabled(true);
    m_overlay->end();
    if (code != ErrorCode::Cancelled)
        ErrorDialog::showError(code, detail, this);
}

void MainWindow::onCancelProcessing()
{
    if (m_worker)   m_worker->requestCancel();
    if (m_exporter) m_exporter->requestCancel();
    m_importCancelled = true;
    if (m_yt) m_yt->cancel();
    if (!m_worker && !m_exporter && !m_decodeWatcher) m_overlay->end();
}

void MainWindow::updateTransportUi()
{
    if (m_pages->currentIndex() == 1) {
        m_trackTransport->setPosition(m_engine.positionSeconds());
        m_trackWaveform->setPlayheadFraction(m_engine.positionFraction());
    } else if (m_pages->currentIndex() == 2) {
        m_mix->setPosition(m_engine.positionSeconds());
    }
}

void MainWindow::startExportAll(ExportFormat format)
{
    if (m_exporter || m_stems.isEmpty()) return;

    m_exporter = new ExportWorker(m_stems, trackTitle(), outputFolderForExport(), format, this);
    connect(m_exporter, &ExportWorker::progressChanged, this, &MainWindow::onExportWorkerProgress);
    connect(m_exporter, &ExportWorker::done,   this, &MainWindow::onExportWorkerDone);
    connect(m_exporter, &ExportWorker::failed, this, &MainWindow::onExportWorkerFailed);
    m_overlay->begin(tr("Exporting…"));
    m_exporter->start();
}

void MainWindow::startExportOne(int index)
{
    if (m_exporter || index < 0 || index >= m_stems.size()) return;

    QVector<StemResult> one;
    one.append(m_stems[index]);
    const ExportFormat fmt = [this] {
        switch (Settings::instance().exportFormat()) {
        case ExportFormatPref::Mp3:  return ExportFormat::Mp3;
        case ExportFormatPref::Flac: return ExportFormat::Flac;
        case ExportFormatPref::Wav:  return ExportFormat::Wav;
        }
        return ExportFormat::Wav;
    }();

    m_exporter = new ExportWorker(one, trackTitle(), outputFolderForExport(), fmt, this);
    connect(m_exporter, &ExportWorker::progressChanged, this, &MainWindow::onExportWorkerProgress);
    connect(m_exporter, &ExportWorker::done,   this, &MainWindow::onExportWorkerDone);
    connect(m_exporter, &ExportWorker::failed, this, &MainWindow::onExportWorkerFailed);
    m_overlay->begin(tr("Exporting…"));
    m_exporter->start();
}

void MainWindow::onExportWorkerProgress(int percent, const QString& stage)
{
    m_overlay->setProgress(percent, stage);
}

void MainWindow::onExportWorkerDone()
{
    const QString folder = m_exporter->exportPath();
    m_exporter->deleteLater();
    m_exporter = nullptr;
    m_overlay->end();
    ErrorDialog::showMessage(tr("Export complete"),
                             tr("Stems exported to:\n%1").arg(QDir::toNativeSeparators(folder)), this);
}

void MainWindow::onExportWorkerFailed(ErrorCode code, const QString& detail)
{
    m_exporter->deleteLater();
    m_exporter = nullptr;
    m_overlay->end();
    if (code != ErrorCode::Cancelled)
        ErrorDialog::showError(code, detail, this);
}

void MainWindow::openOutputFolder()
{
    QDesktopServices::openUrl(QUrl::fromLocalFile(outputFolderForExport()));
}

void MainWindow::openSettings()
{
    auto* dlg = new SettingsDialog(this);
    connect(dlg, &SettingsDialog::settingsChanged, this, &MainWindow::updateGpuChip);
    dlg->exec();
    dlg->deleteLater();
}

QString MainWindow::trackTitle() const
{
    QString title = m_decoded.title;
    if (title.isEmpty() && m_hasYoutubeMeta) title = m_ytMeta.title;
    if (title.isEmpty()) title = tr("Track");
    return title;
}

QString MainWindow::outputFolderForExport() const
{
    return Settings::instance().effectiveOutputFolder();
}

void MainWindow::setBusy(bool) {}

void MainWindow::resizeEvent(QResizeEvent* event)
{
    QMainWindow::resizeEvent(event);
    if (m_overlay) {
        m_overlay->setGeometry(rect());
        m_overlay->raise();
    }
}

void MainWindow::closeEvent(QCloseEvent* event)
{
    m_engine.stop();
    if (m_worker)   m_worker->requestCancel();
    if (m_exporter) m_exporter->requestCancel();
    if (m_yt)       m_yt->cancel();
    if (m_worker)          m_worker->wait();
    if (m_exporter)        m_exporter->wait();
    if (m_decodeWatcher)   m_decodeWatcher->waitForFinished();
    QMainWindow::closeEvent(event);
}

} // namespace mc
