#include "ui/ImportDropZone.h"

#include <QDragEnterEvent>
#include <QDropEvent>
#include <QHBoxLayout>
#include <QLabel>
#include <QLineEdit>
#include <QMimeData>
#include <QPainter>
#include <QPushButton>
#include <QVBoxLayout>

namespace mc {

ImportDropZone::ImportDropZone(QWidget* parent)
    : QWidget(parent)
{
    setAcceptDrops(true);
    setMinimumHeight(340);
    setCursor(Qt::PointingHandCursor);

    auto* root = new QVBoxLayout(this);
    root->setContentsMargins(40, 36, 40, 36);
    root->setSpacing(10);

    root->addStretch(2);

    auto* icon = new QLabel(this);
    icon->setPixmap(QPixmap(QStringLiteral(":/icons/music.svg")).scaled(56, 56, Qt::KeepAspectRatio, Qt::SmoothTransformation));
    icon->setAlignment(Qt::AlignCenter);
    root->addWidget(icon);

    m_title = new QLabel(tr("Drop your song here"), this);
    m_title->setObjectName(QStringLiteral("cardTitle"));
    m_title->setAlignment(Qt::AlignCenter);
    m_title->setStyleSheet(QStringLiteral("font-size: 20px;"));
    root->addWidget(m_title);

    auto* hint = new QLabel(tr("MP3, WAV, MP4, M4A, FLAC, OGG, AAC — or a YouTube link"), this);
    hint->setObjectName(QStringLiteral("metaLabel"));
    hint->setAlignment(Qt::AlignCenter);
    root->addWidget(hint);

    root->addSpacing(6);

    auto* buttons = new QHBoxLayout();
    buttons->setSpacing(10);
    auto* audioBtn = new QPushButton(tr("Import Audio"), this);
    audioBtn->setObjectName(QStringLiteral("primaryButton"));
    audioBtn->setCursor(Qt::ArrowCursor);
    auto* videoBtn = new QPushButton(tr("Import Video"), this);
    videoBtn->setObjectName(QStringLiteral("ghostButton"));
    videoBtn->setCursor(Qt::ArrowCursor);
    buttons->addStretch(1);
    buttons->addWidget(audioBtn);
    buttons->addWidget(videoBtn);
    buttons->addStretch(1);
    root->addLayout(buttons);

    root->addSpacing(8);

    auto* urlRow = new QHBoxLayout();
    urlRow->setSpacing(8);
    m_urlEdit = new QLineEdit(this);
    m_urlEdit->setPlaceholderText(tr("Paste YouTube URL"));
    m_urlEdit->setCursor(Qt::IBeamCursor);
    auto* urlBtn = new QPushButton(tr("Import"), this);
    urlBtn->setObjectName(QStringLiteral("ghostButton"));
    urlBtn->setCursor(Qt::ArrowCursor);
    urlRow->addStretch(1);
    urlRow->addWidget(m_urlEdit, 2);
    urlRow->addWidget(urlBtn);
    urlRow->addStretch(1);
    root->addLayout(urlRow);

    m_legal = new QLabel(tr("Only download content you have the right to download and process."), this);
    m_legal->setObjectName(QStringLiteral("metaLabel"));
    m_legal->setAlignment(Qt::AlignCenter);
    root->addWidget(m_legal);

    root->addStretch(2);

    connect(audioBtn, &QPushButton::clicked, this, &ImportDropZone::importAudioClicked);
    connect(videoBtn, &QPushButton::clicked, this, &ImportDropZone::importVideoClicked);
    connect(urlBtn, &QPushButton::clicked, this, [this] {
        const QString url = m_urlEdit->text().trimmed();
        if (!url.isEmpty()) emit urlSubmitted(url);
    });
    connect(m_urlEdit, &QLineEdit::returnPressed, this, [this] {
        const QString url = m_urlEdit->text().trimmed();
        if (!url.isEmpty()) emit urlSubmitted(url);
    });
}

void ImportDropZone::paintEvent(QPaintEvent*)
{
    QPainter p(this);
    p.setRenderHint(QPainter::Antialiasing, true);

    QPen pen(QColor(90, 96, 120));
    pen.setWidth(2);
    pen.setStyle(Qt::DashLine);
    p.setPen(pen);
    p.setBrush(QColor(22, 24, 31, 160));
    p.drawRoundedRect(rect().adjusted(1, 1, -2, -2), 16, 16);
}

void ImportDropZone::dragEnterEvent(QDragEnterEvent* event)
{
    if (event->mimeData()->hasUrls())
        event->acceptProposedAction();
}

void ImportDropZone::dropEvent(QDropEvent* event)
{
    const QList<QUrl> urls = event->mimeData()->urls();
    if (urls.isEmpty()) return;
    const QString path = urls.first().toLocalFile();
    if (!path.isEmpty()) emit fileImported(path);
}

} // namespace mc
