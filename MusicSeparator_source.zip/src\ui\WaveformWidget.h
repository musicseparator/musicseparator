#pragma once

#include "audio/AudioBuffer.h"
#include "audio/Waveform.h"

#include <QColor>
#include <QWidget>

namespace mc {

// Clickable waveform display with seek-on-click/drag and a playhead
// overlay. The peaks are recomputed lazily when the widget resizes.
class WaveformWidget : public QWidget
{
    Q_OBJECT
public:
    explicit WaveformWidget(QWidget* parent = nullptr);

    void setBuffer(const AudioBuffer* buffer);
    void setColor(const QColor& color);
    void setPlayheadFraction(double fraction);
    void clear();

    bool hasData() const { return m_buffer != nullptr; }

signals:
    void seekRequested(double fraction);

protected:
    void paintEvent(QPaintEvent* event) override;
    void resizeEvent(QResizeEvent* event) override;
    void mousePressEvent(QMouseEvent* event) override;
    void mouseMoveEvent(QMouseEvent* event) override;
    void mouseReleaseEvent(QMouseEvent* event) override;
    void leaveEvent(QEvent* event) override;

private:
    void recomputePeaks();
    double fractionAt(int x) const;

    const AudioBuffer* m_buffer = nullptr;
    WavePeaks m_peaks;
    QColor m_color{109, 93, 246};
    double m_playheadFraction = 0.0;
    bool m_seeking = false;
    bool m_hoverActive = false;
    double m_hoverFraction = -1.0;
};

} // namespace mc
