#pragma once

#include <QWidget>

class QLabel;
class QLineEdit;
class QPushButton;

namespace mc {

// Central drop zone: "Drop your song here", Import Audio / Import Video
// buttons, and the Paste YouTube URL row. Accepts file drag & drop.
class ImportDropZone : public QWidget
{
    Q_OBJECT
public:
    explicit ImportDropZone(QWidget* parent = nullptr);

signals:
    void importAudioClicked();
    void importVideoClicked();
    void urlSubmitted(const QString& url);
    void fileImported(const QString& path);

protected:
    void paintEvent(QPaintEvent* event) override;
    void dragEnterEvent(QDragEnterEvent* event) override;
    void dropEvent(QDropEvent* event) override;

private:
    QLabel* m_title = nullptr;
    QLabel* m_legal = nullptr;
    QLineEdit* m_urlEdit = nullptr;
};

} // namespace mc
