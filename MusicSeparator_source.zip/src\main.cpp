#include "MainWindow.h"

#include "common/ErrorCodes.h"

#include <QApplication>
#include <QFile>
#include <QFont>
#include <QIcon>

#include <QMetaType>

int main(int argc, char* argv[])
{
    QApplication app(argc, argv);
    app.setOrganizationName(QStringLiteral("MusicSeparator"));
    app.setApplicationName(QStringLiteral("MusicSeparator"));
    app.setApplicationVersion(QStringLiteral("1.0.0"));
    app.setWindowIcon(QIcon(QStringLiteral(":/icons/app.svg")));

    // Windows 11 look: Segoe UI Variable with a Segoe UI fallback.
    QFont font = app.font();
    font.setFamily(QStringLiteral("Segoe UI Variable"));
    font.setPointSize(10);
    app.setFont(font);

    QFile theme(QStringLiteral(":/style.qss"));
    if (theme.open(QIODevice::ReadOnly))
        app.setStyleSheet(QString::fromUtf8(theme.readAll()));

    qRegisterMetaType<mc::ErrorCode>("mc::ErrorCode");

    mc::MainWindow window;
    window.show();
    return app.exec();
}
