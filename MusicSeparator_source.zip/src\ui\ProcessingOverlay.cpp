#include "ui/ProcessingOverlay.h"

#include <QFrame>
#include <QHBoxLayout>
#include <QLabel>
#include <QPainter>
#include <QProgressBar>
#include <QPushButton>
#include <QVBoxLayout>

namespace mc {

ProcessingOverlay::ProcessingOverlay(QWidget* parent)
    : QWidget(parent)
{
    setAttribute(Qt::WA_TransparentForMouseEvents, false);
    hide();

    m_effect = new QGraphicsOpacityEffect(this);
    m_effect->setOpacity(0.0);
    setGraphicsEffect(m_effect);

    m_anim = new QPropertyAnimation(m_effect, "opacity", this);
    m_anim->setDuration(180);

    auto* root = new QVBoxLayout(this);
    root->addStretch(1);

    auto* card = new QFrame(this);
    card->setObjectName(QStringLiteral("card"));
    card->setFixedWidth(420);
    auto* cardLayout = new QVBoxLayout(card);
    cardLayout->setContentsMargins(28, 26, 28, 26);
    cardLayout->setSpacing(12);

    m_title = new QLabel(card);
    m_title->setObjectName(QStringLiteral("cardTitle"));
    m_title->setAlignment(Qt::AlignCenter);
    m_title->setStyleSheet(QStringLiteral("font-size:17px;"));
    cardLayout->addWidget(m_title);

    m_bar = new QProgressBar(card);
    m_bar->setRange(0, 100);
    m_bar->setValue(0);
    m_bar->setTextVisible(false);
    m_bar->setFixedHeight(8);
    cardLayout->addWidget(m_bar);

    auto* infoRow = new QHBoxLayout();
    m_stage = new QLabel(card);
    m_stage->setObjectName(QStringLiteral("metaLabel"));
    infoRow->addWidget(m_stage, 1);
    m_percent = new QLabel(card);
    m_percent->setObjectName(QStringLiteral("metaLabel"));
    m_percent->setAlignment(Qt::AlignRight);
    infoRow->addWidget(m_percent);
    cardLayout->addLayout(infoRow);

    m_cancelBtn = new QPushButton(tr("Cancel"), card);
    m_cancelBtn->setObjectName(QStringLiteral("dangerButton"));
    m_cancelBtn->setFixedWidth(120);
    cardLayout->addWidget(m_cancelBtn, 0, Qt::AlignCenter);

    root->addWidget(card, 0, Qt::AlignCenter);
    root->addStretch(1);

    connect(m_cancelBtn, &QPushButton::clicked, this, &ProcessingOverlay::cancelClicked);
    connect(m_anim, &QPropertyAnimation::finished, this, [this] {
        if (m_effect->opacity() <= 0.0) hide();
    });
}

void ProcessingOverlay::begin(const QString& title)
{
    m_active = true;
    m_title->setText(title);
    m_stage->setText(QString());
    m_percent->setText(QStringLiteral("0%"));
    m_bar->setValue(0);
    show();
    raise();
    m_anim->stop();
    m_anim->setStartValue(0.0);
    m_anim->setEndValue(1.0);
    m_anim->start();
}

void ProcessingOverlay::setProgress(int percent, const QString& stage)
{
    m_bar->setValue(percent);
    m_percent->setText(QStringLiteral("%1%").arg(percent));
    m_stage->setText(stage);
}

void ProcessingOverlay::end()
{
    m_active = false;
    m_anim->stop();
    m_anim->setStartValue(1.0);
    m_anim->setEndValue(0.0);
    m_anim->start();
}

void ProcessingOverlay::paintEvent(QPaintEvent*)
{
    QPainter p(this);
    p.fillRect(rect(), QColor(12, 13, 17, 200));
}

} // namespace mc
