$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath $PSScriptRoot
try {
    Start-Transcript -Path (Join-Path $PSScriptRoot 'compilation_ui.log') -Force | Out-Null
    $cache = Join-Path $PSScriptRoot 'build\CMakeCache.txt'
    if (!(Test-Path -LiteralPath $cache)) {
        throw 'Extrayez le ZIP dans votre dossier MusicSeparator existant, a cote de build, puis relancez.'
    }
    $content = Get-Content -LiteralPath $cache
    $line = $content | Where-Object { $_ -match '^CMAKE_COMMAND:INTERNAL=' } | Select-Object -First 1
    if ($line) { $cmake = $line.Substring($line.IndexOf('=') + 1) }
    else { $cmake = (Get-Command cmake -ErrorAction Stop).Source }
    if (!(Test-Path -LiteralPath $cmake)) { throw 'CMake introuvable. Utilisez votre terminal de compilation habituel.' }
    Write-Host 'Compilation de la nouvelle interface...'
    & $cmake --build build --config Release --target MusicSeparator --parallel 4
    if ($LASTEXITCODE -ne 0) { throw 'Compilation echouee. Fermez MusicSeparator si le fichier exe est verrouille.' }
    $multiConfig = $content | Where-Object { $_ -match '^CMAKE_CONFIGURATION_TYPES:[^=]+=.+' }
    if ($multiConfig) { $relativeExe = 'build\Release\MusicSeparator.exe' }
    else { $relativeExe = 'build\MusicSeparator.exe' }
    $exe = Join-Path $PSScriptRoot $relativeExe
    if (!(Test-Path -LiteralPath $exe)) { throw 'Executable compile introuvable. Consultez le journal.' }
    Write-Host 'Interface mise a jour. Le bouton Appearance ouvre les options de personnalisation.'
    Stop-Transcript | Out-Null
    Start-Process -FilePath $exe -WorkingDirectory (Split-Path $exe)
    exit 0
} catch {
    Write-Host $_.Exception.Message -ForegroundColor Red
    try { Stop-Transcript | Out-Null } catch {}
    exit 1
}
