#pragma once
#include <QObject>
#include <QColor>
#include <QIcon>
#include <QString>

namespace mc {
struct Appearance {
    QString theme = QStringLiteral("light");
    QString accent = QStringLiteral("graphite");
    int textSize = 13;
    bool compact = false;
    bool controlsRight = false;
    bool coloredControls = true;
};
class Theme : public QObject {
    Q_OBJECT
public:
    static Theme& instance();
    static Appearance current();
    static void load();
    static void apply(Appearance appearance, bool save = false);
    static QColor accent();
    static QIcon icon(const QString& name, bool onAccent = false);
    static bool dark();
signals:
    void changed();
private:
    Appearance m_appearance;
};
}
