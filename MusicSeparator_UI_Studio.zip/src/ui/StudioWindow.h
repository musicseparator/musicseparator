#pragma once
#include <QMainWindow>
#include <QFrame>
class QLabel;
class QHBoxLayout;
namespace mc {
class StudioWindow : public QMainWindow {
public:
    explicit StudioWindow(QWidget* parent = nullptr);
protected:
    bool nativeEvent(const QByteArray& type, void* message, qintptr* result) override;
    bool eventFilter(QObject* watched, QEvent* event) override;
};
class StudioTitleBar : public QFrame {
public:
    explicit StudioTitleBar(QWidget* parent = nullptr);
protected:
    void mousePressEvent(QMouseEvent* event) override;
    void mouseDoubleClickEvent(QMouseEvent* event) override;
private:
    QWidget* m_controls = nullptr;
    QHBoxLayout* m_left = nullptr;
    QHBoxLayout* m_right = nullptr;
};
}
