#include "ui/Theme.h"
#include <QApplication>
#include <QFile>
#include <QFont>
#include <QIconEngine>
#include <QPainter>
#include <QPainterPath>
#include <QPalette>
#include <QSettings>
#include <QWidget>
#include <algorithm>

namespace mc {
namespace {
class LineIcon final : public QIconEngine {
public:
    LineIcon(QString name, bool accent) : m_name(std::move(name)), m_accent(accent) {}
    QIconEngine* clone() const override { return new LineIcon(m_name, m_accent); }
    void paint(QPainter* p, const QRect& rect, QIcon::Mode mode, QIcon::State) override {
        p->save(); p->setRenderHint(QPainter::Antialiasing);
        const int side = std::min(rect.width(), rect.height());
        p->translate(rect.center().x()-side/2.0, rect.center().y()-side/2.0);
        p->scale(side/24.0, side/24.0);
        const auto palette = qApp->palette();
        const auto role = m_accent ? QPalette::HighlightedText : QPalette::WindowText;
        const QColor color = palette.color(mode == QIcon::Disabled ? QPalette::Disabled : QPalette::Active, role);
        p->setPen(QPen(color, 1.65, Qt::SolidLine, Qt::RoundCap, Qt::RoundJoin));
        p->setBrush(Qt::NoBrush);
        if (m_name == "play") {
            QPainterPath path; path.moveTo(9,5); path.lineTo(19,12); path.lineTo(9,19); path.closeSubpath();
            p->fillPath(path,color);
        } else if (m_name == "pause") {
            p->fillRect(QRectF(7,5,3,14),color); p->fillRect(QRectF(14,5,3,14),color);
        } else if (m_name == "new") {
            p->drawLine(12,5,12,19); p->drawLine(5,12,19,12);
        } else if (m_name == "folder") {
            QPainterPath path; path.moveTo(3,7); path.lineTo(3,19); path.lineTo(21,19); path.lineTo(21,8); path.lineTo(11,8); path.lineTo(9,5); path.lineTo(3,5); path.closeSubpath(); p->drawPath(path);
        } else if (m_name == "export") {
            p->drawLine(12,3,12,15); p->drawLine(8,11,12,15); p->drawLine(12,15,16,11);
            QPainterPath path; path.moveTo(4,15); path.lineTo(4,20); path.lineTo(20,20); path.lineTo(20,15); p->drawPath(path);
        } else if (m_name == "settings") {
            for (int i=0;i<3;++i) { int y=6+i*6, x=i==1?15:9; p->drawLine(4,y,20,y); p->setBrush(palette.window()); p->drawEllipse(QPointF(x,y),2.5,2.5); }
        } else if (m_name == "appearance") {
            p->drawEllipse(QRectF(4,4,16,16)); QPainterPath path; path.moveTo(12,4); path.arcTo(QRectF(4,4,16,16),90,180); path.closeSubpath(); p->fillPath(path,color);
        } else if (m_name == "back") {
            p->drawLine(5,12,19,12); p->drawLine(5,12,11,6); p->drawLine(5,12,11,18);
        } else if (m_name == "video") {
            p->drawRoundedRect(QRectF(3,6,13,12),2,2); p->drawLine(16,9,21,6); p->drawLine(21,6,21,18); p->drawLine(21,18,16,15);
        } else if (m_name == "mute") {
            QPainterPath path; path.moveTo(4,9); path.lineTo(8,9); path.lineTo(12,5); path.lineTo(12,19); path.lineTo(8,15); path.lineTo(4,15); path.closeSubpath(); p->drawPath(path);
            p->drawLine(16,9,21,15); p->drawLine(16,15,21,9);
        } else {
            const int heights[]{7,13,19,11,5};
            for (int i=0;i<5;++i) p->drawLine(QPointF(4+i*4,12-heights[i]/2.0),QPointF(4+i*4,12+heights[i]/2.0));
        }
        p->restore();
    }
    QPixmap pixmap(const QSize& size, QIcon::Mode mode, QIcon::State state) override {
        QPixmap pm(size); pm.fill(Qt::transparent); QPainter p(&pm); paint(&p,QRect(QPoint(),size),mode,state); return pm;
    }
private:
    QString m_name; bool m_accent;
};
}
Theme& Theme::instance() { static Theme theme; return theme; }
Appearance Theme::current() { return instance().m_appearance; }
bool Theme::dark() { return current().theme == QStringLiteral("dark"); }
QColor Theme::accent() { return qApp->palette().highlight().color(); }
QIcon Theme::icon(const QString& name, bool onAccent) { return QIcon(new LineIcon(name,onAccent)); }
void Theme::load() {
    QSettings s; Appearance a;
    a.theme=s.value("appearance/theme",a.theme).toString();
    a.accent=s.value("appearance/accent",a.accent).toString();
    a.textSize=s.value("appearance/textSize",a.textSize).toInt();
    a.compact=s.value("appearance/compact",a.compact).toBool();
    a.controlsRight=s.value("appearance/controlsRight",a.controlsRight).toBool();
    a.coloredControls=s.value("appearance/coloredControls",a.coloredControls).toBool();
    apply(a);
}
void Theme::apply(Appearance a, bool save) {
    a.textSize=std::clamp(a.textSize,12,15);
    if (a.theme != "dark") a.theme="light";
    instance().m_appearance=a;
    const bool d=dark();
    const QString bg=d?"#1b1d1b":"#f5f4f0", surface=d?"#242623":"#ffffff";
    const QString ink=d?"#e8e9e4":"#282c28", muted=d?"#aaafa5":"#696f66";
    const QString border=d?"#3b3f38":"#dddfd7", hover=d?"#30342e":"#eeefe9";
    QString accent=d?"#c9d0c2":"#343d32";
    if(a.accent=="olive") accent=d?"#b5c39b":"#596746";
    if(a.accent=="slate") accent=d?"#a6bbc8":"#4b6574";
    if(a.accent=="sand") accent=d?"#cfbca1":"#7d6547";
    const QString onAccent=d?"#1c221a":"#ffffff";
    QPalette p;
    p.setColor(QPalette::Window,QColor(bg)); p.setColor(QPalette::Base,QColor(surface));
    p.setColor(QPalette::AlternateBase,QColor(hover)); p.setColor(QPalette::WindowText,QColor(ink));
    p.setColor(QPalette::Text,QColor(ink)); p.setColor(QPalette::Button,QColor(surface));
    p.setColor(QPalette::ButtonText,QColor(ink)); p.setColor(QPalette::Mid,QColor(border));
    p.setColor(QPalette::PlaceholderText,QColor(muted)); p.setColor(QPalette::Highlight,QColor(accent));
    p.setColor(QPalette::HighlightedText,QColor(onAccent)); p.setColor(QPalette::ToolTipBase,QColor(surface));
    p.setColor(QPalette::ToolTipText,QColor(ink));
    p.setColor(QPalette::Disabled,QPalette::Text,QColor(muted));
    p.setColor(QPalette::Disabled,QPalette::WindowText,QColor(muted));
    p.setColor(QPalette::Disabled,QPalette::ButtonText,QColor(muted));
    qApp->setPalette(p);
    QFont font(QStringLiteral("Segoe UI")); font.setPixelSize(a.textSize); qApp->setFont(font);
    QFile file(":/style.qss");
    if(file.open(QIODevice::ReadOnly)) {
        QString qss=QString::fromUtf8(file.readAll());
        qss.replace("@bg",bg).replace("@surface",surface).replace("@ink",ink).replace("@muted",muted)
           .replace("@border",border).replace("@hover",hover).replace("@onAccent",onAccent).replace("@accent",accent)
           .replace("@arrow",d?":/icons/chevron-dark.png":":/icons/chevron-light.png")
           .replace("@check",d?":/icons/check-dark.png":":/icons/check-light.png")
           .replace("@font",QString::number(a.textSize)).replace("@pad",a.compact?"6":"9");
        qApp->setStyleSheet(qss);
    }
    if(save) {
        QSettings s; s.setValue("appearance/theme",a.theme); s.setValue("appearance/accent",a.accent);
        s.setValue("appearance/textSize",a.textSize); s.setValue("appearance/compact",a.compact);
        s.setValue("appearance/controlsRight",a.controlsRight); s.setValue("appearance/coloredControls",a.coloredControls);
    }
    emit instance().changed();
    for(auto* w:QApplication::allWidgets()) w->update();
}
}
